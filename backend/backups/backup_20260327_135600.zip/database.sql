mysqldump: [Warning] Using a password on the command line interface can be insecure.
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: house_db
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin_building_scope`
--

DROP TABLE IF EXISTS `admin_building_scope`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin_building_scope` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `admin_id` bigint NOT NULL,
  `building_id` bigint NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_admin_building_scope` (`admin_id`,`building_id`),
  KEY `idx_admin_building_scope_admin_id` (`admin_id`),
  KEY `idx_admin_building_scope_building_id` (`building_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin_building_scope`
--

LOCK TABLES `admin_building_scope` WRITE;
/*!40000 ALTER TABLE `admin_building_scope` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_building_scope` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alert_record`
--

DROP TABLE IF EXISTS `alert_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alert_record` (
  `id` int NOT NULL AUTO_INCREMENT,
  `alert_type` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `level` tinyint NOT NULL,
  `status` tinyint NOT NULL DEFAULT '0',
  `operator_id` int DEFAULT NULL,
  `handled_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_alert_type_status_time` (`alert_type`,`status`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alert_record`
--

LOCK TABLES `alert_record` WRITE;
/*!40000 ALTER TABLE `alert_record` DISABLE KEYS */;
INSERT INTO `alert_record` VALUES (1,'login_failures','连续登录失败: anonymousUser','在5分钟内登录失败=4次，超过阈值=3',3,0,NULL,NULL,'2026-03-27 13:16:00'),(2,'login_failures','连续登录失败: anonymousUser','在5分钟内登录失败=7次，超过阈值=3',3,0,NULL,NULL,'2026-03-27 13:21:00');
/*!40000 ALTER TABLE `alert_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `alert_rule`
--

DROP TABLE IF EXISTS `alert_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alert_rule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `rule_type` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `enabled` tinyint NOT NULL DEFAULT '1',
  `threshold_value` int DEFAULT NULL,
  `window_minutes` int DEFAULT NULL,
  `level` tinyint NOT NULL DEFAULT '2',
  `notify_channels` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_alert_rule_type` (`rule_type`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alert_rule`
--

LOCK TABLES `alert_rule` WRITE;
/*!40000 ALTER TABLE `alert_rule` DISABLE KEYS */;
INSERT INTO `alert_rule` VALUES (1,'high_frequency','短时高频操作',1,5,1,2,'in_app','2026-03-26 23:48:00','2026-03-26 23:48:00'),(2,'login_failures','连续登录失败',1,3,5,3,'in_app,email','2026-03-26 23:48:00','2026-03-26 23:48:00'),(3,'sensitive_operation','敏感操作提醒',1,NULL,10,2,'in_app','2026-03-26 23:48:00','2026-03-26 23:48:00');
/*!40000 ALTER TABLE `alert_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appliance_template`
--

DROP TABLE IF EXISTS `appliance_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `appliance_template` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `default_quantity` int DEFAULT '1',
  `unit` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '个',
  `sort_order` int DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appliance_template`
--

LOCK TABLES `appliance_template` WRITE;
/*!40000 ALTER TABLE `appliance_template` DISABLE KEYS */;
INSERT INTO `appliance_template` VALUES (1,'床','',1,'张',1,'2026-03-13 16:30:26'),(2,'衣柜','',1,'个',2,'2026-03-13 16:30:26'),(3,'空调','',1,'台',3,'2026-03-13 16:30:26'),(4,'热水器','',1,'台',4,'2026-03-13 16:30:26');
/*!40000 ALTER TABLE `appliance_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_config`
--

DROP TABLE IF EXISTS `backup_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_config` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '閰嶇疆ID',
  `enabled` tinyint(1) DEFAULT '0' COMMENT '鏄?惁鍚?敤鑷?姩澶囦唤',
  `backup_type` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT 'daily' COMMENT '澶囦唤鍛ㄦ湡: daily/weekly',
  `backup_day` int DEFAULT '1' COMMENT '姣忓懆澶囦唤鏃?1-7, 1=鍛ㄤ竴)',
  `backup_time` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT '02:00' COMMENT '澶囦唤鏃堕棿(HH:mm)',
  `retention_count` int DEFAULT '7' COMMENT '淇濈暀浠芥暟',
  `storage_path` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT './backups' COMMENT '瀛樺偍璺?緞',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '鍒涘缓鏃堕棿',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '鏇存柊鏃堕棿',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='澶囦唤閰嶇疆琛';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_config`
--

LOCK TABLES `backup_config` WRITE;
/*!40000 ALTER TABLE `backup_config` DISABLE KEYS */;
INSERT INTO `backup_config` VALUES (1,0,'weekly',1,'02:00',7,'./backups','2026-03-14 11:15:17','2026-03-14 11:15:17');
/*!40000 ALTER TABLE `backup_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_record`
--

DROP TABLE IF EXISTS `backup_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_record` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '澶囦唤ID',
  `backup_time` datetime NOT NULL COMMENT '澶囦唤鏃堕棿',
  `type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'manual' COMMENT '澶囦唤绫诲瀷: auto/manual',
  `status` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'success' COMMENT '鐘舵?: success/failed',
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '澶囦唤鏂囦欢鍚',
  `file_path` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '瀛樺偍璺?緞',
  `file_size` bigint DEFAULT '0' COMMENT '鏂囦欢澶у皬(瀛楄妭)',
  `md5` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '鏂囦欢MD5',
  `fail_reason` text COLLATE utf8mb4_unicode_ci COMMENT '澶辫触鍘熷洜',
  `operator_id` bigint DEFAULT NULL COMMENT '鎿嶄綔浜篒D',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '璁板綍鍒涘缓鏃堕棿',
  PRIMARY KEY (`id`),
  KEY `idx_backup_time` (`backup_time`),
  KEY `idx_type` (`type`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='澶囦唤璁板綍琛';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_record`
--

LOCK TABLES `backup_record` WRITE;
/*!40000 ALTER TABLE `backup_record` DISABLE KEYS */;
INSERT INTO `backup_record` VALUES (1,'2026-03-14 23:45:45','manual','failed','backup_20260314_234545.zip','./backups/backup_20260314_234545.zip',0,NULL,'Range [109, 36) out of bounds for length 146',1,NULL),(2,'2026-03-14 23:54:28','manual','success','backup_20260314_235427.zip','./backups/backup_20260314_235427.zip',10722,'3c27dea63b8b648dba529fe2fbc897ad',NULL,1,NULL),(3,'2026-03-14 23:59:52','manual','success','backup_20260314_235952.zip','./backups/backup_20260314_235952.zip',5891608,'53062df7cb0ed8ed0a0f162cb7f2042b',NULL,1,NULL);
/*!40000 ALTER TABLE `backup_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bill`
--

DROP TABLE IF EXISTS `bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bill` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '账单ID',
  `contract_id` bigint NOT NULL COMMENT '合同ID',
  `bill_month` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '账单月份 yyyy-MM',
  `total_amount` decimal(12,2) DEFAULT '0.00' COMMENT '总金额',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'PENDING' COMMENT '状态: PENDING/PAID/OBSOLETE',
  `generated_date` datetime DEFAULT NULL COMMENT '生成日期',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `room_id` bigint DEFAULT NULL,
  `room_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `building_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tenant_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tenant_phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_contract_month` (`contract_id`,`bill_month`),
  KEY `idx_bill_contract_id` (`contract_id`),
  KEY `idx_bill_status_month_created` (`status`,`bill_month`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=74 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='账单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bill`
--

LOCK TABLES `bill` WRITE;
/*!40000 ALTER TABLE `bill` DISABLE KEYS */;
INSERT INTO `bill` VALUES (52,2,'2026-03',10.00,'VOID','2026-03-11 18:10:09','2026-03-11 18:10:09',1,'101','A栋','张三','12345678911',NULL),(53,3,'2026-03',110.00,'已支付','2026-03-11 18:10:09','2026-03-11 18:10:09',2,'202','A栋','张三','12345678911',NULL),(66,1,'2026-01',120.00,'待支付','2026-03-12 21:15:44','2026-03-14 21:02:04',1,'A-101',NULL,'测试用户','13800000000',0),(68,2,'2026-02',10.00,'PENDING','2026-03-15 22:32:06','2026-03-15 22:32:06',1,'101','A栋','ZhangSan','12345678911',NULL),(69,3,'2026-02',110.00,'PENDING','2026-03-15 22:32:07','2026-03-15 22:32:06',2,'202','A栋','ZhangSan','12345678911',NULL),(70,6,'2026-03',2450.00,'已支付','2026-03-22 23:52:52','2026-03-22 23:52:52',8,'T101','T楼','租客测试A','13900009999',0),(71,6,'2026-02',1980.00,'部分支付','2026-03-22 23:52:52','2026-03-22 23:52:52',8,'T101','T楼','租客测试A','13900009999',0),(72,8,'2026-03',2450.00,'PENDING','2026-03-22 23:53:34','2026-03-22 23:53:34',10,'T101','T楼','租客测试A','13900009999',0),(73,8,'2026-02',1980.00,'部分支付','2026-03-22 23:53:34','2026-03-22 23:53:34',10,'T101','T楼','租客测试A','13900009999',0);
/*!40000 ALTER TABLE `bill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bill_detail`
--

DROP TABLE IF EXISTS `bill_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bill_detail` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '明细ID',
  `bill_id` bigint NOT NULL COMMENT '账单ID',
  `fee_item_id` bigint DEFAULT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '费用名称',
  `usage_amount` decimal(10,2) DEFAULT NULL,
  `amount` decimal(12,2) DEFAULT NULL COMMENT '金额',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `prev_reading` double DEFAULT '0',
  `curr_reading` double DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bill_id` (`bill_id`)
) ENGINE=InnoDB AUTO_INCREMENT=114 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='账单明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bill_detail`
--

LOCK TABLES `bill_detail` WRITE;
/*!40000 ALTER TABLE `bill_detail` DISABLE KEYS */;
INSERT INTO `bill_detail` VALUES (1,14,NULL,'基础房费',1.00,10.00,'2026-03-10 22:28:45',0,0),(2,14,NULL,'水费',10.00,35.00,'2026-03-10 22:28:45',0,0),(3,14,NULL,'电费',10.00,6.00,'2026-03-10 22:28:45',0,0),(4,15,NULL,'基础房费',1.00,110.00,'2026-03-10 22:28:45',0,0),(7,20,NULL,'基础房费',1.00,10.00,'2026-03-10 22:58:48',0,0),(8,20,NULL,'水费',30.00,105.00,'2026-03-10 22:58:48',0,0),(9,20,NULL,'电费',30.00,18.00,'2026-03-10 22:58:48',0,0),(10,21,NULL,'基础房费',1.00,110.00,'2026-03-10 22:58:48',0,0),(68,52,NULL,'基础房费',1.00,10.00,'2026-03-11 18:10:09',NULL,NULL),(69,52,NULL,'水费',40.00,0.00,'2026-03-11 18:10:09',40,80),(70,52,NULL,'电费',40.00,0.00,'2026-03-11 18:10:09',40,80),(71,53,NULL,'基础房费',1.00,110.00,'2026-03-11 18:10:09',NULL,NULL),(72,53,NULL,'水费',0.00,0.00,'2026-03-11 18:10:09',20,20),(73,53,NULL,'电费',0.00,0.00,'2026-03-11 18:10:09',20,20),(106,68,NULL,'基础房费',1.00,10.00,'2026-03-15 22:32:06',0,0),(107,69,NULL,'基础房费',1.00,110.00,'2026-03-15 22:32:06',0,0),(108,70,0,'房租',1.00,2000.00,'2026-03-22 23:52:52',0,0),(109,70,0,'水费',10.00,32.00,'2026-03-22 23:52:52',0,0),(110,70,0,'电费',380.00,418.00,'2026-03-22 23:52:52',0,0),(111,72,0,'房租',1.00,2000.00,'2026-03-22 23:53:34',0,0),(112,72,0,'水费',10.00,32.00,'2026-03-22 23:53:34',0,0),(113,72,0,'电费',380.00,418.00,'2026-03-22 23:53:34',0,0);
/*!40000 ALTER TABLE `bill_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `building`
--

DROP TABLE IF EXISTS `building`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `building` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '楼栋ID',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '楼栋名称',
  `code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '楼栋编号',
  `address` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '地址',
  `total_floors` int DEFAULT '1' COMMENT '楼层数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `image_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `water_unit_price` double DEFAULT '0',
  `electric_unit_price` double DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='楼栋表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `building`
--

LOCK TABLES `building` WRITE;
/*!40000 ALTER TABLE `building` DISABLE KEYS */;
INSERT INTO `building` VALUES (1,'A栋','aaa','大萨达撒',3,'2026-03-26 22:16:06','/api/files/9c824e43-7d30-42c1-8fd5-ffac92bbb6c6.gif',0,0,0),(2,'C','c','dasd ',1,'2026-03-11 17:38:20','',NULL,12,2),(3,'B','b ','das sa',1,'2026-03-11 17:55:10','/api/files/4b223c3c-939c-4295-86da-e1250490ba48____.jpg',0,10,1),(4,'12','1','12',1,'2026-03-26 22:19:03','/api/files/3f011ae6-acd8-419a-b036-93f762a9c125_outputs_20250727_934ux694k9.png',0,5,1),(5,'??????','IMG-T','????',6,'2026-03-13 15:09:30','/api/files/5a8b2552-6457-4cc6-9973-3b1515768872_demo.jpeg',0,3.21,0.88),(6,'??????','IMG-OK','????',8,'2026-03-13 15:14:00','/api/files/d7359b5a-486a-40b5-8317-ebfc406e087a_49c74ab4-8fda-43a7-9369-2a480b9e50b3_demo.jpeg',0,3.66,0.77),(7,'??????','IMG-FINAL','????',9,'2026-03-13 15:17:34','/api/files/645d223a-7d43-414b-bdb5-affa241a7438.jpg',0,3.66,0.77),(8,'??????','IMG-REAL','????',10,'2026-03-13 15:20:42','/api/files/b46d4e78-479d-4df5-a1aa-310eb84f1138_49c74ab4-8fda-43a7-9369-2a480b9e50b3_demo.jpeg',0,3.88,0.79),(11,'T楼','T001','测试地址',10,'2026-03-22 23:52:52',NULL,0,3.2,1.1),(12,'T楼','T001','测试地址',10,'2026-03-22 23:53:34',NULL,0,3.2,1.1);
/*!40000 ALTER TABLE `building` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `complaint_log`
--

DROP TABLE IF EXISTS `complaint_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `complaint_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `complaint_id` bigint NOT NULL,
  `operator_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'admin',
  `operator_id` bigint DEFAULT NULL,
  `action` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_complaint_log_complaint_id` (`complaint_id`),
  KEY `idx_complaint_log_created_at` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `complaint_log`
--

LOCK TABLES `complaint_log` WRITE;
/*!40000 ALTER TABLE `complaint_log` DISABLE KEYS */;
INSERT INTO `complaint_log` VALUES (1,1,'tenant',3,'submit','租客提交投诉','2026-03-23 11:02:08'),(2,2,'tenant',3,'submit','租客提交投诉','2026-03-23 11:02:42'),(3,3,'tenant',3,'submit','租客提交投诉','2026-03-23 11:13:30'),(4,4,'tenant',3,'submit','租客提交投诉','2026-03-23 12:42:42'),(5,5,'tenant',3,'submit','租客提交投诉','2026-03-23 12:43:13'),(6,6,'tenant',3,'submit','租客提交投诉','2026-03-23 12:59:27'),(7,7,'tenant',3,'submit','租客提交投诉','2026-03-23 13:02:17'),(8,8,'tenant',3,'submit','租客提交投诉','2026-03-23 13:09:03'),(9,9,'tenant',3,'submit','租客提交投诉','2026-03-23 13:12:31'),(10,10,'admin',1,'submit','提交投诉: ??????','2026-03-23 13:14:43'),(11,10,'admin',1,'accept','已受理，受理意见: ????，处理人: 系统管理员','2026-03-23 13:14:43'),(12,10,'admin',1,'reply','???????','2026-03-23 13:14:43'),(13,10,'admin',1,'complete','完成处理: ????（待确认）','2026-03-23 13:14:43'),(14,10,'admin',1,'confirm','确认完成','2026-03-23 13:14:43'),(15,11,'admin',1,'submit','提交投诉: ??????','2026-03-23 13:14:53'),(16,11,'admin',1,'accept','已受理，受理意见: ????，处理人: 系统管理员','2026-03-23 13:14:53'),(17,11,'admin',1,'reply','???????','2026-03-23 13:14:53'),(18,11,'admin',1,'complete','完成处理: ????（待确认）','2026-03-23 13:14:53'),(19,11,'admin',1,'confirm','确认完成','2026-03-23 13:14:53'),(20,12,'tenant',3,'submit','租客提交投诉','2026-03-23 13:17:48'),(21,13,'tenant',3,'submit','租客提交投诉','2026-03-23 13:23:30'),(22,14,'admin',1,'submit','提交投诉: ??????','2026-03-23 13:23:49'),(23,14,'admin',1,'accept','已受理，受理意见: ????，处理人: 系统管理员','2026-03-23 13:23:49'),(24,14,'admin',1,'reply','???????','2026-03-23 13:23:49'),(25,14,'admin',1,'complete','完成处理: ??????（待确认）','2026-03-23 13:23:49'),(26,14,'admin',1,'confirm','确认完成','2026-03-23 13:23:49'),(27,15,'tenant',3,'submit','租客提交投诉','2026-03-23 14:58:35'),(28,16,'tenant',3,'submit','租客提交投诉','2026-03-23 15:01:46'),(29,17,'tenant',3,'submit','租客提交投诉','2026-03-23 15:18:13'),(30,17,'admin',1,'accept','已受理，受理意见: ??，处理人: 系统管理员','2026-03-23 15:18:58'),(31,17,'admin',1,'reply','?????','2026-03-23 15:18:58'),(32,17,'admin',1,'complete','完成处理: ????（待确认）','2026-03-23 15:18:58'),(33,17,'admin',1,'confirm','确认完成','2026-03-23 15:18:58'),(34,18,'tenant',3,'submit','租客提交投诉','2026-03-23 15:33:48'),(35,19,'tenant',3,'submit','租客提交投诉','2026-03-23 15:34:11'),(36,20,'tenant',3,'submit','租客提交投诉','2026-03-23 15:37:31'),(37,21,'tenant',3,'submit','租客提交投诉','2026-03-23 15:46:09'),(38,22,'tenant',3,'submit','租客提交投诉','2026-03-23 15:46:40'),(39,23,'tenant',1,'submit','租客提交投诉','2026-03-26 22:35:49'),(40,23,'admin',1,'accept','已受理，处理人: 系统管理员','2026-03-26 22:36:24'),(41,23,'admin',1,'complete','完成处理（待确认）','2026-03-26 22:36:36');
/*!40000 ALTER TABLE `complaint_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `complaint_suggestion`
--

DROP TABLE IF EXISTS `complaint_suggestion`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `complaint_suggestion` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `complaint_no` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenant_id` bigint DEFAULT NULL,
  `room_id` bigint NOT NULL,
  `reporter_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'admin',
  `reported_by` bigint DEFAULT NULL,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `images` json DEFAULT NULL,
  `is_anonymous` tinyint DEFAULT '0',
  `priority` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'normal',
  `status` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `assigned_to` bigint DEFAULT NULL,
  `assigned_at` datetime DEFAULT NULL,
  `completed_at` datetime DEFAULT NULL,
  `closed_at` datetime DEFAULT NULL,
  `closed_reason` text COLLATE utf8mb4_unicode_ci,
  `rating` tinyint DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_complaint_no` (`complaint_no`),
  KEY `idx_complaint_status` (`status`),
  KEY `idx_complaint_room_id` (`room_id`),
  KEY `idx_complaint_tenant_id` (`tenant_id`),
  KEY `idx_complaint_created_at` (`created_at`),
  KEY `idx_complaint_tenant_status_created` (`tenant_id`,`status`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `complaint_suggestion`
--

LOCK TABLES `complaint_suggestion` WRITE;
/*!40000 ALTER TABLE `complaint_suggestion` DISABLE KEYS */;
INSERT INTO `complaint_suggestion` VALUES (1,'CP1774234928405',3,8,'tenant',3,'??????','?????????','?????????','[]',0,'normal','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-23 11:02:08','2026-03-23 11:02:08'),(2,'CP1774234961889',3,8,'tenant',3,'service','phase2 smoke complaint','phase2 smoke content','[]',0,'normal','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-23 11:02:42','2026-03-23 11:02:42'),(3,'CP1774235610332',3,8,'tenant',3,'service','phase2 final complaint','phase2 final content','[]',0,'normal','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-23 11:13:30','2026-03-23 11:13:30'),(4,'CP1774240961756',3,8,'tenant',3,'??????','?????????','?????????','[]',0,'normal','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-23 12:42:42','2026-03-23 12:42:42'),(5,'CP1774240992603',3,8,'tenant',3,'??????','?????????','?????????','[]',0,'normal','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-23 12:43:13','2026-03-23 12:43:13'),(6,'CP1774241966492',3,8,'tenant',3,'??????','?????????','?????????','[]',0,'normal','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-23 12:59:26','2026-03-23 12:59:26'),(7,'CP1774242136619',3,8,'tenant',3,'??????','?????????','?????????','[]',0,'normal','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-23 13:02:17','2026-03-23 13:02:17'),(8,'CP1774242542734',3,8,'tenant',3,'??????','?????????','?????????','[]',0,'normal','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-23 13:09:03','2026-03-23 13:09:03'),(9,'CP1774242751079',3,8,'tenant',3,'??????','?????????','?????????','[]',0,'normal','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-23 13:12:31','2026-03-23 13:12:31'),(10,'CP20260323131443980',1,1,'admin',1,'????','??????','???????','[]',0,'normal','completed',1,'2026-03-23 13:14:43','2026-03-23 13:14:43',NULL,NULL,NULL,NULL,'2026-03-23 13:14:43','2026-03-23 13:14:43'),(11,'CP20260323131453807',1,1,'admin',1,'????','??????','???????','[]',0,'normal','completed',1,'2026-03-23 13:14:53','2026-03-23 13:14:53',NULL,NULL,NULL,NULL,'2026-03-23 13:14:53','2026-03-23 13:14:53'),(12,'CP1774243068417',3,8,'tenant',3,'??????','?????????','?????????','[]',0,'normal','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-23 13:17:48','2026-03-23 13:17:48'),(13,'CP1774243409572',3,8,'tenant',3,'??????','?????????','?????????','[]',0,'normal','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-23 13:23:30','2026-03-23 13:23:30'),(14,'CP20260323132348931',1,1,'admin',1,'????','??????','????','[]',0,'normal','completed',1,'2026-03-23 13:23:49','2026-03-23 13:23:49',NULL,NULL,NULL,NULL,'2026-03-23 13:23:49','2026-03-23 13:23:49'),(15,'CP1774249115088',3,8,'tenant',3,'??????','?????????','?????????','[]',0,'normal','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-23 14:58:35','2026-03-23 14:58:35'),(16,'CP1774249305798',3,8,'tenant',3,'??????','?????????','?????????','[]',0,'normal','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-23 15:01:46','2026-03-23 15:01:46'),(17,'CP1774250292696',3,8,'tenant',3,'??????','?????????','?????????','[]',0,'normal','completed',1,'2026-03-23 15:18:58','2026-03-23 15:18:58',NULL,NULL,NULL,NULL,'2026-03-23 15:18:13','2026-03-23 15:18:58'),(18,'CP1774251227884',3,8,'tenant',3,'??????','?????????','?????????','[]',0,'normal','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-23 15:33:48','2026-03-23 15:33:48'),(19,'CP1774251251205',3,8,'tenant',3,'??????','?????????','?????????','[]',0,'normal','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-23 15:34:11','2026-03-23 15:34:11'),(20,'CP1774251451353',3,8,'tenant',3,'??????','?????????','?????????','[]',0,'normal','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-23 15:37:31','2026-03-23 15:37:31'),(21,'CP1774251968642',3,8,'tenant',3,'??????','?????????','?????????','[]',0,'normal','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-23 15:46:09','2026-03-23 15:46:09'),(22,'CP1774252000328',3,8,'tenant',3,'??????','?????????','?????????','[]',0,'normal','pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2026-03-23 15:46:40','2026-03-23 15:46:40'),(23,'CP1774535748645',1,1,'tenant',1,'服务态度','111','1123','[]',0,'normal','pending_confirm',1,'2026-03-26 22:36:24','2026-03-26 22:36:36',NULL,NULL,NULL,NULL,'2026-03-26 22:35:49','2026-03-26 22:36:36');
/*!40000 ALTER TABLE `complaint_suggestion` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract`
--

DROP TABLE IF EXISTS `contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '合同ID',
  `contract_no` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '合同编号',
  `room_id` bigint NOT NULL COMMENT '房间ID',
  `tenant_id` bigint NOT NULL COMMENT '租户ID',
  `start_date` date NOT NULL COMMENT '起租日期',
  `end_date` date NOT NULL COMMENT '结束日期',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'ACTIVE' COMMENT '状态: ACTIVE/EXPIRED/TERMINATED/PENDING',
  `monthly_rent` decimal(12,2) DEFAULT NULL COMMENT '月租金',
  `deposit` decimal(12,2) DEFAULT NULL COMMENT '押金',
  `payment_method` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'MONTHLY' COMMENT '付款方式',
  `remark` text COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `attachment_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '附件URL',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `deleted` tinyint DEFAULT '0',
  `reminder_sent` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '已发送的提醒记录，JSON格式',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_contract_no` (`contract_no`),
  KEY `idx_contract_tenant_status` (`tenant_id`,`status`),
  KEY `idx_contract_status_end_date` (`status`,`end_date`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='合同表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract`
--

LOCK TABLES `contract` WRITE;
/*!40000 ALTER TABLE `contract` DISABLE KEYS */;
INSERT INTO `contract` VALUES (1,'CT1773146939064',2,1,'2026-03-01','2026-03-11','TERMINATED',10.00,10.00,'MONTHLY','','','2026-03-10 20:48:59',0,NULL),(2,'CT1773147392973',1,1,'2026-03-01','2026-03-27','ACTIVE',10.00,10.00,'MONTHLY','','','2026-03-10 20:56:32',0,NULL),(3,'CT1773147765497',2,1,'2026-03-01','2026-03-31','ACTIVE',110.00,10.00,'MONTHLY','','','2026-03-10 21:02:45',0,NULL),(4,'CT1773328382197',3,1,'2026-02-01','2026-03-12','TERMINATED',1110.00,1110.00,'MONTHLY','','','2026-03-12 23:13:02',NULL,NULL),(5,'CT1773328651212',3,1,'2026-03-12','2026-03-12','TERMINATED',500.00,1000.00,'MONTHLY',NULL,NULL,'2026-03-12 23:17:31',NULL,NULL),(6,'TEST-C-1774194772-1',8,3,'2026-03-22','2027-03-22','ACTIVE',2000.00,2000.00,'MONTHLY',NULL,NULL,'2026-03-22 23:52:52',0,NULL),(7,'TEST-C-1774194772-2',9,3,'2026-03-22','2027-03-22','ACTIVE',2300.00,2300.00,'MONTHLY',NULL,NULL,'2026-03-22 23:52:52',0,NULL),(8,'TEST-C-1774194814-1',10,3,'2026-03-22','2027-03-22','ACTIVE',2000.00,2000.00,'MONTHLY',NULL,NULL,'2026-03-22 23:53:34',0,NULL),(9,'TEST-C-1774194814-2',11,3,'2026-03-22','2027-03-22','ACTIVE',2300.00,2300.00,'MONTHLY',NULL,NULL,'2026-03-22 23:53:34',0,NULL);
/*!40000 ALTER TABLE `contract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deposit_record`
--

DROP TABLE IF EXISTS `deposit_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deposit_record` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '押金ID',
  `contract_id` bigint NOT NULL COMMENT '合同ID',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '类型: RECEIVE/REFUND',
  `amount` decimal(12,2) NOT NULL COMMENT '金额',
  `date` date NOT NULL COMMENT '日期',
  `remark` text COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='押金记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deposit_record`
--

LOCK TABLES `deposit_record` WRITE;
/*!40000 ALTER TABLE `deposit_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `deposit_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fee_item`
--

DROP TABLE IF EXISTS `fee_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fee_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '费用项ID',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '费用名称',
  `unit_price` decimal(10,2) NOT NULL COMMENT '单价',
  `unit` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '元/月' COMMENT '单位',
  `category` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'BASE' COMMENT '类别',
  `enabled` tinyint(1) DEFAULT '1' COMMENT '是否启用',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='费用项表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fee_item`
--

LOCK TABLES `fee_item` WRITE;
/*!40000 ALTER TABLE `fee_item` DISABLE KEYS */;
INSERT INTO `fee_item` VALUES (1,'网费',10.00,'元/月','BASE',1,'2026-03-10 22:13:12');
/*!40000 ALTER TABLE `fee_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feedback`
--

DROP TABLE IF EXISTS `feedback`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `feedback` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint NOT NULL,
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `images` text COLLATE utf8mb4_unicode_ci,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_feedback_tenant` (`tenant_id`),
  KEY `idx_feedback_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feedback`
--

LOCK TABLES `feedback` WRITE;
/*!40000 ALTER TABLE `feedback` DISABLE KEYS */;
INSERT INTO `feedback` VALUES (1,3,'??????','?????????','[]','13900009999',0,'2026-03-23 11:02:09'),(2,3,'suggestion','phase2 smoke feedback','[]','13900009999',0,'2026-03-23 11:02:42'),(3,3,'suggestion','phase2 final feedback','[]','13900009999',0,'2026-03-23 11:13:30'),(4,3,'??????','?????????','[]','13900009999',0,'2026-03-23 12:42:42'),(5,3,'??????','?????????','[]','13900009999',0,'2026-03-23 12:43:13'),(6,3,'??????','?????????','[]','13900009999',0,'2026-03-23 12:59:27'),(7,3,'??????','?????????','[]','13900009999',0,'2026-03-23 13:02:17'),(8,3,'??????','?????????','[]','13900009999',0,'2026-03-23 13:09:03'),(9,3,'??????','?????????','[]','13900009999',0,'2026-03-23 13:12:31'),(10,3,'??????','?????????','[]','13900009999',0,'2026-03-23 13:17:49'),(11,3,'??????','?????????','[]','13900009999',0,'2026-03-23 13:23:30'),(12,3,'??????','?????????','[]','13900009999',0,'2026-03-23 14:58:35'),(13,3,'??????','?????????','[]','13900009999',0,'2026-03-23 15:01:46'),(14,3,'??????','?????????','[]','13900009999',0,'2026-03-23 15:18:13'),(15,3,'??????','?????????','[]','13900009999',0,'2026-03-23 15:33:48'),(16,3,'??????','?????????','[]','13900009999',0,'2026-03-23 15:34:11'),(17,3,'??????','?????????','[]','13900009999',0,'2026-03-23 15:37:32'),(18,3,'??????','?????????','[]','13900009999',0,'2026-03-23 15:46:09'),(19,3,'??????','?????????','[]','13900009999',0,'2026-03-23 15:46:40');
/*!40000 ALTER TABLE `feedback` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `guide_dismiss`
--

DROP TABLE IF EXISTS `guide_dismiss`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `guide_dismiss` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint NOT NULL,
  `dismiss_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dismissed_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_guide_user_key` (`user_id`,`dismiss_key`),
  KEY `idx_guide_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `guide_dismiss`
--

LOCK TABLES `guide_dismiss` WRITE;
/*!40000 ALTER TABLE `guide_dismiss` DISABLE KEYS */;
INSERT INTO `guide_dismiss` VALUES (1,1,'tip:dashboard','2026-03-26 23:09:30'),(4,1,'tour:dashboard','2026-03-26 23:16:31'),(5,1,'help:center','2026-03-27 13:27:00');
/*!40000 ALTER TABLE `guide_dismiss` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `handler`
--

DROP TABLE IF EXISTS `handler`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `handler` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `idx_handler_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `handler`
--

LOCK TABLES `handler` WRITE;
/*!40000 ALTER TABLE `handler` DISABLE KEYS */;
/*!40000 ALTER TABLE `handler` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maintenance_mode`
--

DROP TABLE IF EXISTS `maintenance_mode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `maintenance_mode` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `enabled` tinyint(1) DEFAULT '0' COMMENT '鏄?惁鍚?敤缁存姢妯″紡',
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '缁存姢鍘熷洜',
  `operator_id` bigint DEFAULT NULL COMMENT '鎿嶄綔浜篒D',
  `started_at` datetime DEFAULT NULL COMMENT '寮??鏃堕棿',
  `ended_at` datetime DEFAULT NULL COMMENT '缁撴潫鏃堕棿',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '鍒涘缓鏃堕棿',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='缁存姢妯″紡琛';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maintenance_mode`
--

LOCK TABLES `maintenance_mode` WRITE;
/*!40000 ALTER TABLE `maintenance_mode` DISABLE KEYS */;
INSERT INTO `maintenance_mode` VALUES (1,0,'数据恢复中',1,'2026-03-14 23:54:29','2026-03-14 23:54:29',NULL);
/*!40000 ALTER TABLE `maintenance_mode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meter_reading`
--

DROP TABLE IF EXISTS `meter_reading`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `meter_reading` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '读数ID',
  `room_id` bigint NOT NULL COMMENT '房间ID',
  `record_date` date NOT NULL COMMENT '录入日期',
  `water_reading` decimal(10,2) DEFAULT '0.00' COMMENT '水表读数',
  `electric_reading` decimal(10,2) DEFAULT '0.00' COMMENT '电表读数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_room_date` (`room_id`,`record_date`),
  KEY `idx_meter_record_date_room` (`record_date`,`room_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='水电读数表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meter_reading`
--

LOCK TABLES `meter_reading` WRITE;
/*!40000 ALTER TABLE `meter_reading` DISABLE KEYS */;
INSERT INTO `meter_reading` VALUES (1,1,'2026-03-10',70.00,70.00,'2026-03-10 21:04:52'),(2,2,'2026-03-10',20.00,20.00,'2026-03-10 21:04:52'),(3,1,'2026-03-09',40.00,40.00,'2026-03-10 22:22:36'),(4,1,'2026-03-11',80.00,80.00,'2026-03-11 09:49:37'),(5,1,'2026-02-01',0.00,0.00,'2026-03-12 14:10:04'),(6,1,'2026-03-12',90.00,90.00,'2026-03-12 14:10:30'),(7,1,'2026-03-15',90.00,90.00,'2026-03-15 21:49:47'),(8,2,'2026-03-15',100.00,100.00,'2026-03-15 22:33:38'),(9,1,'2026-03-17',120.00,120.00,'2026-03-17 12:22:56'),(10,1,'2026-03-26',1250.50,3680.00,'2026-03-26 22:38:05'),(11,2,'2026-03-26',1312.30,3725.00,'2026-03-26 22:38:05');
/*!40000 ALTER TABLE `meter_reading` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notice`
--

DROP TABLE IF EXISTS `notice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `notice` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort` int NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_notice_sort_created` (`sort`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notice`
--

LOCK TABLES `notice` WRITE;
/*!40000 ALTER TABLE `notice` DISABLE KEYS */;
INSERT INTO `notice` VALUES (1,'测试公告-停水通知','<p>今晚22:00-23:00停水检修，请提前储水。</p>',NULL,100,'2026-03-22 23:53:34');
/*!40000 ALTER TABLE `notice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operation_log`
--

DROP TABLE IF EXISTS `operation_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `operation_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '日志ID',
  `user_id` bigint DEFAULT NULL COMMENT '鎿嶄綔鐢ㄦ埛ID',
  `username` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '鐢ㄦ埛鍚',
  `operation_time` datetime NOT NULL COMMENT '操作时间',
  `operator` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '操作人',
  `module` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '模块',
  `action` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '操作内容',
  `business_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '涓氬姟瀵硅薄ID',
  `business_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '涓氬姟瀵硅薄鍚嶇О',
  `detail_before` json DEFAULT NULL COMMENT '鎿嶄綔鍓嶅揩鐓',
  `detail_after` json DEFAULT NULL COMMENT '鎿嶄綔鍚庡揩鐓',
  `change_summary` text COLLATE utf8mb4_unicode_ci COMMENT '鍙樻洿鎽樿?',
  `request_ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '璇锋眰IP',
  `user_agent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'UserAgent',
  `request_params` text COLLATE utf8mb4_unicode_ci COMMENT '璇锋眰鍙傛暟',
  `result` tinyint NOT NULL DEFAULT '1' COMMENT '1鎴愬姛0澶辫触',
  `fail_reason` text COLLATE utf8mb4_unicode_ci COMMENT '澶辫触鍘熷洜',
  `duration_ms` int DEFAULT NULL COMMENT '鑰楁椂姣??',
  `log_level` tinyint NOT NULL DEFAULT '1' COMMENT '1-INFO 2-WARN 3-ERROR',
  `ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'IP地址',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `ai_instruction` text COLLATE utf8mb4_unicode_ci COMMENT 'AI原始指令',
  `ai_intent` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'AI解析意图',
  `ai_entities` text COLLATE utf8mb4_unicode_ci COMMENT 'AI解析实体JSON',
  `ai_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'AI执行状态',
  `ai_response_message` text COLLATE utf8mb4_unicode_ci COMMENT 'AI返回消息',
  `ai_duration_ms` bigint DEFAULT NULL COMMENT 'AI执行耗时ms',
  `ai_model_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'AI模型名称',
  PRIMARY KEY (`id`),
  KEY `idx_operation_time_module` (`operation_time`,`module`),
  KEY `idx_log_created_module_action` (`created_at`,`module`,`action`),
  KEY `idx_log_business_id` (`business_id`),
  KEY `idx_log_user_time` (`username`,`operation_time`),
  KEY `idx_log_level_result_duration` (`log_level`,`result`,`duration_ms`)
) ENGINE=InnoDB AUTO_INCREMENT=400 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='操作日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operation_log`
--

LOCK TABLES `operation_log` WRITE;
/*!40000 ALTER TABLE `operation_log` DISABLE KEYS */;
INSERT INTO `operation_log` VALUES (1,NULL,'anonymousUser','2026-03-13 15:36:17','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 15:36:17',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(2,NULL,'anonymousUser','2026-03-13 15:36:28','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 15:36:28',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(3,NULL,'anonymousUser','2026-03-13 15:36:39','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 15:36:39',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(4,NULL,'admin','2026-03-13 15:36:39','admin','批量操作','批量续租: 合同1份',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 15:36:39',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(5,NULL,'anonymousUser','2026-03-13 15:38:11','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 15:38:11',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(6,NULL,'admin','2026-03-13 15:38:11','admin','批量操作','批量发送通知: 租户2人',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 15:38:11',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(7,NULL,'admin','2026-03-13 15:45:05','admin','批量操作','批量导出: 模块=contracts',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-13 15:45:05',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(8,NULL,'anonymousUser','2026-03-13 16:12:24','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 16:12:24',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(9,NULL,'anonymousUser','2026-03-13 16:12:38','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 16:12:38',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(10,NULL,'anonymousUser','2026-03-13 16:15:56','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 16:15:56',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(11,NULL,'anonymousUser','2026-03-13 16:16:14','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 16:16:14',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(12,NULL,'anonymousUser','2026-03-13 16:16:43','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 16:16:43',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(13,NULL,'anonymousUser','2026-03-13 16:28:05','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 16:28:05',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(14,NULL,'anonymousUser','2026-03-13 16:28:30','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 16:28:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(15,NULL,'anonymousUser','2026-03-13 16:30:49','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 16:30:49',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(16,NULL,'anonymousUser','2026-03-13 16:31:23','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 16:31:23',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(17,NULL,'anonymousUser','2026-03-13 16:32:04','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 16:32:04',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(18,NULL,'anonymousUser','2026-03-13 16:37:50','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 16:37:50',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(19,NULL,'anonymousUser','2026-03-13 16:38:11','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 16:38:11',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(20,NULL,'anonymousUser','2026-03-13 16:48:13','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 16:48:13',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(21,NULL,'anonymousUser','2026-03-13 16:50:27','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 16:50:27',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(22,NULL,'admin','2026-03-13 16:50:28','admin','导出','导出房间器具核对单PDF: 房间101(入住)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 16:50:28',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(23,NULL,'anonymousUser','2026-03-13 16:50:34','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 16:50:34',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(24,NULL,'admin','2026-03-13 16:50:35','admin','导出','导出房间器具核对单PDF: 房间101(退租)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 16:50:35',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(25,NULL,'anonymousUser','2026-03-13 17:55:53','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 17:55:53',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(26,NULL,'anonymousUser','2026-03-13 17:56:16','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 17:56:16',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(27,NULL,'anonymousUser','2026-03-13 17:56:41','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 17:56:41',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(28,NULL,'anonymousUser','2026-03-13 17:57:14','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 17:57:14',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(29,NULL,'anonymousUser','2026-03-13 17:57:28','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 17:57:28',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(30,NULL,'anonymousUser','2026-03-13 17:58:00','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 17:58:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(31,NULL,'anonymousUser','2026-03-13 17:58:26','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 17:58:26',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(32,NULL,'anonymousUser','2026-03-13 18:00:23','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 18:00:23',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(33,NULL,'anonymousUser','2026-03-13 18:06:43','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 18:06:43',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(34,NULL,'anonymousUser','2026-03-13 18:09:14','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 18:09:14',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(35,NULL,'anonymousUser','2026-03-13 18:09:31','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 18:09:31',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(36,NULL,'anonymousUser','2026-03-13 18:09:44','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 18:09:44',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(37,NULL,'anonymousUser','2026-03-13 18:09:57','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 18:09:57',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(38,NULL,'anonymousUser','2026-03-13 18:10:13','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 18:10:13',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(39,NULL,'anonymousUser','2026-03-13 18:10:32','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 18:10:32',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(40,NULL,'admin','2026-03-13 18:10:32','admin','操作恢复','恢复 账单管理 - 2026-02 / #64',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 18:10:32',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(41,NULL,'anonymousUser','2026-03-13 18:11:15','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 18:11:15',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(42,NULL,'admin','2026-03-13 18:11:15','admin','操作恢复','恢复 账单管理 - 2026-02 / #64',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 18:11:15',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(43,NULL,'anonymousUser','2026-03-13 18:15:22','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 18:15:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(44,NULL,'admin','2026-03-13 18:15:22','admin','操作恢复','恢复 账单管理 - 2026-02 / #64',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 18:15:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(45,NULL,'anonymousUser','2026-03-13 18:23:31','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 18:23:31',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(46,NULL,'admin','2026-03-13 18:23:31','admin','操作恢复','恢复 账单管理 - 2026-02 / #64',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 18:23:31',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(47,NULL,'anonymousUser','2026-03-13 18:23:38','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 18:23:38',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(48,NULL,'anonymousUser','2026-03-13 18:26:26','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 18:26:26',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(49,NULL,'admin','2026-03-13 18:26:26','admin','操作恢复','恢复 房屋管理 - UNDO_TEST_1773397585',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 18:26:26',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(50,NULL,'anonymousUser','2026-03-13 18:28:09','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 18:28:09',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(51,NULL,'anonymousUser','2026-03-13 18:32:44','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 18:32:44',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(52,NULL,'admin','2026-03-13 18:32:44','admin','操作恢复','恢复 房屋管理 - UNDO_BLD_1773397963',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 18:32:44',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(53,NULL,'admin','2026-03-13 18:33:59','admin','操作恢复','恢复 房屋管理 - 101',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-13 18:33:59',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(54,NULL,'anonymousUser','2026-03-13 18:38:41','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-13 18:38:41',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(55,NULL,'anonymousUser','2026-03-13 21:36:43','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 21:36:43',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(56,NULL,'anonymousUser','2026-03-13 21:36:57','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 21:36:57',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(57,NULL,'anonymousUser','2026-03-13 21:37:59','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 21:37:59',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(58,NULL,'anonymousUser','2026-03-13 21:49:38','anonymousUser','用户认证','登录失败: 系统异常(admin)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 21:49:38',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(59,NULL,'anonymousUser','2026-03-13 21:50:07','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 21:50:07',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(60,NULL,'anonymousUser','2026-03-13 21:50:29','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 21:50:29',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(61,NULL,'anonymousUser','2026-03-13 21:52:47','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 21:52:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(62,NULL,'anonymousUser','2026-03-13 21:53:33','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 21:53:33',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(63,NULL,'anonymousUser','2026-03-13 21:53:33','anonymousUser','用户认证','登录成功: qr_viewer_1773410013',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-13 21:53:33',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(64,NULL,'anonymousUser','2026-03-14 21:18:34','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-14 21:18:34',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(65,NULL,'anonymousUser','2026-03-14 21:18:40','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-14 21:18:40',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(66,NULL,'anonymousUser','2026-03-14 21:18:52','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-14 21:18:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(67,NULL,'anonymousUser','2026-03-14 21:18:59','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-14 21:18:59',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(68,NULL,'anonymousUser','2026-03-14 21:19:02','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-14 21:19:02',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(69,NULL,'anonymousUser','2026-03-14 21:19:06','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-14 21:19:06',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(70,NULL,'anonymousUser','2026-03-14 21:19:34','anonymousUser','用户认证','登录成功: manager1',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-14 21:19:34',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(71,NULL,'anonymousUser','2026-03-14 21:20:33','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-14 21:20:33',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(72,NULL,'anonymousUser','2026-03-14 21:20:35','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-14 21:20:35',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(73,NULL,'anonymousUser','2026-03-14 21:22:43','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 21:22:43',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(74,NULL,'anonymousUser','2026-03-14 21:22:50','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 21:22:50',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(75,NULL,'anonymousUser','2026-03-14 21:23:08','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 21:23:08',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(76,NULL,'anonymousUser','2026-03-14 21:27:33','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-14 21:27:33',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(77,NULL,'anonymousUser','2026-03-14 21:27:39','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-14 21:27:39',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(78,NULL,'anonymousUser','2026-03-14 21:27:45','anonymousUser','用户认证','登录成功: manager1',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-14 21:27:45',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(79,NULL,'anonymousUser','2026-03-14 22:04:01','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-14 22:04:01',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(80,NULL,'anonymousUser','2026-03-14 22:11:13','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-14 22:11:13',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(81,NULL,'anonymousUser','2026-03-14 22:14:00','anonymousUser','用户认证','登录成功: manager1',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-14 22:14:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(82,NULL,'anonymousUser','2026-03-14 22:38:52','anonymousUser','用户认证','登录失败: 密码错误(manager1)',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-14 22:38:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(83,NULL,'anonymousUser','2026-03-14 22:38:55','anonymousUser','用户认证','登录成功: manager1',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-14 22:38:55',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(84,NULL,'anonymousUser','2026-03-14 22:39:02','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-14 22:39:02',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(85,NULL,'anonymousUser','2026-03-14 23:11:02','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:11:02',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(86,NULL,'anonymousUser','2026-03-14 23:11:12','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:11:12',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(87,NULL,'anonymousUser','2026-03-14 23:11:13','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:11:13',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(88,NULL,'anonymousUser','2026-03-14 23:11:37','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:11:37',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(89,NULL,'anonymousUser','2026-03-14 23:14:37','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:14:37',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(90,NULL,'anonymousUser','2026-03-14 23:14:38','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:14:38',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(91,NULL,'anonymousUser','2026-03-14 23:15:04','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:15:04',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(92,NULL,'anonymousUser','2026-03-14 23:17:16','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:17:16',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(93,NULL,'anonymousUser','2026-03-14 23:17:16','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:17:16',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(94,NULL,'anonymousUser','2026-03-14 23:17:25','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:17:25',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(95,NULL,'anonymousUser','2026-03-14 23:17:32','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:17:32',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(96,NULL,'anonymousUser','2026-03-14 23:21:21','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:21:21',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(97,NULL,'anonymousUser','2026-03-14 23:21:23','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:21:23',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(98,NULL,'anonymousUser','2026-03-14 23:21:23','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:21:23',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(99,NULL,'anonymousUser','2026-03-14 23:26:29','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:26:29',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(100,NULL,'anonymousUser','2026-03-14 23:26:30','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:26:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(101,NULL,'anonymousUser','2026-03-14 23:26:31','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:26:31',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(102,NULL,'anonymousUser','2026-03-14 23:28:44','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:28:44',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(103,NULL,'anonymousUser','2026-03-14 23:28:46','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:28:46',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(104,NULL,'anonymousUser','2026-03-14 23:28:46','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:28:46',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(105,NULL,'anonymousUser','2026-03-14 23:30:46','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:30:46',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(106,NULL,'anonymousUser','2026-03-14 23:30:47','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:30:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(107,NULL,'anonymousUser','2026-03-14 23:30:48','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:30:48',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(108,NULL,'anonymousUser','2026-03-14 23:32:37','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:32:37',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(109,NULL,'anonymousUser','2026-03-14 23:32:38','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:32:38',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(110,NULL,'anonymousUser','2026-03-14 23:32:39','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:32:39',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(111,NULL,'anonymousUser','2026-03-14 23:33:18','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:33:18',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(112,NULL,'anonymousUser','2026-03-14 23:33:37','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:33:37',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(113,NULL,'anonymousUser','2026-03-14 23:34:39','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:34:39',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(114,NULL,'anonymousUser','2026-03-14 23:38:12','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:38:12',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(115,NULL,'anonymousUser','2026-03-14 23:38:13','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:38:13',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(116,NULL,'anonymousUser','2026-03-14 23:38:13','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:38:13',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(117,NULL,'anonymousUser','2026-03-14 23:38:26','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:38:26',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(118,NULL,'anonymousUser','2026-03-14 23:40:14','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:40:14',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(119,NULL,'anonymousUser','2026-03-14 23:41:36','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:41:36',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(120,NULL,'anonymousUser','2026-03-14 23:43:57','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:43:57',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(121,NULL,'anonymousUser','2026-03-14 23:43:59','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:43:59',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(122,NULL,'anonymousUser','2026-03-14 23:43:59','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:43:59',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(123,NULL,'anonymousUser','2026-03-14 23:45:45','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:45:45',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(124,NULL,'anonymousUser','2026-03-14 23:54:28','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:54:28',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(125,NULL,'admin','2026-03-14 23:54:29','admin','BACKUP','手动备份',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-14 23:54:29',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(126,NULL,'admin','2026-03-14 23:59:53','admin','BACKUP','手动备份',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-14 23:59:53',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(127,NULL,'anonymousUser','2026-03-15 00:25:31','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-15 00:25:31',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(128,NULL,'anonymousUser','2026-03-15 00:25:57','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-15 00:25:57',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(129,NULL,'anonymousUser','2026-03-15 00:28:37','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-15 00:28:37',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(130,NULL,'anonymousUser','2026-03-15 00:30:16','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-15 00:30:16',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(131,NULL,'anonymousUser','2026-03-15 00:42:40','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-15 00:42:40',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(132,NULL,'anonymousUser','2026-03-15 00:42:55','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-15 00:42:55',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(133,NULL,'anonymousUser','2026-03-15 18:43:47','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 18:43:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(134,NULL,'anonymousUser','2026-03-15 18:45:46','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 18:45:46',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(135,NULL,'anonymousUser','2026-03-15 18:47:48','anonymousUser','用户认证','登录失败: 密码错误(manager1)',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 18:47:48',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(136,NULL,'anonymousUser','2026-03-15 18:47:52','anonymousUser','用户认证','登录成功: manager1',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 18:47:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(137,NULL,'anonymousUser','2026-03-15 18:54:41','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 18:54:41',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(138,NULL,'anonymousUser','2026-03-15 19:02:15','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-15 19:02:15',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(139,NULL,'anonymousUser','2026-03-15 19:02:17','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-15 19:02:17',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(140,NULL,'anonymousUser','2026-03-15 19:10:05','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-15 19:10:05',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(141,NULL,'anonymousUser','2026-03-15 19:10:18','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-15 19:10:18',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(142,NULL,'anonymousUser','2026-03-15 19:12:33','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 19:12:33',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(143,NULL,'anonymousUser','2026-03-15 19:13:23','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 19:13:23',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(144,NULL,'anonymousUser','2026-03-15 20:53:37','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-15 20:53:37',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(145,NULL,'anonymousUser','2026-03-15 20:54:44','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-15 20:54:44',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(146,NULL,'anonymousUser','2026-03-15 20:55:11','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-15 20:55:11',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(147,NULL,'anonymousUser','2026-03-15 20:55:11','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-15 20:55:11',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(148,NULL,'anonymousUser','2026-03-15 20:57:10','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-15 20:57:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(149,NULL,'anonymousUser','2026-03-15 20:57:50','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-15 20:57:50',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(150,NULL,'anonymousUser','2026-03-15 21:07:02','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-15 21:07:02',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(151,NULL,'anonymousUser','2026-03-15 21:07:02','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-15 21:07:02',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(152,NULL,'anonymousUser','2026-03-15 21:07:02','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-15 21:07:02',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(153,NULL,'anonymousUser','2026-03-15 21:08:49','anonymousUser','用户认证','登录失败: 密码错误(manager1)',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 21:08:49',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(154,NULL,'anonymousUser','2026-03-15 21:08:52','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-15 21:08:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(155,NULL,'anonymousUser','2026-03-15 21:08:52','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-15 21:08:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(156,NULL,'anonymousUser','2026-03-15 21:08:52','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-15 21:08:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(157,NULL,'anonymousUser','2026-03-15 21:08:52','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-15 21:08:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(158,NULL,'anonymousUser','2026-03-15 21:08:55','anonymousUser','用户认证','登录失败: 密码错误(manager1)',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 21:08:55',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(159,NULL,'anonymousUser','2026-03-15 21:09:06','anonymousUser','用户认证','登录失败: 密码错误(manager1)',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 21:09:06',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(160,NULL,'anonymousUser','2026-03-15 21:09:08','anonymousUser','用户认证','登录失败: 密码错误(manager1)',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 21:09:08',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(161,NULL,'anonymousUser','2026-03-15 21:09:08','anonymousUser','用户认证','登录失败: 密码错误(manager1)',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 21:09:08',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(162,NULL,'anonymousUser','2026-03-15 21:09:10','anonymousUser','用户认证','登录失败: 密码错误(manager1)',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 21:09:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(163,NULL,'anonymousUser','2026-03-15 21:09:16','anonymousUser','用户认证','登录成功: manager1',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 21:09:16',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(164,NULL,'anonymousUser','2026-03-15 21:10:14','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 21:10:14',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(165,NULL,'anonymousUser','2026-03-15 21:27:50','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 21:27:50',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(166,NULL,'anonymousUser','2026-03-15 21:28:02','anonymousUser','用户认证','登录失败: 密码错误(manager1)',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 21:28:02',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(167,NULL,'anonymousUser','2026-03-15 21:28:06','anonymousUser','用户认证','登录失败: 密码错误(manager1)',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 21:28:06',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(168,NULL,'anonymousUser','2026-03-15 21:28:12','anonymousUser','用户认证','登录失败: 密码错误(manager1)',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 21:28:12',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(169,NULL,'anonymousUser','2026-03-15 21:28:19','anonymousUser','用户认证','登录失败: 密码错误(manager1)',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 21:28:19',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(170,NULL,'anonymousUser','2026-03-15 21:28:25','anonymousUser','用户认证','登录成功: manager1',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 21:28:25',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(171,NULL,'anonymousUser','2026-03-15 21:30:33','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 21:30:33',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(172,NULL,'anonymousUser','2026-03-15 21:33:30','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 21:33:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(173,NULL,'anonymousUser','2026-03-15 21:33:37','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 21:33:37',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(174,NULL,'anonymousUser','2026-03-15 21:33:49','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 21:33:49',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(175,NULL,'anonymousUser','2026-03-15 21:33:55','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 21:33:55',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(176,NULL,'anonymousUser','2026-03-15 21:34:02','anonymousUser','用户认证','登录失败: 密码错误(manager1)',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 21:34:02',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(177,NULL,'anonymousUser','2026-03-15 21:34:07','anonymousUser','用户认证','登录成功: manager1',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 21:34:07',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(178,NULL,'anonymousUser','2026-03-15 21:42:39','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-15 21:42:39',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(179,NULL,'anonymousUser','2026-03-15 21:42:57','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-15 21:42:57',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(180,NULL,'anonymousUser','2026-03-15 21:43:53','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-15 21:43:53',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(181,NULL,'anonymousUser','2026-03-15 21:44:03','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-15 21:44:03',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(182,NULL,'anonymousUser','2026-03-15 21:45:59','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 21:45:59',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(183,NULL,'anonymousUser','2026-03-15 21:48:18','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 21:48:18',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(184,NULL,'anonymousUser','2026-03-15 21:49:25','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-15 21:49:25',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(185,NULL,'anonymousUser','2026-03-16 23:25:17','anonymousUser','用户认证','登录成功: ai_test_admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-16 23:25:17',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(186,NULL,'ai_test_admin','2026-03-16 23:25:19','ai_test_admin','AI助手','自然语言指令执行',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-16 23:25:19','??101????1250.5,??3680','UNKNOWN','{}','FAILED','所有模型调用失败: primary: request timed out',2531,''),(187,NULL,'anonymousUser','2026-03-16 23:27:00','anonymousUser','用户认证','登录成功: ai_test_admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-16 23:27:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(188,NULL,'ai_test_admin','2026-03-16 23:27:15','ai_test_admin','AI助手','自然语言指令执行',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-16 23:27:15','??101????1250.5,??3680','UNKNOWN','{}','FAILED','所有模型调用失败: primary: request timed out',15031,''),(189,NULL,'anonymousUser','2026-03-16 23:29:00','anonymousUser','用户认证','登录成功: ai_test_admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-16 23:29:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(190,NULL,'ai_test_admin','2026-03-16 23:29:15','ai_test_admin','AI助手','自然语言指令执行',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-16 23:29:15','??101????1250.5,??3680','UNKNOWN','{}','FAILED','所有模型调用失败: primary: request timed out',15030,''),(191,NULL,'anonymousUser','2026-03-16 23:42:07','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-16 23:42:07',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(192,NULL,'admin','2026-03-16 23:42:08','admin','AI助手','自然语言指令执行',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-16 23:42:08','????????','UNKNOWN','{}','FAILED','所有模型调用失败: primary: 404 - {\"timestamp\":\"2026-03-16T15:42:05.839+00:00\",\"status\":404,\"error\":\"Not Found\",\"path\":\"/v4/v1/chat/completions\"}',816,''),(193,NULL,'anonymousUser','2026-03-16 23:47:54','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-16 23:47:54',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(194,NULL,'admin','2026-03-16 23:47:55','admin','AI助手','自然语言指令执行',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-16 23:47:55','????????','UNKNOWN','{}','FAILED','所有模型调用失败: primary: 429 - {\"error\":{\"code\":\"1302\",\"message\":\"您的账户已达到速率限制，请您控制请求频率\"}}',833,''),(195,NULL,'anonymousUser','2026-03-17 00:06:12','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-17 00:06:12',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(196,NULL,'anonymousUser','2026-03-17 00:06:23','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-17 00:06:23',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(197,NULL,'admin','2026-03-17 00:06:24','admin','AI助手','自然语言指令执行',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-17 00:06:24','????????','UNKNOWN','{}','FAILED','您好，有什么可以帮助您的吗？',1575,'siliconflow'),(198,NULL,'anonymousUser','2026-03-17 00:06:34','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-17 00:06:34',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(199,NULL,'admin','2026-03-17 00:06:38','admin','AI助手','自然语言指令执行',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-17 00:06:38','??101????1250.5,??3680','METER_READING','{\"date\":\"今天\",\"electric_reading\":3680.0,\"building_name\":\"未知\",\"water_reading\":1250.5,\"room_number\":\"101\"}','FAILED','未找到房间\"101\"。',4022,'siliconflow'),(200,NULL,'anonymousUser','2026-03-17 12:21:15','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-17 12:21:15',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(201,NULL,'anonymousUser','2026-03-17 12:22:01','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-17 12:22:01',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(202,NULL,'admin','2026-03-17 12:22:58','admin','AI助手','自然语言指令执行',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-17 12:22:58','今天A栋101房间的水电记录是120和120','METER_READING','{\"date\":\"今天\",\"electric_reading\":120.0,\"building_name\":\"A栋\",\"water_reading\":120.0,\"room_number\":\"101\"}','SUCCESS','房间 A栋101 水电读数录入成功（水：120.0，电：120.0）',4913,'siliconflow'),(203,NULL,'anonymousUser','2026-03-17 12:26:08','anonymousUser','用户认证','登录成功: manager1',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-17 12:26:08',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(204,NULL,'anonymousUser','2026-03-18 00:03:04','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 00:03:04',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(205,NULL,'anonymousUser','2026-03-18 00:03:13','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 00:03:13',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(206,NULL,'anonymousUser','2026-03-18 00:04:42','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 00:04:42',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(207,NULL,'anonymousUser','2026-03-18 00:06:07','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 00:06:07',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(208,NULL,'anonymousUser','2026-03-18 00:06:21','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 00:06:21',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(209,NULL,'anonymousUser','2026-03-18 00:11:51','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 00:11:51',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(210,NULL,'anonymousUser','2026-03-18 00:13:08','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 00:13:08',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(211,NULL,'anonymousUser','2026-03-18 00:13:28','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 00:13:28',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(212,NULL,'anonymousUser','2026-03-18 00:14:25','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 00:14:25',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(213,NULL,'anonymousUser','2026-03-18 11:06:21','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:06:21',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(214,NULL,'anonymousUser','2026-03-18 11:06:22','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:06:22',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(215,NULL,'anonymousUser','2026-03-18 11:06:32','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:06:32',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(216,NULL,'anonymousUser','2026-03-18 11:06:42','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:06:42',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(217,NULL,'anonymousUser','2026-03-18 11:06:56','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:06:56',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(218,NULL,'anonymousUser','2026-03-18 11:07:07','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:07:07',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(219,NULL,'anonymousUser','2026-03-18 11:08:09','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:08:09',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(220,NULL,'anonymousUser','2026-03-18 11:09:28','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:09:28',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(221,NULL,'anonymousUser','2026-03-18 11:09:29','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:09:29',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(222,NULL,'anonymousUser','2026-03-18 11:09:29','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:09:29',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(223,NULL,'anonymousUser','2026-03-18 11:09:42','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:09:42',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(224,NULL,'anonymousUser','2026-03-18 11:09:49','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:09:49',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(225,NULL,'anonymousUser','2026-03-18 11:10:46','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:10:46',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(226,NULL,'anonymousUser','2026-03-18 11:10:48','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:10:48',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(227,NULL,'anonymousUser','2026-03-18 11:10:48','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:10:48',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(228,NULL,'anonymousUser','2026-03-18 11:12:43','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:12:43',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(229,NULL,'anonymousUser','2026-03-18 11:12:44','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:12:44',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(230,NULL,'anonymousUser','2026-03-18 11:12:44','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:12:44',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(231,NULL,'anonymousUser','2026-03-18 11:12:59','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:12:59',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(232,NULL,'anonymousUser','2026-03-18 11:14:36','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:14:36',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(233,NULL,'anonymousUser','2026-03-18 11:15:58','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:15:58',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(234,NULL,'anonymousUser','2026-03-18 11:17:21','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:17:21',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(235,NULL,'anonymousUser','2026-03-18 11:22:23','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:22:23',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(236,NULL,'anonymousUser','2026-03-18 11:22:25','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:22:25',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(237,NULL,'anonymousUser','2026-03-18 11:28:41','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:28:41',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(238,NULL,'anonymousUser','2026-03-18 11:28:42','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:28:42',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(239,NULL,'anonymousUser','2026-03-18 11:29:02','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:29:02',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(240,NULL,'anonymousUser','2026-03-18 11:29:12','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:29:12',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(241,NULL,'anonymousUser','2026-03-18 11:29:13','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:29:13',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(242,NULL,'anonymousUser','2026-03-18 11:30:14','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:30:14',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(243,NULL,'anonymousUser','2026-03-18 11:40:33','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:40:33',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(244,NULL,'anonymousUser','2026-03-18 11:40:34','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 11:40:34',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(245,NULL,'anonymousUser','2026-03-18 13:17:34','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-18 13:17:34',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(246,NULL,'anonymousUser','2026-03-23 12:42:36','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 12:42:36',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(247,NULL,'anonymousUser','2026-03-23 12:42:54','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 12:42:54',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(248,NULL,'admin','2026-03-23 12:42:54','admin','操作恢复','恢复 账单管理 - 2026-02 / #68',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 12:42:54',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(249,NULL,'anonymousUser','2026-03-23 12:59:14','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 12:59:14',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(250,NULL,'anonymousUser','2026-03-23 12:59:46','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 12:59:46',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(251,NULL,'admin','2026-03-23 12:59:46','admin','操作恢复','恢复 账单管理 - 2026-02 / #68',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 12:59:46',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(252,NULL,'anonymousUser','2026-03-23 13:02:08','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 13:02:08',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(253,NULL,'anonymousUser','2026-03-23 13:09:24','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 13:09:24',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(254,NULL,'admin','2026-03-23 13:09:24','admin','操作恢复','恢复 账单管理 - 2026-02 / #68',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 13:09:24',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(255,NULL,'anonymousUser','2026-03-23 13:12:53','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 13:12:53',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(256,NULL,'admin','2026-03-23 13:12:53','admin','操作恢复','恢复 账单管理 - 2026-02 / #68',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 13:12:53',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(257,NULL,'anonymousUser','2026-03-23 13:14:43','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 13:14:43',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(258,NULL,'admin','2026-03-23 13:14:43','admin','投诉管理','创建投诉: CP20260323131443980',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 13:14:43',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(259,NULL,'admin','2026-03-23 13:14:43','admin','投诉管理','受理投诉: CP20260323131443980',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 13:14:43',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(260,NULL,'admin','2026-03-23 13:14:43','admin','投诉管理','回复投诉: CP20260323131443980',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 13:14:43',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(261,NULL,'admin','2026-03-23 13:14:43','admin','投诉管理','完成投诉处理: CP20260323131443980',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 13:14:43',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(262,NULL,'admin','2026-03-23 13:14:43','admin','投诉管理','确认完成投诉: CP20260323131443980',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 13:14:43',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(263,NULL,'anonymousUser','2026-03-23 13:14:53','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 13:14:53',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(264,NULL,'admin','2026-03-23 13:14:53','admin','投诉管理','创建投诉: CP20260323131453807',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 13:14:53',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(265,NULL,'admin','2026-03-23 13:14:53','admin','投诉管理','受理投诉: CP20260323131453807',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 13:14:53',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(266,NULL,'admin','2026-03-23 13:14:53','admin','投诉管理','回复投诉: CP20260323131453807',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 13:14:53',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(267,NULL,'admin','2026-03-23 13:14:53','admin','投诉管理','完成投诉处理: CP20260323131453807',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 13:14:53',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(268,NULL,'admin','2026-03-23 13:14:53','admin','投诉管理','确认完成投诉: CP20260323131453807',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 13:14:53',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(269,NULL,'anonymousUser','2026-03-23 13:23:33','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 13:23:33',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(270,NULL,'admin','2026-03-23 13:23:33','admin','操作恢复','恢复 账单管理 - 2026-02 / #68',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 13:23:33',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(271,NULL,'anonymousUser','2026-03-23 13:23:49','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 13:23:49',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(272,NULL,'admin','2026-03-23 13:23:49','admin','投诉管理','创建投诉: CP20260323132348931',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 13:23:49',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(273,NULL,'admin','2026-03-23 13:23:49','admin','投诉管理','受理投诉: CP20260323132348931',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 13:23:49',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(274,NULL,'admin','2026-03-23 13:23:49','admin','投诉管理','回复投诉: CP20260323132348931',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 13:23:49',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(275,NULL,'admin','2026-03-23 13:23:49','admin','投诉管理','完成投诉处理: CP20260323132348931',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 13:23:49',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(276,NULL,'admin','2026-03-23 13:23:49','admin','投诉管理','确认完成投诉: CP20260323132348931',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 13:23:49',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(277,NULL,'anonymousUser','2026-03-23 15:01:49','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:01:49',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(278,NULL,'admin','2026-03-23 15:01:50','admin','操作恢复','恢复 账单管理 - 2026-02 / #68',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:01:50',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(279,NULL,'anonymousUser','2026-03-23 15:04:28','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:04:28',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(280,NULL,'anonymousUser','2026-03-23 15:04:35','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:04:35',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(281,NULL,'anonymousUser','2026-03-23 15:04:41','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:04:41',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(282,NULL,'anonymousUser','2026-03-23 15:04:57','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:04:57',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(283,NULL,'anonymousUser','2026-03-23 15:05:04','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:05:04',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(284,NULL,'anonymousUser','2026-03-23 15:05:25','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:05:25',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(285,NULL,'anonymousUser','2026-03-23 15:06:04','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:06:04',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(286,NULL,'anonymousUser','2026-03-23 15:06:32','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:06:32',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(287,NULL,'anonymousUser','2026-03-23 15:06:41','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:06:41',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(288,NULL,'anonymousUser','2026-03-23 15:12:20','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:12:20',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(289,NULL,'anonymousUser','2026-03-23 15:14:02','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:14:02',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(290,NULL,'anonymousUser','2026-03-23 15:18:30','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:18:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(291,NULL,'admin','2026-03-23 15:18:30','admin','操作恢复','恢复 账单管理 - 2026-02 / #68',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:18:30',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(292,NULL,'anonymousUser','2026-03-23 15:18:57','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:18:57',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(293,NULL,'admin','2026-03-23 15:18:58','admin','投诉管理','受理投诉: CP1774250292696',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:18:58',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(294,NULL,'admin','2026-03-23 15:18:58','admin','投诉管理','回复投诉: CP1774250292696',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:18:58',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(295,NULL,'admin','2026-03-23 15:18:58','admin','投诉管理','完成投诉处理: CP1774250292696',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:18:58',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(296,NULL,'admin','2026-03-23 15:18:58','admin','投诉管理','确认完成投诉: CP1774250292696',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:18:58',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(297,NULL,'anonymousUser','2026-03-23 15:25:50','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:25:50',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(298,NULL,'anonymousUser','2026-03-23 15:35:58','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:35:58',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(299,NULL,'anonymousUser','2026-03-23 15:39:16','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:39:16',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(300,NULL,'anonymousUser','2026-03-23 15:39:31','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:39:31',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(301,NULL,'anonymousUser','2026-03-23 15:39:49','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:39:49',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(302,NULL,'anonymousUser','2026-03-23 15:40:08','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:40:08',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(303,NULL,'anonymousUser','2026-03-23 15:40:49','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:40:49',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(304,NULL,'anonymousUser','2026-03-23 15:41:05','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:41:05',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(305,NULL,'anonymousUser','2026-03-23 15:41:17','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:41:17',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(306,NULL,'anonymousUser','2026-03-23 15:41:39','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:41:39',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(307,NULL,'anonymousUser','2026-03-23 15:44:33','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:44:33',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(308,NULL,'anonymousUser','2026-03-23 15:46:15','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:46:15',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(309,NULL,'anonymousUser','2026-03-23 15:46:47','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-23 15:46:47',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(310,NULL,'anonymousUser','2026-03-26 21:50:10','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 21:50:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(311,NULL,'anonymousUser','2026-03-26 21:52:43','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-26 21:52:43',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(312,NULL,'admin','2026-03-26 21:56:29','admin','AI助手','自然语言指令执行',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-26 21:56:29','今天A栋101水表1250.5电表3680，A栋102水表1312.3电表3725, B栋303水表10电表10','METER_READING','{\"date\":null,\"building_name\":null,\"records\":[{\"roomNumber\":\"A栋101\",\"waterReading\":1250.5,\"electricReading\":3680,\"date\":\"今天\",\"buildingName\":\"A栋\"},{\"roomNumber\":\"A栋102\",\"waterReading\":1312.3,\"electricReading\":3725,\"date\":\"今天\",\"buildingName\":\"A栋\"},{\"roomNumber\":\"B栋303\",\"waterReading\":10,\"electricReading\":10,\"date\":\"今天\",\"buildingName\":\"B栋\"}]}','FAILED','未找到房间\"A栋101\"。',5703,'siliconflow'),(313,NULL,'admin','2026-03-26 21:56:52','admin','AI助手','自然语言指令执行',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-26 21:56:52','今天A栋101水表1250.5电表3680，A栋102水表1312.3电表3725, B栋303水表10电表10','METER_READING','{\"date\":\"今天\",\"building_name\":\"A栋,B栋\",\"records\":[{\"roomNumber\":\"A栋101\",\"waterReading\":1250.5,\"electricReading\":3680},{\"roomNumber\":\"A栋102\",\"waterReading\":1312.3,\"electricReading\":3725},{\"roomNumber\":\"B栋303\",\"waterReading\":10,\"electricReading\":10}]}','FAILED','未找到房间\"A栋101\"。',3288,'siliconflow'),(314,NULL,'admin','2026-03-26 21:57:10','admin','AI助手','自然语言指令执行',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-26 21:57:10','今天A栋101水表1250.5电表3680，A栋102水表1312.3电表3725, B栋303水表10电表10','METER_READING','{\"date\":\"今天\",\"building_name\":\"A栋,B栋\",\"records\":[{\"roomNumber\":\"A栋101\",\"waterReading\":1250.5,\"electricReading\":3680},{\"roomNumber\":\"A栋102\",\"waterReading\":1312.3,\"electricReading\":3725},{\"roomNumber\":\"B栋303\",\"waterReading\":10,\"electricReading\":10}]}','FAILED','未找到房间\"A栋101\"。',3672,'siliconflow'),(315,NULL,'admin','2026-03-26 22:02:41','admin','AI助手','自然语言指令执行',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-26 22:02:41','今天A栋101水表1250.5电表3680，A栋102水表1312.3电表3725, B栋303水表10电表10','METER_READING','{\"date\":null,\"building_name\":null,\"records\":[{\"roomNumber\":\"101\",\"waterReading\":1250.5,\"electricReading\":3680,\"date\":\"今天\",\"buildingName\":\"A栋\"},{\"roomNumber\":\"102\",\"waterReading\":1312.3,\"electricReading\":3725,\"date\":\"今天\",\"buildingName\":\"A栋\"},{\"roomNumber\":\"303\",\"waterReading\":10,\"electricReading\":10,\"date\":\"今天\",\"buildingName\":\"B栋\"}]}','FAILED','未找到房间\"102\"。',5506,'siliconflow'),(316,NULL,'admin','2026-03-26 22:03:00','admin','AI助手','自然语言指令执行',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-26 22:03:00','今天A栋101水表1250.5电表3680，A栋102水表1312.3电表3725, B栋303水表10电表10','METER_READING','{\"date\":null,\"building_name\":null,\"records\":[{\"roomNumber\":\"101\",\"waterReading\":1250.5,\"electricReading\":3680,\"date\":\"今天\",\"buildingName\":\"A栋\"},{\"roomNumber\":\"102\",\"waterReading\":1312.3,\"electricReading\":3725,\"date\":\"今天\",\"buildingName\":\"A栋\"},{\"roomNumber\":\"303\",\"waterReading\":10,\"electricReading\":10,\"date\":\"今天\",\"buildingName\":\"B栋\"}]}','FAILED','未找到房间\"102\"。',2612,'siliconflow'),(317,NULL,'admin','2026-03-26 22:03:14','admin','AI助手','自然语言指令执行',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-26 22:03:14','今天A栋101水表1250.5电表3680，A栋202水表1312.3电表3725, B栋303水表10电表10','METER_READING','{\"date\":null,\"building_name\":null,\"records\":[{\"roomNumber\":\"101\",\"waterReading\":1250.5,\"electricReading\":3680,\"date\":\"今天\",\"buildingName\":\"A栋\"},{\"roomNumber\":\"202\",\"waterReading\":1312.3,\"electricReading\":3725,\"date\":\"今天\",\"buildingName\":\"A栋\"},{\"roomNumber\":\"303\",\"waterReading\":10,\"electricReading\":10,\"date\":\"今天\",\"buildingName\":\"B栋\"}]}','FAILED','未找到房间\"303\"。',4377,'siliconflow'),(318,NULL,'admin','2026-03-26 22:03:41','admin','AI助手','自然语言指令执行',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-26 22:03:41','今天A栋101水表1250.5电表3680，A栋102水表1312.3电表3725, B栋303水表10电表10','METER_READING','{\"date\":null,\"building_name\":null,\"records\":[{\"roomNumber\":\"A栋101\",\"waterReading\":1250.5,\"electricReading\":3680,\"date\":\"今天\",\"buildingName\":\"A栋\"},{\"roomNumber\":\"A栋102\",\"waterReading\":1312.3,\"electricReading\":3725,\"date\":\"今天\",\"buildingName\":\"A栋\"},{\"roomNumber\":\"B栋303\",\"waterReading\":10,\"electricReading\":10,\"date\":\"今天\",\"buildingName\":\"B栋\"}]}','FAILED','未找到房间\"A栋101\"。',6612,'siliconflow'),(319,NULL,'admin','2026-03-26 22:03:49','admin','AI助手','自然语言指令执行',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-26 22:03:49','今天A栋101水表1250.5电表3680，A栋102水表1312.3电表3725, B栋303水表10电表10','METER_READING','{\"date\":null,\"building_name\":null,\"records\":[{\"roomNumber\":\"101\",\"waterReading\":1250.5,\"electricReading\":3680,\"date\":\"今天\",\"buildingName\":\"A栋\"},{\"roomNumber\":\"102\",\"waterReading\":1312.3,\"electricReading\":3725,\"date\":\"今天\",\"buildingName\":\"A栋\"},{\"roomNumber\":\"303\",\"waterReading\":10,\"electricReading\":10,\"date\":\"今天\",\"buildingName\":\"B栋\"}]}','FAILED','未找到房间\"102\"。',5409,'siliconflow'),(320,NULL,'admin','2026-03-26 22:04:25','admin','操作恢复','恢复 房屋管理 - A栋',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-26 22:04:25',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(321,NULL,'admin','2026-03-26 22:10:14','admin','操作恢复','恢复 房屋管理 - 12',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-26 22:10:14',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(322,NULL,'admin','2026-03-26 22:10:24','admin','操作恢复','恢复 房屋管理 - 12',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-26 22:10:24',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(323,NULL,'anonymousUser','2026-03-26 22:12:43','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 22:12:43',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(324,NULL,'anonymousUser','2026-03-26 22:14:12','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 22:14:12',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(325,NULL,'admin','2026-03-26 22:16:06','admin','操作恢复','恢复 房屋管理 - A栋',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-26 22:16:06',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(326,NULL,'admin','2026-03-26 22:16:53','admin','AI助手','自然语言指令执行',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-26 22:16:53','今天A栋101水表1250.5电表3680，A栋102水表1312.3电表3725, B栋303水表10电表10','METER_READING','{\"date\":\"今天\",\"building_name\":\"A栋,B栋\",\"records\":[{\"roomNumber\":\"A栋101\",\"waterReading\":1250.5,\"electricReading\":3680},{\"roomNumber\":\"A栋102\",\"waterReading\":1312.3,\"electricReading\":3725},{\"roomNumber\":\"B栋303\",\"waterReading\":10,\"electricReading\":10}]}','FAILED','未找到房间\"A栋101\"。',6629,'siliconflow'),(327,NULL,'admin','2026-03-26 22:17:00','admin','AI助手','自然语言指令执行',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-26 22:17:00','今天A栋101水表1250.5电表3680，A栋102水表1312.3电表3725, B栋303水表10电表10','METER_READING','{\"date\":\"今天\",\"building_name\":\"A栋,B栋\",\"records\":[{\"roomNumber\":\"A栋101\",\"waterReading\":1250.5,\"electricReading\":3680},{\"roomNumber\":\"A栋102\",\"waterReading\":1312.3,\"electricReading\":3725},{\"roomNumber\":\"B栋303\",\"waterReading\":10,\"electricReading\":10}]}','FAILED','未找到房间\"A栋101\"。',3965,'siliconflow'),(328,NULL,'admin','2026-03-26 22:19:03','admin','操作恢复','恢复 房屋管理 - 12',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-26 22:19:03',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(329,NULL,'anonymousUser','2026-03-26 22:27:46','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 22:27:46',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(330,NULL,'anonymousUser','2026-03-26 22:33:43','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 22:33:43',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(331,NULL,'admin','2026-03-26 22:35:27','admin','维修管理','分配维修工: RE1774535709365 -> ?????A',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-26 22:35:27',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(332,NULL,'admin','2026-03-26 22:36:24','admin','投诉管理','受理投诉: CP1774535748645',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-26 22:36:24',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(333,NULL,'admin','2026-03-26 22:36:36','admin','投诉管理','完成投诉处理: CP1774535748645',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-26 22:36:36',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(334,NULL,'admin','2026-03-26 22:38:06','admin','AI助手','自然语言指令执行',NULL,NULL,NULL,NULL,NULL,'127.0.0.1',NULL,NULL,1,NULL,NULL,1,'127.0.0.1','2026-03-26 22:38:06','今天A栋101水表1250.5电表3680，A栋202水表1312.3电表3725, B栋303水表10电表10','METER_READING','{\"date\":\"今天\",\"building_name\":\"A栋\",\"records\":[{\"roomNumber\":\"101\",\"waterReading\":1250.5,\"electricReading\":3680},{\"roomNumber\":\"202\",\"waterReading\":1312.3,\"electricReading\":3725}]}','SUCCESS','已批量录入2条水电读数（示例：A栋101、A栋202）。',5072,'siliconflow'),(335,NULL,'anonymousUser','2026-03-26 22:53:36','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 22:53:36',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(336,NULL,'anonymousUser','2026-03-26 22:55:37','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 22:55:37',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(337,NULL,'anonymousUser','2026-03-26 22:56:41','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 22:56:41',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(338,NULL,'anonymousUser','2026-03-26 22:57:13','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 22:57:13',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(339,NULL,'anonymousUser','2026-03-26 22:57:39','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 22:57:39',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(340,NULL,'anonymousUser','2026-03-26 22:57:59','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 22:57:59',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(341,NULL,'anonymousUser','2026-03-26 23:07:35','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:07:35',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(342,NULL,'anonymousUser','2026-03-26 23:08:26','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:08:26',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(343,NULL,'anonymousUser','2026-03-26 23:09:29','anonymousUser','用户认证','登录成功: admin',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:09:29',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(344,NULL,'anonymousUser','2026-03-26 23:12:10','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:12:10',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(345,NULL,'anonymousUser','2026-03-26 23:12:35','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:12:35',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(346,NULL,'anonymousUser','2026-03-26 23:12:35','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:12:35',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(347,NULL,'anonymousUser','2026-03-26 23:12:35','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:12:35',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(348,NULL,'anonymousUser','2026-03-26 23:12:35','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:12:35',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(349,NULL,'anonymousUser','2026-03-26 23:12:35','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:12:35',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(350,NULL,'anonymousUser','2026-03-26 23:12:35','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:12:35',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(351,NULL,'anonymousUser','2026-03-26 23:12:35','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:12:35',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(352,NULL,'anonymousUser','2026-03-26 23:12:35','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:12:35',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(353,NULL,'anonymousUser','2026-03-26 23:12:35','anonymousUser','用户认证','登录失败: 密码错误(manager1)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:12:35',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(354,NULL,'anonymousUser','2026-03-26 23:12:35','anonymousUser','用户认证','登录失败: 密码错误(manager1)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:12:35',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(355,NULL,'anonymousUser','2026-03-26 23:12:36','anonymousUser','用户认证','登录成功: manager1',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:12:36',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(356,NULL,'anonymousUser','2026-03-26 23:12:51','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:12:51',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(357,NULL,'anonymousUser','2026-03-26 23:12:51','anonymousUser','用户认证','登录成功: manager1',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:12:51',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(358,NULL,'anonymousUser','2026-03-26 23:13:08','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:13:08',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(359,NULL,'anonymousUser','2026-03-26 23:13:08','anonymousUser','用户认证','登录失败: 密码错误(manager1)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:13:08',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(360,NULL,'anonymousUser','2026-03-26 23:13:50','anonymousUser','用户认证','登录失败: 密码错误(manager1)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:13:50',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(361,NULL,'anonymousUser','2026-03-26 23:13:59','anonymousUser','用户认证','登录失败: 密码错误(manager1)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:13:59',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(362,NULL,'anonymousUser','2026-03-26 23:14:00','anonymousUser','用户认证','登录失败: 密码错误(manager1)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:14:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(363,NULL,'anonymousUser','2026-03-26 23:14:00','anonymousUser','用户认证','登录失败: 密码错误(manager1)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:14:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(364,NULL,'anonymousUser','2026-03-26 23:14:00','anonymousUser','用户认证','登录失败: 密码错误(manager1)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:14:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(365,NULL,'anonymousUser','2026-03-26 23:14:00','anonymousUser','用户认证','登录失败: 密码错误(manager1)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:14:00',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(366,NULL,'anonymousUser','2026-03-26 23:14:23','anonymousUser','用户认证','登录失败: 密码错误(manager1)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:14:23',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(367,NULL,'anonymousUser','2026-03-26 23:14:52','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:14:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(368,NULL,'anonymousUser','2026-03-26 23:14:52','anonymousUser','用户认证','登录失败: 密码错误(manager1)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:14:52',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(369,NULL,'anonymousUser','2026-03-26 23:20:01','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:20:01',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(370,NULL,'anonymousUser','2026-03-26 23:20:42','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:20:42',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(371,NULL,'anonymousUser','2026-03-26 23:20:42','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:20:42',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(372,NULL,'anonymousUser','2026-03-26 23:20:42','anonymousUser','用户认证','登录失败: 密码错误(manager1)',NULL,NULL,NULL,NULL,NULL,'0:0:0:0:0:0:0:1',NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:20:42',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(373,NULL,NULL,'2026-03-26 23:51:23','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-26 23:51:23',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(374,NULL,NULL,'2026-03-27 00:00:56','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-27 00:00:56',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(375,NULL,NULL,'2026-03-27 00:00:57','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-27 00:00:57',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(376,NULL,NULL,'2026-03-27 00:00:57','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-27 00:00:57',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(377,NULL,NULL,'2026-03-27 00:00:57','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-27 00:00:57',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(378,NULL,NULL,'2026-03-27 00:00:57','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-27 00:00:57',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(379,NULL,NULL,'2026-03-27 00:00:57','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-27 00:00:57',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(380,NULL,NULL,'2026-03-27 00:00:57','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-27 00:00:57',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(381,NULL,NULL,'2026-03-27 00:00:57','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-27 00:00:57',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(382,NULL,NULL,'2026-03-27 00:00:57','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-27 00:00:57',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(383,NULL,NULL,'2026-03-27 00:02:34','anonymousUser','用户认证','登录失败: 密码错误(admin)',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-27 00:02:34',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(384,NULL,NULL,'2026-03-27 00:02:34','anonymousUser','用户认证','登录失败: 密码错误(manager1)',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,NULL,1,'0:0:0:0:0:0:0:1','2026-03-27 00:02:34',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(385,NULL,'anonymousUser','2026-03-27 00:05:17','anonymousUser','auth','login','1','admin',NULL,NULL,'登录失败: 密码错误(admin)','0:0:0:0:0:0:0:1','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) WindowsPowerShell/5.1.26100.7920','{\"username\":\"admin\",\"password\":\"admin123\"}',0,'密码错误',NULL,3,'0:0:0:0:0:0:0:1','2026-03-27 00:05:17',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(386,NULL,'anonymousUser','2026-03-27 13:15:21','anonymousUser','auth','login','1','admin',NULL,NULL,'登录失败: 密码错误(admin)','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0 SLBrowser/9.0.7.12011 SLBChan/10 SLBVPV/64-bit','{\"username\":\"admin\",\"password\":\"admin123\"}',0,'密码错误',NULL,3,'127.0.0.1','2026-03-27 13:15:21',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(387,NULL,'anonymousUser','2026-03-27 13:15:25','anonymousUser','auth','login','1','admin',NULL,NULL,'登录失败: 密码错误(admin)','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0 SLBrowser/9.0.7.12011 SLBChan/10 SLBVPV/64-bit','{\"username\":\"admin\",\"password\":\"admin123\"}',0,'密码错误',NULL,3,'127.0.0.1','2026-03-27 13:15:25',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(388,NULL,'anonymousUser','2026-03-27 13:15:31','anonymousUser','auth','login','1','admin',NULL,NULL,'登录失败: 密码错误(admin)','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0 SLBrowser/9.0.7.12011 SLBChan/10 SLBVPV/64-bit','{\"username\":\"admin\",\"password\":\"admin123\"}',0,'密码错误',NULL,3,'127.0.0.1','2026-03-27 13:15:31',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(389,NULL,'anonymousUser','2026-03-27 13:15:40','anonymousUser','auth','login','1','admin',NULL,NULL,'登录失败: 密码错误(admin)','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0 SLBrowser/9.0.7.12011 SLBChan/10 SLBVPV/64-bit','{\"username\":\"admin\",\"password\":\"admin123\"}',0,'密码错误',NULL,3,'127.0.0.1','2026-03-27 13:15:40',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(390,NULL,'anonymousUser','2026-03-27 13:16:20','anonymousUser','auth','login','2','manager1',NULL,NULL,'登录失败: 密码错误(manager1)','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0 SLBrowser/9.0.7.12011 SLBChan/10 SLBVPV/64-bit','{\"username\":\"manager1\",\"password\":\"admin123\"}',0,'密码错误',NULL,3,'127.0.0.1','2026-03-27 13:16:20',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(391,NULL,'anonymousUser','2026-03-27 13:16:23','anonymousUser','auth','login','2','manager1',NULL,NULL,'登录失败: 密码错误(manager1)','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0 SLBrowser/9.0.7.12011 SLBChan/10 SLBVPV/64-bit','{\"username\":\"manager1\",\"password\":\"123456\"}',0,'密码错误',NULL,3,'127.0.0.1','2026-03-27 13:16:23',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(392,NULL,'anonymousUser','2026-03-27 13:16:24','anonymousUser','auth','login','2','manager1',NULL,NULL,'登录失败: 密码错误(manager1)','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0 SLBrowser/9.0.7.12011 SLBChan/10 SLBVPV/64-bit','{\"username\":\"manager1\",\"password\":\"123456\"}',0,'密码错误',NULL,3,'127.0.0.1','2026-03-27 13:16:24',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(393,NULL,'anonymousUser','2026-03-27 13:16:27','anonymousUser','auth','login','2','manager1',NULL,NULL,'登录失败: 密码错误(manager1)','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0 SLBrowser/9.0.7.12011 SLBChan/10 SLBVPV/64-bit','{\"username\":\"manager1\",\"password\":\"admin123\"}',0,'密码错误',NULL,3,'127.0.0.1','2026-03-27 13:16:27',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(394,NULL,'anonymousUser','2026-03-27 13:18:28','anonymousUser','auth','login','2','manager1',NULL,NULL,'登录失败: 密码错误(manager1)','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0 SLBrowser/9.0.7.12011 SLBChan/10 SLBVPV/64-bit','{\"username\":\"manager1\",\"password\":\"admin123\"}',0,'密码错误',NULL,3,'127.0.0.1','2026-03-27 13:18:28',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(395,NULL,'anonymousUser','2026-03-27 13:18:46','anonymousUser','auth','login','1','admin',NULL,NULL,'登录失败: 密码错误(admin)','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) WindowsPowerShell/5.1.26100.7920','{\"username\":\"admin\",\"password\":\"admin123\"}',0,'密码错误',NULL,3,'127.0.0.1','2026-03-27 13:18:46',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(396,NULL,'anonymousUser','2026-03-27 13:18:46','anonymousUser','auth','login','2','manager1',NULL,NULL,'登录失败: 密码错误(manager1)','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) WindowsPowerShell/5.1.26100.7920','{\"username\":\"manager1\",\"password\":\"admin123\"}',0,'密码错误',NULL,3,'127.0.0.1','2026-03-27 13:18:46',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(397,NULL,'anonymousUser','2026-03-27 13:19:39','anonymousUser','auth','login','1','admin',NULL,NULL,'登录成功: admin','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) WindowsPowerShell/5.1.26100.7920','{\"username\":\"admin\",\"password\":\"admin123\"}',1,NULL,NULL,1,'127.0.0.1','2026-03-27 13:19:39',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(398,NULL,'anonymousUser','2026-03-27 13:19:39','anonymousUser','auth','login','2','manager1',NULL,NULL,'登录成功: manager1','127.0.0.1','Mozilla/5.0 (Windows NT; Windows NT 10.0; zh-CN) WindowsPowerShell/5.1.26100.7920','{\"username\":\"manager1\",\"password\":\"admin123\"}',1,NULL,NULL,1,'127.0.0.1','2026-03-27 13:19:39',NULL,NULL,NULL,NULL,NULL,NULL,NULL),(399,NULL,'anonymousUser','2026-03-27 13:24:43','anonymousUser','auth','login','1','admin',NULL,NULL,'登录成功: admin','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/146.0.0.0 Safari/537.36 Edg/146.0.0.0 SLBrowser/9.0.7.12011 SLBChan/10 SLBVPV/64-bit','{\"username\":\"admin\",\"password\":\"admin123\"}',1,NULL,NULL,1,'127.0.0.1','2026-03-27 13:24:43',NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `operation_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operation_log_archive`
--

DROP TABLE IF EXISTS `operation_log_archive`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `operation_log_archive` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '日志ID',
  `user_id` bigint DEFAULT NULL COMMENT '鎿嶄綔鐢ㄦ埛ID',
  `username` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '鐢ㄦ埛鍚',
  `operation_time` datetime NOT NULL COMMENT '操作时间',
  `operator` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '操作人',
  `module` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '模块',
  `action` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '操作内容',
  `business_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '涓氬姟瀵硅薄ID',
  `business_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '涓氬姟瀵硅薄鍚嶇О',
  `detail_before` json DEFAULT NULL COMMENT '鎿嶄綔鍓嶅揩鐓',
  `detail_after` json DEFAULT NULL COMMENT '鎿嶄綔鍚庡揩鐓',
  `change_summary` text COLLATE utf8mb4_unicode_ci COMMENT '鍙樻洿鎽樿?',
  `request_ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '璇锋眰IP',
  `user_agent` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'UserAgent',
  `request_params` text COLLATE utf8mb4_unicode_ci COMMENT '璇锋眰鍙傛暟',
  `result` tinyint NOT NULL DEFAULT '1' COMMENT '1鎴愬姛0澶辫触',
  `fail_reason` text COLLATE utf8mb4_unicode_ci COMMENT '澶辫触鍘熷洜',
  `duration_ms` int DEFAULT NULL COMMENT '鑰楁椂姣??',
  `log_level` tinyint NOT NULL DEFAULT '1' COMMENT '1-INFO 2-WARN 3-ERROR',
  `ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'IP地址',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `ai_instruction` text COLLATE utf8mb4_unicode_ci COMMENT 'AI原始指令',
  `ai_intent` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'AI解析意图',
  `ai_entities` text COLLATE utf8mb4_unicode_ci COMMENT 'AI解析实体JSON',
  `ai_status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'AI执行状态',
  `ai_response_message` text COLLATE utf8mb4_unicode_ci COMMENT 'AI返回消息',
  `ai_duration_ms` bigint DEFAULT NULL COMMENT 'AI执行耗时ms',
  `ai_model_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'AI模型名称',
  PRIMARY KEY (`id`),
  KEY `idx_operation_time_module` (`operation_time`,`module`),
  KEY `idx_log_created_module_action` (`created_at`,`module`,`action`),
  KEY `idx_log_business_id` (`business_id`),
  KEY `idx_log_user_time` (`username`,`operation_time`),
  KEY `idx_log_level_result_duration` (`log_level`,`result`,`duration_ms`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='操作日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operation_log_archive`
--

LOCK TABLES `operation_log_archive` WRITE;
/*!40000 ALTER TABLE `operation_log_archive` DISABLE KEYS */;
/*!40000 ALTER TABLE `operation_log_archive` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operation_snapshot`
--

DROP TABLE IF EXISTS `operation_snapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `operation_snapshot` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `module` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `operation` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_id` bigint DEFAULT NULL,
  `target_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `table_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `before_data` json DEFAULT NULL,
  `after_data` json DEFAULT NULL,
  `is_recovered` tinyint(1) NOT NULL DEFAULT '0',
  `expired_at` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `recovered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_snapshot_created` (`created_at`),
  KEY `idx_snapshot_expired` (`expired_at`),
  KEY `idx_snapshot_target` (`table_name`,`target_id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operation_snapshot`
--

LOCK TABLES `operation_snapshot` WRITE;
/*!40000 ALTER TABLE `operation_snapshot` DISABLE KEYS */;
INSERT INTO `operation_snapshot` VALUES (2,NULL,'admin','账单管理','void',64,'2026-02 / #64','bill','{\"id\": 64, \"roomId\": 1, \"status\": \"PENDING\", \"deleted\": null, \"payments\": null, \"billMonth\": \"2026-02\", \"contractId\": 2, \"createTime\": null, \"paidAmount\": null, \"roomNumber\": \"101\", \"tenantName\": \"ZhangSan\", \"waterUsage\": null, \"tenantPhone\": \"12345678911\", \"totalAmount\": 10.0, \"buildingName\": \"A栋\", \"electricUsage\": null, \"generatedDate\": \"2026-03-13T17:57:14\", \"waterUnitPrice\": null, \"currWaterReading\": null, \"prevWaterReading\": null, \"electricUnitPrice\": null, \"currElectricReading\": null, \"prevElectricReading\": null}','{\"id\": 64, \"roomId\": 1, \"status\": \"VOID\", \"deleted\": null, \"payments\": null, \"billMonth\": \"2026-02\", \"contractId\": 2, \"createTime\": null, \"paidAmount\": null, \"roomNumber\": \"101\", \"tenantName\": \"ZhangSan\", \"waterUsage\": null, \"tenantPhone\": \"12345678911\", \"totalAmount\": 10.0, \"buildingName\": \"A栋\", \"electricUsage\": null, \"generatedDate\": \"2026-03-13T17:57:14\", \"waterUnitPrice\": null, \"currWaterReading\": null, \"prevWaterReading\": null, \"electricUnitPrice\": null, \"currElectricReading\": null, \"prevElectricReading\": null}',1,'2026-03-13 18:40:32','2026-03-13 18:10:32','2026-03-13 18:10:32'),(3,NULL,'admin','账单管理','void',64,'2026-02 / #64','bill','{\"id\": 64, \"roomId\": 1, \"status\": \"PENDING\", \"deleted\": null, \"payments\": null, \"billMonth\": \"2026-02\", \"contractId\": 2, \"createTime\": null, \"paidAmount\": null, \"roomNumber\": \"101\", \"tenantName\": \"ZhangSan\", \"waterUsage\": null, \"tenantPhone\": \"12345678911\", \"totalAmount\": 10.0, \"buildingName\": \"A栋\", \"electricUsage\": null, \"generatedDate\": \"2026-03-13T17:57:14\", \"waterUnitPrice\": null, \"currWaterReading\": null, \"prevWaterReading\": null, \"electricUnitPrice\": null, \"currElectricReading\": null, \"prevElectricReading\": null}','{\"id\": 64, \"roomId\": 1, \"status\": \"VOID\", \"deleted\": null, \"payments\": null, \"billMonth\": \"2026-02\", \"contractId\": 2, \"createTime\": null, \"paidAmount\": null, \"roomNumber\": \"101\", \"tenantName\": \"ZhangSan\", \"waterUsage\": null, \"tenantPhone\": \"12345678911\", \"totalAmount\": 10.0, \"buildingName\": \"A栋\", \"electricUsage\": null, \"generatedDate\": \"2026-03-13T17:57:14\", \"waterUnitPrice\": null, \"currWaterReading\": null, \"prevWaterReading\": null, \"electricUnitPrice\": null, \"currElectricReading\": null, \"prevElectricReading\": null}',1,'2026-03-13 18:41:15','2026-03-13 18:11:15','2026-03-13 18:11:15'),(4,NULL,'admin','账单管理','void',64,'2026-02 / #64','bill','{\"id\": 64, \"roomId\": 1, \"status\": \"PENDING\", \"deleted\": null, \"payments\": null, \"billMonth\": \"2026-02\", \"contractId\": 2, \"createTime\": null, \"paidAmount\": null, \"roomNumber\": \"101\", \"tenantName\": \"ZhangSan\", \"waterUsage\": null, \"tenantPhone\": \"12345678911\", \"totalAmount\": 10.0, \"buildingName\": \"A栋\", \"electricUsage\": null, \"generatedDate\": \"2026-03-13T17:57:14\", \"waterUnitPrice\": null, \"currWaterReading\": null, \"prevWaterReading\": null, \"electricUnitPrice\": null, \"currElectricReading\": null, \"prevElectricReading\": null}','{\"id\": 64, \"roomId\": 1, \"status\": \"VOID\", \"deleted\": null, \"payments\": null, \"billMonth\": \"2026-02\", \"contractId\": 2, \"createTime\": null, \"paidAmount\": null, \"roomNumber\": \"101\", \"tenantName\": \"ZhangSan\", \"waterUsage\": null, \"tenantPhone\": \"12345678911\", \"totalAmount\": 10.0, \"buildingName\": \"A栋\", \"electricUsage\": null, \"generatedDate\": \"2026-03-13T17:57:14\", \"waterUnitPrice\": null, \"currWaterReading\": null, \"prevWaterReading\": null, \"electricUnitPrice\": null, \"currElectricReading\": null, \"prevElectricReading\": null}',1,'2026-03-13 18:45:22','2026-03-13 18:15:22','2026-03-13 18:15:22'),(6,NULL,'admin','账单管理','void',64,'2026-02 / #64','bill','{\"id\": 64, \"roomId\": 1, \"status\": \"PENDING\", \"deleted\": null, \"payments\": null, \"billMonth\": \"2026-02\", \"contractId\": 2, \"createTime\": null, \"paidAmount\": null, \"roomNumber\": \"101\", \"tenantName\": \"ZhangSan\", \"waterUsage\": null, \"tenantPhone\": \"12345678911\", \"totalAmount\": 10.0, \"buildingName\": \"A栋\", \"electricUsage\": null, \"generatedDate\": \"2026-03-13T17:57:14\", \"waterUnitPrice\": null, \"currWaterReading\": null, \"prevWaterReading\": null, \"electricUnitPrice\": null, \"currElectricReading\": null, \"prevElectricReading\": null}','{\"id\": 64, \"roomId\": 1, \"status\": \"VOID\", \"deleted\": null, \"payments\": null, \"billMonth\": \"2026-02\", \"contractId\": 2, \"createTime\": null, \"paidAmount\": null, \"roomNumber\": \"101\", \"tenantName\": \"ZhangSan\", \"waterUsage\": null, \"tenantPhone\": \"12345678911\", \"totalAmount\": 10.0, \"buildingName\": \"A栋\", \"electricUsage\": null, \"generatedDate\": \"2026-03-13T17:57:14\", \"waterUnitPrice\": null, \"currWaterReading\": null, \"prevWaterReading\": null, \"electricUnitPrice\": null, \"currElectricReading\": null, \"prevElectricReading\": null}',1,'2026-03-13 18:53:31','2026-03-13 18:23:31','2026-03-13 18:23:31'),(8,NULL,'admin','房屋管理','delete',6,'UNDO_TEST_1773397585','room','{\"id\": 6, \"area\": 20.0, \"floor\": 1, \"layout\": \"1?\", \"status\": \"??\", \"deleted\": null, \"imageUrl\": null, \"buildingId\": 1, \"roomNumber\": \"UNDO_TEST_1773397585\", \"waterMeterId\": null, \"electricMeterId\": null}',NULL,1,'2026-03-13 18:56:26','2026-03-13 18:26:26','2026-03-13 18:26:26'),(10,NULL,'admin','房屋管理','delete',10,'UNDO_BLD_1773397963','building','{\"id\": 10, \"code\": \"TST\", \"name\": \"UNDO_BLD_1773397963\", \"address\": \"test\", \"imageUrl\": null, \"totalFloors\": 2, \"waterUnitPrice\": 1.1, \"electricUnitPrice\": 0.7}',NULL,1,'2026-03-13 19:02:44','2026-03-13 18:32:44','2026-03-13 18:32:44'),(11,NULL,'admin','房屋管理','delete',7,'101','room','{\"id\": 7, \"area\": 100.0, \"floor\": 1, \"layout\": \"\", \"status\": \"空闲\", \"deleted\": null, \"imageUrl\": \"\", \"buildingId\": 2, \"roomNumber\": \"101\", \"waterMeterId\": null, \"electricMeterId\": null}',NULL,1,'2026-03-13 19:03:58','2026-03-13 18:33:58','2026-03-13 18:33:59');
/*!40000 ALTER TABLE `operation_snapshot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_order`
--

DROP TABLE IF EXISTS `payment_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_order` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `bill_id` bigint NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  `pay_type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `out_trade_no` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_id` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT '0' COMMENT '0-寰呮敮浠?1-鏀?粯鎴愬姛 2-鏀?粯澶辫触',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_payment_order_out_trade_no` (`out_trade_no`),
  KEY `idx_payment_order_bill` (`bill_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_order`
--

LOCK TABLES `payment_order` WRITE;
/*!40000 ALTER TABLE `payment_order` DISABLE KEYS */;
INSERT INTO `payment_order` VALUES (1,70,2450.00,'wx','PO17741949045212CD99334','MOCKTX123',1,'2026-03-22 23:55:05','2026-03-22 23:55:05');
/*!40000 ALTER TABLE `payment_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_record`
--

DROP TABLE IF EXISTS `payment_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_record` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '收款ID',
  `bill_id` bigint NOT NULL COMMENT '账单ID',
  `paid_amount` decimal(12,2) NOT NULL COMMENT '收款金额',
  `paid_date` datetime DEFAULT NULL COMMENT '收款日期',
  `payment_method` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '支付方式',
  `remark` text COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_bill_id` (`bill_id`),
  KEY `idx_payment_paid_date_bill` (`paid_date`,`bill_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='收款记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_record`
--

LOCK TABLES `payment_record` WRITE;
/*!40000 ALTER TABLE `payment_record` DISABLE KEYS */;
INSERT INTO `payment_record` VALUES (1,53,110.00,'2026-03-11 18:14:09','CASH','','2026-03-11 18:14:08'),(2,71,500.00,'2026-03-22 23:52:52','WECHAT','历史部分支付','2026-03-22 23:52:52'),(3,73,500.00,'2026-03-22 23:53:34','WECHAT','历史部分支付','2026-03-22 23:53:34'),(4,70,2450.00,'2026-03-22 23:55:05','WECHAT','租客端在线支付','2026-03-22 23:55:04');
/*!40000 ALTER TABLE `payment_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `remind_log`
--

DROP TABLE IF EXISTS `remind_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `remind_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `tenant_id` int DEFAULT NULL,
  `tenant_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `room_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `overdue_days` int DEFAULT NULL,
  `bill_ids` json DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `status` enum('success','failed') COLLATE utf8mb4_unicode_ci DEFAULT 'success',
  `fail_reason` text COLLATE utf8mb4_unicode_ci,
  `is_debug` tinyint(1) DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_remind_log_tenant_overdue` (`tenant_id`,`overdue_days`)
) ENGINE=InnoDB AUTO_INCREMENT=66 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `remind_log`
--

LOCK TABLES `remind_log` WRITE;
/*!40000 ALTER TABLE `remind_log` DISABLE KEYS */;
INSERT INTO `remind_log` VALUES (1,1,'测试用户','13800000000','A-101',1,'[66]',120.00,'尊敬的测试用户，您房间A-101有1笔账单逾期，总欠费120.00元，请尽快处理。','success',NULL,1,'2026-03-14 21:14:50'),(2,NULL,'张三','13800000000','A-101',1,'[1, 2]',256.80,'尊敬的张三，您有2笔账单逾期，总欠费256.80元，请尽快处理。','success',NULL,1,'2026-03-14 22:59:14'),(3,NULL,'张三','12345678911','101',0,'[52]',10.00,'2026-03 房间101账单待处理，金额10.00元，请及时查看并缴费。','success',NULL,1,'2026-03-15 00:42:55'),(4,NULL,'ZhangSan','12345678911','101',0,'[64]',10.00,'2026-02 房间101账单待处理，金额10.00元，请及时查看并缴费。','success',NULL,1,'2026-03-15 00:48:20'),(5,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：771586，5分钟内有效。','success',NULL,1,'2026-03-22 23:54:08'),(6,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：696475，5分钟内有效。','success',NULL,1,'2026-03-22 23:54:45'),(7,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：233155，5分钟内有效。','success',NULL,1,'2026-03-22 23:55:04'),(8,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：335332，5分钟内有效。','success',NULL,1,'2026-03-22 23:55:17'),(9,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：580483，5分钟内有效。','success',NULL,1,'2026-03-23 11:02:08'),(10,NULL,'租客','13900008888','手机号修改',NULL,NULL,NULL,'您正在修改手机号，验证码：016453，5分钟内有效。','success',NULL,1,'2026-03-23 11:02:09'),(11,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：142919，5分钟内有效。','success',NULL,1,'2026-03-23 11:02:41'),(12,NULL,'租客','13900008888','手机号修改',NULL,NULL,NULL,'您正在修改手机号，验证码：589524，5分钟内有效。','success',NULL,1,'2026-03-23 11:02:42'),(13,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：863956，5分钟内有效。','success',NULL,1,'2026-03-23 11:08:10'),(14,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：072973，5分钟内有效。','success',NULL,1,'2026-03-23 11:09:20'),(15,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：499424，5分钟内有效。','success',NULL,1,'2026-03-23 11:09:28'),(16,NULL,'租客','13900007777','手机号修改',NULL,NULL,NULL,'您正在修改手机号，验证码：960278，5分钟内有效。','success',NULL,1,'2026-03-23 11:13:40'),(17,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：260587，5分钟内有效。','success',NULL,1,'2026-03-23 12:42:40'),(18,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：909679，5分钟内有效。','success',NULL,1,'2026-03-23 12:42:41'),(19,NULL,'租客','13900008888','手机号修改',NULL,NULL,NULL,'您正在修改手机号，验证码：095154，5分钟内有效。','success',NULL,1,'2026-03-23 12:42:42'),(20,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：851334，5分钟内有效。','success',NULL,1,'2026-03-23 12:43:06'),(21,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：636368，5分钟内有效。','success',NULL,1,'2026-03-23 12:43:12'),(22,NULL,'租客','13900008888','手机号修改',NULL,NULL,NULL,'您正在修改手机号，验证码：229724，5分钟内有效。','success',NULL,1,'2026-03-23 12:43:13'),(23,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：848657，5分钟内有效。','success',NULL,1,'2026-03-23 12:59:21'),(24,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：598032，5分钟内有效。','success',NULL,1,'2026-03-23 12:59:26'),(25,NULL,'租客','13900008888','手机号修改',NULL,NULL,NULL,'您正在修改手机号，验证码：777904，5分钟内有效。','success',NULL,1,'2026-03-23 12:59:27'),(26,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：303844，5分钟内有效。','success',NULL,1,'2026-03-23 13:02:15'),(27,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：120520，5分钟内有效。','success',NULL,1,'2026-03-23 13:02:16'),(28,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：895845，5分钟内有效。','success',NULL,1,'2026-03-23 13:08:58'),(29,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：771258，5分钟内有效。','success',NULL,1,'2026-03-23 13:09:02'),(30,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：975076，5分钟内有效。','success',NULL,1,'2026-03-23 13:12:22'),(31,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：969876，5分钟内有效。','success',NULL,1,'2026-03-23 13:12:31'),(32,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：748374，5分钟内有效。','success',NULL,1,'2026-03-23 13:15:04'),(33,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：588641，5分钟内有效。','success',NULL,1,'2026-03-23 13:15:20'),(34,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：317621，5分钟内有效。','success',NULL,1,'2026-03-23 13:15:38'),(35,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：878782，5分钟内有效。','success',NULL,1,'2026-03-23 13:17:44'),(36,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：084410，5分钟内有效。','success',NULL,1,'2026-03-23 13:17:48'),(37,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：081137，5分钟内有效。','success',NULL,1,'2026-03-23 13:23:25'),(38,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：800545，5分钟内有效。','success',NULL,1,'2026-03-23 13:23:29'),(39,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：046827，5分钟内有效。','success',NULL,1,'2026-03-23 14:58:30'),(40,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：501147，5分钟内有效。','success',NULL,1,'2026-03-23 14:58:34'),(41,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：429263，5分钟内有效。','success',NULL,1,'2026-03-23 15:01:31'),(42,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：624400，5分钟内有效。','success',NULL,1,'2026-03-23 15:01:45'),(43,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：055706，5分钟内有效。','success',NULL,1,'2026-03-23 15:18:04'),(44,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：359044，5分钟内有效。','success',NULL,1,'2026-03-23 15:18:12'),(45,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：697052，5分钟内有效。','success',NULL,1,'2026-03-23 15:25:34'),(46,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：684355，5分钟内有效。','success',NULL,1,'2026-03-23 15:33:43'),(47,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：301630，5分钟内有效。','success',NULL,1,'2026-03-23 15:33:47'),(48,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：525151，5分钟内有效。','success',NULL,1,'2026-03-23 15:34:07'),(49,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：847097，5分钟内有效。','success',NULL,1,'2026-03-23 15:34:11'),(50,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：087631，5分钟内有效。','success',NULL,1,'2026-03-23 15:35:32'),(51,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：390094，5分钟内有效。','success',NULL,1,'2026-03-23 15:37:30'),(52,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：252002，5分钟内有效。','success',NULL,1,'2026-03-23 15:37:31'),(53,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：952067，5分钟内有效。','success',NULL,1,'2026-03-23 15:37:32'),(54,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：863148，5分钟内有效。','success',NULL,1,'2026-03-23 15:38:09'),(55,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：815950，5分钟内有效。','success',NULL,1,'2026-03-23 15:44:22'),(56,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：949428，5分钟内有效。','success',NULL,1,'2026-03-26 21:50:15'),(57,1,'ZhangSan','12345678911','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：161264，5分钟内有效。','success',NULL,1,'2026-03-26 21:53:31'),(58,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：043126，5分钟内有效。','success',NULL,1,'2026-03-26 22:32:10'),(59,3,'租客测试A','13900009999','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：369418，5分钟内有效。','success',NULL,1,'2026-03-26 22:33:57'),(60,1,'ZhangSan','12345678911','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：819115，5分钟内有效。','success',NULL,1,'2026-03-26 22:34:31'),(61,5,'tenant8986','13262319733','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：023274，5分钟内有效。','success',NULL,1,'2026-03-27 13:04:39'),(62,7,'SmokeTenant8284','17774588284','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：266721，5分钟内有效。','success',NULL,1,'2026-03-27 13:11:25'),(63,8,'SmokeTenant8295','17774588295','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：725559，5分钟内有效。','success',NULL,1,'2026-03-27 13:11:36'),(64,9,'SmokeTenant8309','17774588309','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：352742，5分钟内有效。','success',NULL,1,'2026-03-27 13:11:50'),(65,10,'SmokeTenant8325','17774588325','租客登录',NULL,NULL,NULL,'您正在登录房屋租赁系统，验证码：119708，5分钟内有效。','success',NULL,1,'2026-03-27 13:12:06');
/*!40000 ALTER TABLE `remind_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `remind_rule`
--

DROP TABLE IF EXISTS `remind_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `remind_rule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `overdue_days` int NOT NULL,
  `send_time` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '09:00',
  `sms_template` text COLLATE utf8mb4_unicode_ci,
  `is_enabled` tinyint(1) DEFAULT '0',
  `sort_order` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `remind_rule`
--

LOCK TABLES `remind_rule` WRITE;
/*!40000 ALTER TABLE `remind_rule` DISABLE KEYS */;
INSERT INTO `remind_rule` VALUES (1,1,'21:14','尊敬的{租户姓名}，您房间{房间号}有{逾期笔数}笔账单逾期，总欠费{总欠费金额}元，请尽快处理。',1,0),(2,1,'21:15','尊敬的{租户姓名}，您房间{房间号}有{逾期笔数}笔账单逾期，总欠费{总欠费金额}元，请尽快处理。',1,0),(3,1,'21:33','尊敬的{租户姓名}，您有{逾期笔数}笔账单逾期，总欠费{总欠费金额}元。',1,10),(4,1,'12:43','尊敬的{租户姓名}，您有{逾期笔数}笔账单逾期，总欠费{总欠费金额}元。',1,10),(5,1,'12:59','尊敬的{租户姓名}，您有{逾期笔数}笔账单逾期，总欠费{总欠费金额}元。',1,10),(6,1,'13:09','尊敬的{租户姓名}，您有{逾期笔数}笔账单逾期，总欠费{总欠费金额}元。',1,10),(7,1,'14:55','尊敬的{租户姓名}，您有{逾期笔数}笔账单逾期，总欠费{总欠费金额}元。',1,10),(8,1,'15:04','尊敬的{租户姓名}，您有{逾期笔数}笔账单逾期，总欠费{总欠费金额}元。',1,10),(9,1,'15:19','尊敬的{租户姓名}，您有{逾期笔数}笔账单逾期，总欠费{总欠费金额}元。',1,10);
/*!40000 ALTER TABLE `remind_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reminder_settings`
--

DROP TABLE IF EXISTS `reminder_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reminder_settings` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `enabled` tinyint DEFAULT '1' COMMENT '是否启用提醒',
  `reminder_days` varchar(100) DEFAULT '3,1' COMMENT '提前提醒天数，多个用逗号分隔',
  `reminder_time` varchar(10) DEFAULT '09:00' COMMENT '每日提醒时间',
  `overdue_reminder_enabled` tinyint DEFAULT '0' COMMENT '是否启用逾期提醒',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='合同到期提醒设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reminder_settings`
--

LOCK TABLES `reminder_settings` WRITE;
/*!40000 ALTER TABLE `reminder_settings` DISABLE KEYS */;
INSERT INTO `reminder_settings` VALUES (1,1,'3,1','09:00',0,'2026-03-12 18:01:48','2026-03-12 18:01:48');
/*!40000 ALTER TABLE `reminder_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `renew_application`
--

DROP TABLE IF EXISTS `renew_application`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `renew_application` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `contract_id` bigint NOT NULL,
  `tenant_id` bigint NOT NULL,
  `expected_duration` int NOT NULL,
  `remark` text COLLATE utf8mb4_unicode_ci,
  `status` tinyint NOT NULL DEFAULT '0',
  `result_remark` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_renew_tenant` (`tenant_id`),
  KEY `idx_renew_contract` (`contract_id`),
  KEY `idx_renew_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `renew_application`
--

LOCK TABLES `renew_application` WRITE;
/*!40000 ALTER TABLE `renew_application` DISABLE KEYS */;
INSERT INTO `renew_application` VALUES (1,6,3,12,'????????????',0,NULL,'2026-03-23 11:02:09','2026-03-23 11:02:09'),(2,6,3,12,'phase2 smoke renew',0,NULL,'2026-03-23 11:02:42','2026-03-23 11:02:42'),(3,6,3,12,'phase2 final renew',0,NULL,'2026-03-23 11:13:40','2026-03-23 11:13:40'),(4,6,3,12,'????????????',0,NULL,'2026-03-23 12:42:42','2026-03-23 12:42:42'),(5,6,3,12,'????????????',0,NULL,'2026-03-23 12:43:13','2026-03-23 12:43:13'),(6,6,3,12,'????????????',0,NULL,'2026-03-23 12:59:27','2026-03-23 12:59:27'),(7,6,3,12,'????????????',0,NULL,'2026-03-23 13:02:17','2026-03-23 13:02:17'),(8,6,3,12,'????????????',0,NULL,'2026-03-23 13:09:03','2026-03-23 13:09:03'),(9,6,3,12,'????????????',0,NULL,'2026-03-23 13:12:31','2026-03-23 13:12:31'),(10,6,3,12,'????????????',0,NULL,'2026-03-23 13:17:49','2026-03-23 13:17:49'),(11,6,3,12,'????????????',0,NULL,'2026-03-23 13:23:30','2026-03-23 13:23:30'),(12,6,3,12,'????????????',0,NULL,'2026-03-23 14:58:35','2026-03-23 14:58:35'),(13,6,3,12,'????????????',0,NULL,'2026-03-23 15:01:46','2026-03-23 15:01:46'),(14,6,3,12,'????????????',0,NULL,'2026-03-23 15:18:13','2026-03-23 15:18:13'),(15,6,3,12,'????????????',0,NULL,'2026-03-23 15:33:48','2026-03-23 15:33:48'),(16,6,3,12,'????????????',0,NULL,'2026-03-23 15:34:11','2026-03-23 15:34:11'),(17,6,3,12,'????????????',0,NULL,'2026-03-23 15:37:31','2026-03-23 15:37:31'),(18,6,3,12,'????????????',0,NULL,'2026-03-23 15:46:09','2026-03-23 15:46:09'),(19,6,3,12,'????????????',0,NULL,'2026-03-23 15:46:40','2026-03-23 15:46:40');
/*!40000 ALTER TABLE `renew_application` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repair_order`
--

DROP TABLE IF EXISTS `repair_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `repair_order` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `order_no` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `room_id` bigint NOT NULL,
  `tenant_id` bigint DEFAULT NULL,
  `reporter_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'admin',
  `reported_by` bigint DEFAULT NULL,
  `fault_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `images` json DEFAULT NULL,
  `appliance_id` bigint DEFAULT NULL,
  `status` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `worker_id` bigint DEFAULT NULL,
  `assigned_at` datetime DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `finish_time` datetime DEFAULT NULL,
  `accept_time` datetime DEFAULT NULL,
  `cancel_reason` text COLLATE utf8mb4_unicode_ci,
  `repair_result` text COLLATE utf8mb4_unicode_ci,
  `material_fee` decimal(10,2) DEFAULT '0.00',
  `labor_fee` decimal(10,2) DEFAULT '0.00',
  `total_fee` decimal(10,2) DEFAULT '0.00',
  `fee_remark` text COLLATE utf8mb4_unicode_ci,
  `is_tenant_charge` tinyint DEFAULT '0',
  `bill_item_id` bigint DEFAULT NULL,
  `rating` tinyint DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `expected_time` datetime DEFAULT NULL COMMENT 'tenant expected repair time',
  `contact_phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'tenant contact phone',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_repair_order_no` (`order_no`),
  KEY `idx_repair_order_status` (`status`),
  KEY `idx_repair_order_room` (`room_id`),
  KEY `idx_repair_order_worker` (`worker_id`),
  KEY `idx_repair_order_created` (`created_at`),
  KEY `idx_repair_tenant_status_created` (`tenant_id`,`status`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repair_order`
--

LOCK TABLES `repair_order` WRITE;
/*!40000 ALTER TABLE `repair_order` DISABLE KEYS */;
INSERT INTO `repair_order` VALUES (1,'RE1774234928259',8,3,'tenant',3,'??????','???????????????','[]',NULL,'pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,NULL,0,NULL,NULL,NULL,'2026-03-23 11:02:08','2026-03-23 11:02:08',NULL,'13900009999'),(2,'RE1774234961865',8,3,'tenant',3,'water','phase2 smoke repair','[]',NULL,'pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,NULL,0,NULL,NULL,NULL,'2026-03-23 11:02:42','2026-03-23 11:02:42',NULL,'13900009999'),(3,'RE1774235610249',8,3,'tenant',3,'water','phase2 final repair','[]',NULL,'pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,NULL,0,NULL,NULL,NULL,'2026-03-23 11:13:30','2026-03-23 11:13:30',NULL,'13900009999'),(4,'RE1774240961616',8,3,'tenant',3,'??????','???????????????','[]',NULL,'pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,NULL,0,NULL,NULL,NULL,'2026-03-23 12:42:42','2026-03-23 12:42:42',NULL,'13900009999'),(5,'RE1774240992501',8,3,'tenant',3,'??????','???????????????','[]',NULL,'pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,NULL,0,NULL,NULL,NULL,'2026-03-23 12:43:13','2026-03-23 12:43:13',NULL,'13900009999'),(6,'RE1774241966359',8,3,'tenant',3,'??????','???????????????','[]',NULL,'pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,NULL,0,NULL,NULL,NULL,'2026-03-23 12:59:26','2026-03-23 12:59:26',NULL,'13900009999'),(7,'RE1774242136536',8,3,'tenant',3,'??????','???????????????','[]',NULL,'pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,NULL,0,NULL,NULL,NULL,'2026-03-23 13:02:17','2026-03-23 13:02:17',NULL,'13900009999'),(8,'RE1774242542607',8,3,'tenant',3,'??????','???????????????','[]',NULL,'pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,NULL,0,NULL,NULL,NULL,'2026-03-23 13:09:03','2026-03-23 13:09:03',NULL,'13900009999'),(9,'RE1774242750937',8,3,'tenant',3,'??????','???????????????','[]',NULL,'pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,NULL,0,NULL,NULL,NULL,'2026-03-23 13:12:31','2026-03-23 13:12:31',NULL,'13900009999'),(10,'RE1774243068182',8,3,'tenant',3,'??????','???????????????','[]',NULL,'pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,NULL,0,NULL,NULL,NULL,'2026-03-23 13:17:48','2026-03-23 13:17:48',NULL,'13900009999'),(11,'RE1774243409392',8,3,'tenant',3,'??????','???????????????','[]',NULL,'pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,NULL,0,NULL,NULL,NULL,'2026-03-23 13:23:29','2026-03-23 13:23:29',NULL,'13900009999'),(12,'RE1774249114879',8,3,'tenant',3,'??????','???????????????','[]',NULL,'pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,NULL,0,NULL,NULL,NULL,'2026-03-23 14:58:35','2026-03-23 14:58:35',NULL,'13900009999'),(13,'RE1774249305637',8,3,'tenant',3,'??????','???????????????','[]',NULL,'pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,NULL,0,NULL,NULL,NULL,'2026-03-23 15:01:46','2026-03-23 15:01:46',NULL,'13900009999'),(14,'RE1774250292461',8,3,'tenant',3,'??????','???????????????','[]',NULL,'pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,NULL,0,NULL,NULL,NULL,'2026-03-23 15:18:12','2026-03-23 15:18:12',NULL,'13900009999'),(15,'RE1774251227689',8,3,'tenant',3,'??????','???????????????','[]',NULL,'pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,NULL,0,NULL,NULL,NULL,'2026-03-23 15:33:48','2026-03-23 15:33:48',NULL,'13900009999'),(16,'RE1774251251057',8,3,'tenant',3,'??????','???????????????','[]',NULL,'pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,NULL,0,NULL,NULL,NULL,'2026-03-23 15:34:11','2026-03-23 15:34:11',NULL,'13900009999'),(17,'RE1774251451253',8,3,'tenant',3,'??????','???????????????','[]',NULL,'pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,NULL,0,NULL,NULL,NULL,'2026-03-23 15:37:31','2026-03-23 15:37:31',NULL,'13900009999'),(18,'RE1774251968549',8,3,'tenant',3,'??????','???????????????','[]',NULL,'pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,NULL,0,NULL,NULL,NULL,'2026-03-23 15:46:09','2026-03-23 15:46:09',NULL,'13900009999'),(19,'RE1774252000236',8,3,'tenant',3,'??????','???????????????','[]',NULL,'pending',NULL,NULL,NULL,NULL,NULL,NULL,NULL,0.00,0.00,0.00,NULL,0,NULL,NULL,NULL,'2026-03-23 15:46:40','2026-03-23 15:46:40',NULL,'13900009999'),(20,'RE1774535709365',1,1,'tenant',1,'家电故障','空调坏了','[]',NULL,'processing',1,'2026-03-26 22:35:27','2026-03-26 22:35:27',NULL,NULL,NULL,NULL,0.00,0.00,0.00,NULL,0,NULL,NULL,NULL,'2026-03-26 22:35:09','2026-03-26 22:35:27','2026-03-26 14:34:00','12345678911');
/*!40000 ALTER TABLE `repair_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repair_worker`
--

DROP TABLE IF EXISTS `repair_worker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `repair_worker` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint DEFAULT '1',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_repair_worker_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repair_worker`
--

LOCK TABLES `repair_worker` WRITE;
/*!40000 ALTER TABLE `repair_worker` DISABLE KEYS */;
INSERT INTO `repair_worker` VALUES (1,'?????A','13800000000',1,'?????','2026-03-13 16:31:23'),(2,'?????B','13900000000',1,'????','2026-03-13 16:32:04');
/*!40000 ALTER TABLE `repair_worker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restore_log`
--

DROP TABLE IF EXISTS `restore_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `restore_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '鎭㈠?ID',
  `restore_time` datetime NOT NULL COMMENT '鎭㈠?鏃堕棿',
  `backup_id` bigint NOT NULL COMMENT '鍏宠仈鐨勫?浠絀D',
  `operator_id` bigint NOT NULL COMMENT '鎿嶄綔鐢ㄦ埛ID',
  `status` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'success' COMMENT '鎭㈠?鐘舵?: success/failed',
  `fail_reason` text COLLATE utf8mb4_unicode_ci COMMENT '澶辫触鍘熷洜',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '璁板綍鍒涘缓鏃堕棿',
  PRIMARY KEY (`id`),
  KEY `idx_backup_id` (`backup_id`),
  KEY `idx_restore_time` (`restore_time`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='鎭㈠?鏃ュ織琛';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restore_log`
--

LOCK TABLES `restore_log` WRITE;
/*!40000 ALTER TABLE `restore_log` DISABLE KEYS */;
INSERT INTO `restore_log` VALUES (1,'2026-03-14 23:54:29',1,1,'failed','备份文件不存在',NULL);
/*!40000 ALTER TABLE `restore_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `room` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '房间ID',
  `building_id` bigint NOT NULL COMMENT '楼栋ID',
  `floor` int DEFAULT NULL COMMENT '楼层',
  `room_number` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '房间号',
  `layout` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '户型',
  `area` decimal(10,2) DEFAULT NULL COMMENT '面积(平方米)',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'IDLE' COMMENT '状态: IDLE/RENTED/MAINTENANCE',
  `water_meter_id` bigint DEFAULT NULL COMMENT '水表ID',
  `electric_meter_id` bigint DEFAULT NULL COMMENT '电表ID',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `image_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_building_floor_number` (`building_id`,`floor`,`room_number`),
  KEY `idx_room_building_status_floor` (`building_id`,`status`,`floor`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='房间表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` VALUES (1,1,1,'101','',100.00,'已租',NULL,NULL,'2026-03-10 20:35:34',NULL,0),(2,1,1,'202','',10.00,'已租',NULL,NULL,'2026-03-10 20:35:54',NULL,0),(3,3,1,'303','',10.00,'空闲',NULL,NULL,'2026-03-12 23:11:59','',NULL),(6,1,1,'UNDO_TEST_1773397585','1?',20.00,'??',NULL,NULL,'2026-03-13 18:26:25',NULL,NULL),(7,2,1,'101','',100.00,'空闲',NULL,NULL,'2026-03-13 18:33:59','',NULL),(8,11,1,'T101',NULL,NULL,'RENTED',NULL,NULL,'2026-03-22 23:52:52',NULL,0),(9,11,2,'T201',NULL,NULL,'RENTED',NULL,NULL,'2026-03-22 23:52:52',NULL,0),(10,12,1,'T101',NULL,NULL,'RENTED',NULL,NULL,'2026-03-22 23:53:34',NULL,0),(11,12,2,'T201',NULL,NULL,'RENTED',NULL,NULL,'2026-03-22 23:53:34',NULL,0);
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room_appliance`
--

DROP TABLE IF EXISTS `room_appliance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `room_appliance` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `room_id` bigint NOT NULL,
  `appliance_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` int DEFAULT '1',
  `unit` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '个',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '正常',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `photos` json DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_room_appliance_room_id` (`room_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room_appliance`
--

LOCK TABLES `room_appliance` WRITE;
/*!40000 ALTER TABLE `room_appliance` DISABLE KEYS */;
INSERT INTO `room_appliance` VALUES (1,0,'????','????',1,'?','???',NULL,'[]','2026-03-13 16:31:23','2026-03-13 16:31:23'),(2,1,'????',NULL,1,'?','???',NULL,'[]','2026-03-13 16:32:04','2026-03-13 16:32:04'),(3,1,'空调','',1,'个','正常','','[]','2026-03-13 16:55:18','2026-03-13 16:55:18');
/*!40000 ALTER TABLE `room_appliance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sign_agreement`
--

DROP TABLE IF EXISTS `sign_agreement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sign_agreement` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `contract_id` bigint NOT NULL,
  `tenant_id` bigint NOT NULL,
  `verify_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'PENDING',
  `verify_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `verify_id_card` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sign_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'UNSIGNED',
  `sign_provider` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sign_flow_no` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `signed_at` datetime DEFAULT NULL,
  `expire_at` datetime DEFAULT NULL,
  `last_error` text COLLATE utf8mb4_unicode_ci,
  `retry_count` int NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_sign_contract_tenant` (`contract_id`,`tenant_id`),
  KEY `idx_sign_flow_no` (`sign_flow_no`),
  KEY `idx_sign_tenant` (`tenant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sign_agreement`
--

LOCK TABLES `sign_agreement` WRITE;
/*!40000 ALTER TABLE `sign_agreement` DISABLE KEYS */;
INSERT INTO `sign_agreement` VALUES (1,6,3,'PASSED','Test Tenant','1101****1234','UNSIGNED','MOCK_ESIGN','FLOW1774535637790','2026-03-26 22:33:58','2026-03-27 22:33:58',NULL,31,'2026-03-23 11:50:50','2026-03-26 22:33:58');
/*!40000 ALTER TABLE `sign_agreement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_config`
--

DROP TABLE IF EXISTS `sms_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_config` (
  `id` int NOT NULL AUTO_INCREMENT,
  `provider` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'aliyun',
  `access_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access_secret` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `signature` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template_code` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `debug_mode` tinyint(1) DEFAULT '1',
  `status` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_config`
--

LOCK TABLES `sms_config` WRITE;
/*!40000 ALTER TABLE `sms_config` DISABLE KEYS */;
INSERT INTO `sms_config` VALUES (1,'aliyun','','','租赁平台','',1,1),(2,'aliyun','','','租赁平台','',1,1);
/*!40000 ALTER TABLE `sms_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user`
--

DROP TABLE IF EXISTS `sys_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `real_name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `role` varchar(20) NOT NULL DEFAULT 'STAFF',
  `enabled` tinyint NOT NULL DEFAULT '1',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_login_time` datetime DEFAULT NULL COMMENT '最后登录时间',
  `theme_preference` varchar(20) NOT NULL DEFAULT 'system' COMMENT '??????: light/dark/system',
  `first_login` tinyint(1) NOT NULL DEFAULT '1' COMMENT '????????????',
  `show_context_tips` tinyint(1) NOT NULL DEFAULT '1' COMMENT '鏄?惁鏄剧ず涓婁笅鏂囨彁绀',
  `show_task_card` tinyint(1) NOT NULL DEFAULT '1' COMMENT '鏄?惁鏄剧ず鏂版墜浠诲姟鍗',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user`
--

LOCK TABLES `sys_user` WRITE;
/*!40000 ALTER TABLE `sys_user` DISABLE KEYS */;
INSERT INTO `sys_user` VALUES (1,'admin','$2a$10$6ghpnxxLQ7iOsmi/MiFT0eM6djEU7ktybENx4K8OHalzgnLP70qSK','系统管理员',NULL,NULL,'SUPER_ADMIN',1,NULL,NULL,'2026-03-27 13:24:43','light',0,1,1),(2,'manager1','$2a$10$6ghpnxxLQ7iOsmi/MiFT0eM6djEU7ktybENx4K8OHalzgnLP70qSK','管理员1',NULL,NULL,'ADMIN',1,'2026-03-13 12:00:06',NULL,'2026-03-27 13:19:39','system',1,1,1);
/*!40000 ALTER TABLE `sys_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_message`
--

DROP TABLE IF EXISTS `system_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_message` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL COMMENT '消息类型：CONTRACT_EXPIRE-合同到期提醒',
  `title` varchar(200) NOT NULL COMMENT '消息标题',
  `content` text NOT NULL COMMENT '消息内容',
  `related_id` bigint DEFAULT NULL COMMENT '关联ID（合同ID）',
  `is_read` tinyint DEFAULT '0' COMMENT '是否已读：0-未读，1-已读',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `read_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=75 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='系统消息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_message`
--

LOCK TABLES `system_message` WRITE;
/*!40000 ALTER TABLE `system_message` DISABLE KEYS */;
INSERT INTO `system_message` VALUES (1,'BATCH_NOTIFY','??????','????????',1,1,'2026-03-13 15:38:11','2026-03-13 18:33:24'),(2,'BATCH_NOTIFY','??????','????????',2,1,'2026-03-13 15:38:11','2026-03-13 18:33:30'),(3,'SMS_MOCK','短信已发送(模拟)','租户: 张三; 手机号: 13800000000; 房间: A-101; 内容: 尊敬的张三，您有2笔账单逾期，总欠费256.80元，请尽快处理。',NULL,1,'2026-03-14 22:59:14','2026-03-14 22:59:33'),(4,'SMS_MOCK','短信已发送(模拟)','租户: 张三; 手机号: 12345678911; 房间: 101; 内容: 2026-03 房间101账单待处理，金额10.00元，请及时查看并缴费。',NULL,1,'2026-03-15 00:42:55','2026-03-15 00:48:02'),(5,'SMS_MOCK','短信已发送(模拟)','租户: ZhangSan; 手机号: 12345678911; 房间: 101; 内容: 2026-02 房间101账单待处理，金额10.00元，请及时查看并缴费。',NULL,1,'2026-03-15 00:48:20','2026-03-15 00:48:25'),(6,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：771586，5分钟内有效。',3,0,'2026-03-22 23:54:08',NULL),(7,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：696475，5分钟内有效。',3,0,'2026-03-22 23:54:45',NULL),(8,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：233155，5分钟内有效。',3,0,'2026-03-22 23:55:04',NULL),(9,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：335332，5分钟内有效。',3,0,'2026-03-22 23:55:17',NULL),(10,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：580483，5分钟内有效。',3,0,'2026-03-23 11:02:08',NULL),(11,'SMS_MOCK','短信已发送(模拟)','租户: 租客; 手机号: 13900008888; 房间: 手机号修改; 内容: 您正在修改手机号，验证码：016453，5分钟内有效。',NULL,0,'2026-03-23 11:02:09',NULL),(12,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：142919，5分钟内有效。',3,0,'2026-03-23 11:02:41',NULL),(13,'SMS_MOCK','短信已发送(模拟)','租户: 租客; 手机号: 13900008888; 房间: 手机号修改; 内容: 您正在修改手机号，验证码：589524，5分钟内有效。',NULL,0,'2026-03-23 11:02:42',NULL),(14,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：863956，5分钟内有效。',3,0,'2026-03-23 11:08:10',NULL),(15,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：072973，5分钟内有效。',3,0,'2026-03-23 11:09:20',NULL),(16,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：499424，5分钟内有效。',3,0,'2026-03-23 11:09:28',NULL),(17,'SMS_MOCK','短信已发送(模拟)','租户: 租客; 手机号: 13900007777; 房间: 手机号修改; 内容: 您正在修改手机号，验证码：960278，5分钟内有效。',NULL,0,'2026-03-23 11:13:40',NULL),(18,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：260587，5分钟内有效。',3,0,'2026-03-23 12:42:40',NULL),(19,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：909679，5分钟内有效。',3,0,'2026-03-23 12:42:41',NULL),(20,'SMS_MOCK','短信已发送(模拟)','租户: 租客; 手机号: 13900008888; 房间: 手机号修改; 内容: 您正在修改手机号，验证码：095154，5分钟内有效。',NULL,0,'2026-03-23 12:42:42',NULL),(21,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：851334，5分钟内有效。',3,0,'2026-03-23 12:43:06',NULL),(22,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：636368，5分钟内有效。',3,0,'2026-03-23 12:43:12',NULL),(23,'SMS_MOCK','短信已发送(模拟)','租户: 租客; 手机号: 13900008888; 房间: 手机号修改; 内容: 您正在修改手机号，验证码：229724，5分钟内有效。',NULL,0,'2026-03-23 12:43:13',NULL),(24,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：848657，5分钟内有效。',3,0,'2026-03-23 12:59:21',NULL),(25,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：598032，5分钟内有效。',3,0,'2026-03-23 12:59:26',NULL),(26,'SMS_MOCK','短信已发送(模拟)','租户: 租客; 手机号: 13900008888; 房间: 手机号修改; 内容: 您正在修改手机号，验证码：777904，5分钟内有效。',NULL,0,'2026-03-23 12:59:27',NULL),(27,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：303844，5分钟内有效。',3,0,'2026-03-23 13:02:15',NULL),(28,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：120520，5分钟内有效。',3,0,'2026-03-23 13:02:16',NULL),(29,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：895845，5分钟内有效。',3,0,'2026-03-23 13:08:58',NULL),(30,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：771258，5分钟内有效。',3,0,'2026-03-23 13:09:02',NULL),(31,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：975076，5分钟内有效。',3,0,'2026-03-23 13:12:22',NULL),(32,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：969876，5分钟内有效。',3,0,'2026-03-23 13:12:31',NULL),(33,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：748374，5分钟内有效。',3,0,'2026-03-23 13:15:04',NULL),(34,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：588641，5分钟内有效。',3,0,'2026-03-23 13:15:20',NULL),(35,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：317621，5分钟内有效。',3,0,'2026-03-23 13:15:38',NULL),(36,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：878782，5分钟内有效。',3,0,'2026-03-23 13:17:44',NULL),(37,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：084410，5分钟内有效。',3,0,'2026-03-23 13:17:48',NULL),(38,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：081137，5分钟内有效。',3,0,'2026-03-23 13:23:25',NULL),(39,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：800545，5分钟内有效。',3,0,'2026-03-23 13:23:29',NULL),(40,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：046827，5分钟内有效。',3,0,'2026-03-23 14:58:30',NULL),(41,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：501147，5分钟内有效。',3,0,'2026-03-23 14:58:34',NULL),(42,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：429263，5分钟内有效。',3,0,'2026-03-23 15:01:31',NULL),(43,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：624400，5分钟内有效。',3,0,'2026-03-23 15:01:45',NULL),(44,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：055706，5分钟内有效。',3,0,'2026-03-23 15:18:04',NULL),(45,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：359044，5分钟内有效。',3,0,'2026-03-23 15:18:12',NULL),(46,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：697052，5分钟内有效。',3,0,'2026-03-23 15:25:34',NULL),(47,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：684355，5分钟内有效。',3,0,'2026-03-23 15:33:43',NULL),(48,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：301630，5分钟内有效。',3,0,'2026-03-23 15:33:47',NULL),(49,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：525151，5分钟内有效。',3,0,'2026-03-23 15:34:07',NULL),(50,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：847097，5分钟内有效。',3,0,'2026-03-23 15:34:11',NULL),(51,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：087631，5分钟内有效。',3,0,'2026-03-23 15:35:32',NULL),(52,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：390094，5分钟内有效。',3,0,'2026-03-23 15:37:30',NULL),(53,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：252002，5分钟内有效。',3,0,'2026-03-23 15:37:31',NULL),(54,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：952067，5分钟内有效。',3,0,'2026-03-23 15:37:32',NULL),(55,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：863148，5分钟内有效。',3,0,'2026-03-23 15:38:09',NULL),(56,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：815950，5分钟内有效。',3,0,'2026-03-23 15:44:22',NULL),(57,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：949428，5分钟内有效。',3,0,'2026-03-26 21:50:15',NULL),(58,'SMS_MOCK','短信已发送(模拟)','租户: ZhangSan; 手机号: 12345678911; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：161264，5分钟内有效。',1,0,'2026-03-26 21:53:31',NULL),(59,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：043126，5分钟内有效。',3,0,'2026-03-26 22:32:10',NULL),(60,'SMS_MOCK','短信已发送(模拟)','租户: 租客测试A; 手机号: 13900009999; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：369418，5分钟内有效。',3,0,'2026-03-26 22:33:57',NULL),(61,'SMS_MOCK','短信已发送(模拟)','租户: ZhangSan; 手机号: 12345678911; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：819115，5分钟内有效。',1,0,'2026-03-26 22:34:31',NULL),(62,'TENANT_REGISTER','新租户注册','租户 tenant8986（132****9733）已在租客端注册，请及时跟进租房需求。',5,0,'2026-03-27 13:04:31',NULL),(63,'TENANT_RENT_INTENT','新租房沟通申请','租户: tenant8986\n手机号: 132****9733\n意向房间: 303\n留言: Interested in renting this room',5,0,'2026-03-27 13:04:31',NULL),(64,'SMS_MOCK','短信已发送(模拟)','租户: tenant8986; 手机号: 13262319733; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：023274，5分钟内有效。',5,0,'2026-03-27 13:04:39',NULL),(65,'TENANT_REGISTER','新租户注册','租户 SmokeTenant8237（177****8237）已在租客端注册，请及时跟进租房需求。',6,0,'2026-03-27 13:10:37',NULL),(66,'TENANT_REGISTER','新租户注册','租户 SmokeTenant8284（177****8284）已在租客端注册，请及时跟进租房需求。',7,0,'2026-03-27 13:11:25',NULL),(67,'SMS_MOCK','短信已发送(模拟)','租户: SmokeTenant8284; 手机号: 17774588284; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：266721，5分钟内有效。',7,0,'2026-03-27 13:11:25',NULL),(68,'TENANT_REGISTER','新租户注册','租户 SmokeTenant8295（177****8295）已在租客端注册，请及时跟进租房需求。',8,0,'2026-03-27 13:11:36',NULL),(69,'SMS_MOCK','短信已发送(模拟)','租户: SmokeTenant8295; 手机号: 17774588295; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：725559，5分钟内有效。',8,0,'2026-03-27 13:11:36',NULL),(70,'TENANT_REGISTER','新租户注册','租户 SmokeTenant8309（177****8309）已在租客端注册，请及时跟进租房需求。',9,0,'2026-03-27 13:11:50',NULL),(71,'SMS_MOCK','短信已发送(模拟)','租户: SmokeTenant8309; 手机号: 17774588309; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：352742，5分钟内有效。',9,0,'2026-03-27 13:11:50',NULL),(72,'TENANT_REGISTER','新租户注册','租户 SmokeTenant8325（177****8325）已在租客端注册，请及时跟进租房需求。',10,0,'2026-03-27 13:12:06',NULL),(73,'SMS_MOCK','短信已发送(模拟)','租户: SmokeTenant8325; 手机号: 17774588325; 房间: 租客登录; 内容: 您正在登录房屋租赁系统，验证码：119708，5分钟内有效。',10,0,'2026-03-27 13:12:06',NULL),(74,'TENANT_RENT_INTENT','新租房沟通申请','租户: SmokeTenant8325\n手机号: 17774588325\n意向房间: 303\n留言: Smoke test intent at 2026-03-27 13:12:06',10,0,'2026-03-27 13:12:07',NULL);
/*!40000 ALTER TABLE `system_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenant`
--

DROP TABLE IF EXISTS `tenant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '租户ID',
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '姓名',
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '手机号',
  `password` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '租客登录密码(BCrypt)',
  `id_card` varchar(18) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '身份证号',
  `emergency_contact` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '紧急联系人',
  `emergency_phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '紧急联系电话',
  `remark` text COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `register_source` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'ADMIN' COMMENT '注册来源: ADMIN/APP',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `deleted` tinyint DEFAULT '0',
  `is_blacklisted` tinyint DEFAULT '0' COMMENT '是否在黑名单中',
  `blacklist_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '加入黑名单原因',
  `blacklisted_at` datetime DEFAULT NULL COMMENT '加入黑名单时间',
  `blacklisted_by` bigint DEFAULT NULL COMMENT '操作人ID',
  `language_preference` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'zh-CN' COMMENT '??????: zh-CN/en-US',
  `notify_overdue` tinyint NOT NULL DEFAULT '1' COMMENT '逾期提醒开关',
  `notify_repair` tinyint NOT NULL DEFAULT '1' COMMENT '报修投诉进度提醒开关',
  `notify_contract` tinyint NOT NULL DEFAULT '1' COMMENT '合同提醒开关',
  `notify_notice` tinyint NOT NULL DEFAULT '1' COMMENT '公告提醒开关',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_phone` (`phone`),
  KEY `idx_tenant_blacklisted` (`is_blacklisted`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='租户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant`
--

LOCK TABLES `tenant` WRITE;
/*!40000 ALTER TABLE `tenant` DISABLE KEYS */;
INSERT INTO `tenant` VALUES (1,'ZhangSan','12345678911',NULL,'110101199001011234','李四','13800138000',NULL,'ADMIN','2026-03-10 20:35:22',0,0,NULL,NULL,NULL,'zh-CN',1,1,1,1),(2,'李四','14785236900',NULL,'','','','','ADMIN','2026-03-12 23:11:18',NULL,1,'扰民','2026-03-12 23:11:31',1,'zh-CN',1,1,1,1),(3,'租客测试A','13900009999',NULL,'320102199901011234','李四','13900001111','租客端测试数据','ADMIN','2026-03-22 23:52:52',0,0,NULL,NULL,NULL,'en-US',1,1,1,1),(5,'tenant8986','13262319733','$2a$10$naxCtdisvIKz9tIBADvss.yHS3qnMwn0OjsLSkPsefBBK4W0CtCrK',NULL,NULL,NULL,NULL,'APP','2026-03-27 13:04:30',0,NULL,NULL,NULL,NULL,'zh-CN',1,1,1,1),(6,'SmokeTenant8237','17774588237','$2a$10$3/salABIEvB/Efw9.GyD/OO8ACMAtsyQlhUYyTk1rAddlRSgfFGoq',NULL,NULL,NULL,NULL,'APP','2026-03-27 13:10:37',0,NULL,NULL,NULL,NULL,'zh-CN',1,1,1,1),(7,'SmokeTenant8284','17774588284','$2a$10$DYFYBlt1hK7bdiaeYVyJ/u5xXAY4D6o22ITeNjZCXRSHiGdkiChNG',NULL,NULL,NULL,NULL,'APP','2026-03-27 13:11:24',0,NULL,NULL,NULL,NULL,'zh-CN',1,1,1,1),(8,'SmokeTenant8295','17774588295','$2a$10$gHhXIEf7fkOTbfNzZIZy9OX/.OhJWJvW.JJgaY6NFQJhCezajFIbC',NULL,NULL,NULL,NULL,'APP','2026-03-27 13:11:35',0,NULL,NULL,NULL,NULL,'zh-CN',1,1,1,1),(9,'SmokeTenant8309','17774588309','$2a$10$XFi.AR2n7EMYq3cYNh2hRu8lj64g2rlo9YsOlQwCiGcQwlqDy9nO6',NULL,NULL,NULL,NULL,'APP','2026-03-27 13:11:49',0,NULL,NULL,NULL,NULL,'zh-CN',1,1,1,1),(10,'SmokeTenant8325','17774588325','$2a$10$1EmEqt7.4kSXY0r7b/xmBepiFxr51/Rn8lNF4RCx0QQb46AIlaQgq',NULL,NULL,NULL,NULL,'APP','2026-03-27 13:12:05',0,NULL,NULL,NULL,NULL,'zh-CN',1,1,1,1);
/*!40000 ALTER TABLE `tenant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenant_login_code`
--

DROP TABLE IF EXISTS `tenant_login_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant_login_code` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(6) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expires_at` datetime NOT NULL,
  `sent_date` date NOT NULL,
  `sent_count` int NOT NULL DEFAULT '0',
  `last_sent_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_tenant_login_code_phone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant_login_code`
--

LOCK TABLES `tenant_login_code` WRITE;
/*!40000 ALTER TABLE `tenant_login_code` DISABLE KEYS */;
INSERT INTO `tenant_login_code` VALUES (1,'13900009999','369418','2026-03-26 22:38:57','2026-03-26',3,'2026-03-26 22:33:57'),(2,'13900008888','777904','2026-03-23 13:04:27','2026-03-23',5,'2026-03-23 12:59:27'),(3,'13900007777','960278','2026-03-23 11:18:40','2026-03-23',1,'2026-03-23 11:13:40'),(43,'12345678911','819115','2026-03-26 22:39:31','2026-03-26',2,'2026-03-26 22:34:31'),(44,'13262319733','023274','2026-03-27 13:09:39','2026-03-27',1,'2026-03-27 13:04:39'),(45,'17774588284','266721','2026-03-27 13:16:25','2026-03-27',1,'2026-03-27 13:11:25'),(46,'17774588295','725559','2026-03-27 13:16:36','2026-03-27',1,'2026-03-27 13:11:36'),(47,'17774588309','352742','2026-03-27 13:16:50','2026-03-27',1,'2026-03-27 13:11:50'),(48,'17774588325','119708','2026-03-27 13:17:06','2026-03-27',1,'2026-03-27 13:12:06');
/*!40000 ALTER TABLE `tenant_login_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenant_message`
--

DROP TABLE IF EXISTS `tenant_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant_message` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint NOT NULL,
  `room_id` bigint DEFAULT NULL,
  `category` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'TODO/NOTICE',
  `type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'OVERDUE/REPAIR_PROGRESS/CONTRACT_EXPIRE/NOTICE_NEW/SIGN_RETRY',
  `title` varchar(120) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_url` varchar(300) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_type` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_id` bigint DEFAULT NULL,
  `is_read` tinyint NOT NULL DEFAULT '0',
  `is_deleted` tinyint NOT NULL DEFAULT '0',
  `need_action` tinyint NOT NULL DEFAULT '0',
  `action_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DONE' COMMENT 'PENDING/DONE',
  `created_at` datetime NOT NULL,
  `read_at` datetime DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_tenant_message_tenant` (`tenant_id`),
  KEY `idx_tenant_message_category` (`category`),
  KEY `idx_tenant_message_ref` (`ref_type`,`ref_id`),
  KEY `idx_tenant_message_created` (`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant_message`
--

LOCK TABLES `tenant_message` WRITE;
/*!40000 ALTER TABLE `tenant_message` DISABLE KEYS */;
INSERT INTO `tenant_message` VALUES (1,3,8,'TODO','OVERDUE','Bill overdue reminder','Your bill 2026-02 is overdue, unpaid amount: 1480.00.','/bills','BILL',71,1,0,0,'DONE','2026-03-23 11:50:50','2026-03-23 15:18:21',NULL),(2,3,8,'TODO','OVERDUE','Bill overdue reminder','Your bill 2026-02 is overdue, unpaid amount: 1480.00.','/bills','BILL',73,0,0,1,'PENDING','2026-03-23 11:50:50',NULL,NULL),(3,3,8,'TODO','OVERDUE','Bill overdue reminder','Your bill 2026-03 is overdue, unpaid amount: 2450.00.','/bills','BILL',72,0,0,1,'PENDING','2026-03-23 11:50:50',NULL,NULL),(4,3,8,'NOTICE','NOTICE_NEW','New announcement','A new announcement is published: 测试公告-停水通知','/notices/1','NOTICE',1,0,0,0,'DONE','2026-03-23 11:50:50',NULL,NULL),(5,3,8,'NOTICE','SIGN_VERIFY','Identity verification passed','Contract TEST-C-1774194772-1 is ready for signing.','/contract','CONTRACT',6,0,0,0,'DONE','2026-03-23 11:50:50',NULL,NULL),(6,3,8,'NOTICE','SIGN_SUCCESS','Contract signed successfully','Contract TEST-C-1774194772-1 has been signed.','/contract','CONTRACT',6,0,0,0,'DONE','2026-03-23 11:50:50',NULL,NULL),(7,3,8,'NOTICE','COMPLAINT_PROGRESS','Complaint update','Complaint CP1774250292696 status changed to completed.','/complaints/17','COMPLAINT',17,1,0,0,'DONE','2026-03-23 15:33:52','2026-03-26 22:33:58',NULL);
/*!40000 ALTER TABLE `tenant_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户名',
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '密码',
  `real_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '真实姓名',
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '手机号',
  `role` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'ADMIN' COMMENT '角色',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin','$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5EH','管理员',NULL,'ADMIN','2026-03-10 17:57:22');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-27 13:56:02
