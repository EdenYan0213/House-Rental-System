mysqldump: [Warning] Using a password on the command line interface can be insecure.
-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: localhost    Database: house_db
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `appliance_template`
--

DROP TABLE IF EXISTS `appliance_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `appliance_template` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `default_quantity` int DEFAULT '1',
  `unit` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '个',
  `sort_order` int DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appliance_template`
--

LOCK TABLES `appliance_template` WRITE;
/*!40000 ALTER TABLE `appliance_template` DISABLE KEYS */;
INSERT INTO `appliance_template` VALUES (1,'床','',1,'张',1,'2026-03-13 16:30:26'),(2,'衣柜','',1,'个',2,'2026-03-13 16:30:26'),(3,'空调','',1,'台',3,'2026-03-13 16:30:26'),(4,'热水器','',1,'台',4,'2026-03-13 16:30:26');
/*!40000 ALTER TABLE `appliance_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_config`
--

DROP TABLE IF EXISTS `backup_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_config` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '閰嶇疆ID',
  `enabled` tinyint(1) DEFAULT '0' COMMENT '鏄?惁鍚?敤鑷?姩澶囦唤',
  `backup_type` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT 'daily' COMMENT '澶囦唤鍛ㄦ湡: daily/weekly',
  `backup_day` int DEFAULT '1' COMMENT '姣忓懆澶囦唤鏃?1-7, 1=鍛ㄤ竴)',
  `backup_time` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT '02:00' COMMENT '澶囦唤鏃堕棿(HH:mm)',
  `retention_count` int DEFAULT '7' COMMENT '淇濈暀浠芥暟',
  `storage_path` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT './backups' COMMENT '瀛樺偍璺?緞',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '鍒涘缓鏃堕棿',
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '鏇存柊鏃堕棿',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='澶囦唤閰嶇疆琛';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_config`
--

LOCK TABLES `backup_config` WRITE;
/*!40000 ALTER TABLE `backup_config` DISABLE KEYS */;
INSERT INTO `backup_config` VALUES (1,0,'weekly',1,'02:00',7,'./backups','2026-03-14 11:15:17','2026-03-14 11:15:17');
/*!40000 ALTER TABLE `backup_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backup_record`
--

DROP TABLE IF EXISTS `backup_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backup_record` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '澶囦唤ID',
  `backup_time` datetime NOT NULL COMMENT '澶囦唤鏃堕棿',
  `type` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'manual' COMMENT '澶囦唤绫诲瀷: auto/manual',
  `status` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'success' COMMENT '鐘舵?: success/failed',
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '澶囦唤鏂囦欢鍚',
  `file_path` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '瀛樺偍璺?緞',
  `file_size` bigint DEFAULT '0' COMMENT '鏂囦欢澶у皬(瀛楄妭)',
  `md5` varchar(32) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '鏂囦欢MD5',
  `fail_reason` text COLLATE utf8mb4_unicode_ci COMMENT '澶辫触鍘熷洜',
  `operator_id` bigint DEFAULT NULL COMMENT '鎿嶄綔浜篒D',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '璁板綍鍒涘缓鏃堕棿',
  PRIMARY KEY (`id`),
  KEY `idx_backup_time` (`backup_time`),
  KEY `idx_type` (`type`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='澶囦唤璁板綍琛';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backup_record`
--

LOCK TABLES `backup_record` WRITE;
/*!40000 ALTER TABLE `backup_record` DISABLE KEYS */;
INSERT INTO `backup_record` VALUES (1,'2026-03-14 23:45:45','manual','failed','backup_20260314_234545.zip','./backups/backup_20260314_234545.zip',0,NULL,'Range [109, 36) out of bounds for length 146',1,NULL);
/*!40000 ALTER TABLE `backup_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bill`
--

DROP TABLE IF EXISTS `bill`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bill` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '账单ID',
  `contract_id` bigint NOT NULL COMMENT '合同ID',
  `bill_month` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '账单月份 yyyy-MM',
  `total_amount` decimal(12,2) DEFAULT '0.00' COMMENT '总金额',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'PENDING' COMMENT '状态: PENDING/PAID/OBSOLETE',
  `generated_date` datetime DEFAULT NULL COMMENT '生成日期',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `room_id` bigint DEFAULT NULL,
  `room_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `building_name` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tenant_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tenant_phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_contract_month` (`contract_id`,`bill_month`)
) ENGINE=InnoDB AUTO_INCREMENT=68 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='账单表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bill`
--

LOCK TABLES `bill` WRITE;
/*!40000 ALTER TABLE `bill` DISABLE KEYS */;
INSERT INTO `bill` VALUES (52,2,'2026-03',10.00,'VOID','2026-03-11 18:10:09','2026-03-11 18:10:09',1,'101','A栋','张三','12345678911',NULL),(53,3,'2026-03',110.00,'已支付','2026-03-11 18:10:09','2026-03-11 18:10:09',2,'202','A栋','张三','12345678911',NULL),(64,2,'2026-02',10.00,'PENDING','2026-03-13 17:57:14','2026-03-13 17:57:14',1,'101','A栋','ZhangSan','12345678911',NULL),(65,3,'2026-02',110.00,'PENDING','2026-03-13 17:57:15','2026-03-13 17:57:14',2,'202','A栋','ZhangSan','12345678911',NULL),(66,1,'2026-01',120.00,'待支付','2026-03-12 21:15:44','2026-03-14 21:02:04',1,'A-101',NULL,'测试用户','13800000000',0);
/*!40000 ALTER TABLE `bill` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bill_detail`
--

DROP TABLE IF EXISTS `bill_detail`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bill_detail` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '明细ID',
  `bill_id` bigint NOT NULL COMMENT '账单ID',
  `fee_item_id` bigint DEFAULT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '费用名称',
  `usage_amount` decimal(10,2) DEFAULT NULL,
  `amount` decimal(12,2) DEFAULT NULL COMMENT '金额',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `prev_reading` double DEFAULT '0',
  `curr_reading` double DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `idx_bill_id` (`bill_id`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='账单明细表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bill_detail`
--

LOCK TABLES `bill_detail` WRITE;
/*!40000 ALTER TABLE `bill_detail` DISABLE KEYS */;
INSERT INTO `bill_detail` VALUES (1,14,NULL,'基础房费',1.00,10.00,'2026-03-10 22:28:45',0,0),(2,14,NULL,'水费',10.00,35.00,'2026-03-10 22:28:45',0,0),(3,14,NULL,'电费',10.00,6.00,'2026-03-10 22:28:45',0,0),(4,15,NULL,'基础房费',1.00,110.00,'2026-03-10 22:28:45',0,0),(7,20,NULL,'基础房费',1.00,10.00,'2026-03-10 22:58:48',0,0),(8,20,NULL,'水费',30.00,105.00,'2026-03-10 22:58:48',0,0),(9,20,NULL,'电费',30.00,18.00,'2026-03-10 22:58:48',0,0),(10,21,NULL,'基础房费',1.00,110.00,'2026-03-10 22:58:48',0,0),(68,52,NULL,'基础房费',1.00,10.00,'2026-03-11 18:10:09',NULL,NULL),(69,52,NULL,'水费',40.00,0.00,'2026-03-11 18:10:09',40,80),(70,52,NULL,'电费',40.00,0.00,'2026-03-11 18:10:09',40,80),(71,53,NULL,'基础房费',1.00,110.00,'2026-03-11 18:10:09',NULL,NULL),(72,53,NULL,'水费',0.00,0.00,'2026-03-11 18:10:09',20,20),(73,53,NULL,'电费',0.00,0.00,'2026-03-11 18:10:09',20,20),(104,64,NULL,'基础房费',1.00,10.00,'2026-03-13 17:57:14',0,0),(105,65,NULL,'基础房费',1.00,110.00,'2026-03-13 17:57:14',0,0);
/*!40000 ALTER TABLE `bill_detail` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `building`
--

DROP TABLE IF EXISTS `building`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `building` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '楼栋ID',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '楼栋名称',
  `code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '楼栋编号',
  `address` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '地址',
  `total_floors` int DEFAULT '1' COMMENT '楼层数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `image_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  `water_unit_price` double DEFAULT '0',
  `electric_unit_price` double DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='楼栋表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `building`
--

LOCK TABLES `building` WRITE;
/*!40000 ALTER TABLE `building` DISABLE KEYS */;
INSERT INTO `building` VALUES (1,'A栋','aaa','大萨达撒',3,'2026-03-10 20:29:53','/api/files/9c824e43-7d30-42c1-8fd5-ffac92bbb6c6.gif',0,0,0),(2,'C','c','dasd ',1,'2026-03-11 17:38:20','',NULL,12,2),(3,'B','b ','das sa',1,'2026-03-11 17:55:10','/api/files/4b223c3c-939c-4295-86da-e1250490ba48____.jpg',0,10,1),(4,'12','1','12',1,'2026-03-11 18:00:21','/api/files/3f011ae6-acd8-419a-b036-93f762a9c125_outputs_20250727_934ux694k9.png',0,5,1),(5,'??????','IMG-T','????',6,'2026-03-13 15:09:30','/api/files/5a8b2552-6457-4cc6-9973-3b1515768872_demo.jpeg',0,3.21,0.88),(6,'??????','IMG-OK','????',8,'2026-03-13 15:14:00','/api/files/d7359b5a-486a-40b5-8317-ebfc406e087a_49c74ab4-8fda-43a7-9369-2a480b9e50b3_demo.jpeg',0,3.66,0.77),(7,'??????','IMG-FINAL','????',9,'2026-03-13 15:17:34','/api/files/645d223a-7d43-414b-bdb5-affa241a7438.jpg',0,3.66,0.77),(8,'??????','IMG-REAL','????',10,'2026-03-13 15:20:42','/api/files/b46d4e78-479d-4df5-a1aa-310eb84f1138_49c74ab4-8fda-43a7-9369-2a480b9e50b3_demo.jpeg',0,3.88,0.79),(10,'UNDO_BLD_1773397963','TST','test',2,'2026-03-13 18:32:43',NULL,0,1.1,0.7);
/*!40000 ALTER TABLE `building` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contract`
--

DROP TABLE IF EXISTS `contract`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contract` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '合同ID',
  `contract_no` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '合同编号',
  `room_id` bigint NOT NULL COMMENT '房间ID',
  `tenant_id` bigint NOT NULL COMMENT '租户ID',
  `start_date` date NOT NULL COMMENT '起租日期',
  `end_date` date NOT NULL COMMENT '结束日期',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'ACTIVE' COMMENT '状态: ACTIVE/EXPIRED/TERMINATED/PENDING',
  `monthly_rent` decimal(12,2) DEFAULT NULL COMMENT '月租金',
  `deposit` decimal(12,2) DEFAULT NULL COMMENT '押金',
  `payment_method` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'MONTHLY' COMMENT '付款方式',
  `remark` text COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `attachment_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '附件URL',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `deleted` tinyint DEFAULT '0',
  `reminder_sent` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '已发送的提醒记录，JSON格式',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_contract_no` (`contract_no`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='合同表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contract`
--

LOCK TABLES `contract` WRITE;
/*!40000 ALTER TABLE `contract` DISABLE KEYS */;
INSERT INTO `contract` VALUES (1,'CT1773146939064',2,1,'2026-03-01','2026-03-11','TERMINATED',10.00,10.00,'MONTHLY','','','2026-03-10 20:48:59',0,NULL),(2,'CT1773147392973',1,1,'2026-03-01','2026-03-27','ACTIVE',10.00,10.00,'MONTHLY','','','2026-03-10 20:56:32',0,NULL),(3,'CT1773147765497',2,1,'2026-03-01','2026-03-31','ACTIVE',110.00,10.00,'MONTHLY','','','2026-03-10 21:02:45',0,NULL),(4,'CT1773328382197',3,1,'2026-02-01','2026-03-12','TERMINATED',1110.00,1110.00,'MONTHLY','','','2026-03-12 23:13:02',NULL,NULL),(5,'CT1773328651212',3,1,'2026-03-12','2026-03-12','TERMINATED',500.00,1000.00,'MONTHLY',NULL,NULL,'2026-03-12 23:17:31',NULL,NULL);
/*!40000 ALTER TABLE `contract` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deposit_record`
--

DROP TABLE IF EXISTS `deposit_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `deposit_record` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '押金ID',
  `contract_id` bigint NOT NULL COMMENT '合同ID',
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '类型: RECEIVE/REFUND',
  `amount` decimal(12,2) NOT NULL COMMENT '金额',
  `date` date NOT NULL COMMENT '日期',
  `remark` text COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='押金记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deposit_record`
--

LOCK TABLES `deposit_record` WRITE;
/*!40000 ALTER TABLE `deposit_record` DISABLE KEYS */;
/*!40000 ALTER TABLE `deposit_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fee_item`
--

DROP TABLE IF EXISTS `fee_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fee_item` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '费用项ID',
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '费用名称',
  `unit_price` decimal(10,2) NOT NULL COMMENT '单价',
  `unit` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '元/月' COMMENT '单位',
  `category` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'BASE' COMMENT '类别',
  `enabled` tinyint(1) DEFAULT '1' COMMENT '是否启用',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='费用项表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fee_item`
--

LOCK TABLES `fee_item` WRITE;
/*!40000 ALTER TABLE `fee_item` DISABLE KEYS */;
INSERT INTO `fee_item` VALUES (1,'网费',10.00,'元/月','BASE',1,'2026-03-10 22:13:12');
/*!40000 ALTER TABLE `fee_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `maintenance_mode`
--

DROP TABLE IF EXISTS `maintenance_mode`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `maintenance_mode` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `enabled` tinyint(1) DEFAULT '0' COMMENT '鏄?惁鍚?敤缁存姢妯″紡',
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '缁存姢鍘熷洜',
  `operator_id` bigint DEFAULT NULL COMMENT '鎿嶄綔浜篒D',
  `started_at` datetime DEFAULT NULL COMMENT '寮??鏃堕棿',
  `ended_at` datetime DEFAULT NULL COMMENT '缁撴潫鏃堕棿',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '鍒涘缓鏃堕棿',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='缁存姢妯″紡琛';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `maintenance_mode`
--

LOCK TABLES `maintenance_mode` WRITE;
/*!40000 ALTER TABLE `maintenance_mode` DISABLE KEYS */;
/*!40000 ALTER TABLE `maintenance_mode` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `meter_reading`
--

DROP TABLE IF EXISTS `meter_reading`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `meter_reading` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '读数ID',
  `room_id` bigint NOT NULL COMMENT '房间ID',
  `record_date` date NOT NULL COMMENT '录入日期',
  `water_reading` decimal(10,2) DEFAULT '0.00' COMMENT '水表读数',
  `electric_reading` decimal(10,2) DEFAULT '0.00' COMMENT '电表读数',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_room_date` (`room_id`,`record_date`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='水电读数表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `meter_reading`
--

LOCK TABLES `meter_reading` WRITE;
/*!40000 ALTER TABLE `meter_reading` DISABLE KEYS */;
INSERT INTO `meter_reading` VALUES (1,1,'2026-03-10',70.00,70.00,'2026-03-10 21:04:52'),(2,2,'2026-03-10',20.00,20.00,'2026-03-10 21:04:52'),(3,1,'2026-03-09',40.00,40.00,'2026-03-10 22:22:36'),(4,1,'2026-03-11',80.00,80.00,'2026-03-11 09:49:37'),(5,1,'2026-02-01',0.00,0.00,'2026-03-12 14:10:04'),(6,1,'2026-03-12',90.00,90.00,'2026-03-12 14:10:30');
/*!40000 ALTER TABLE `meter_reading` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operation_log`
--

DROP TABLE IF EXISTS `operation_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `operation_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '日志ID',
  `operation_time` datetime NOT NULL COMMENT '操作时间',
  `operator` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '操作人',
  `module` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '模块',
  `action` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '操作内容',
  `ip` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'IP地址',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=125 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='操作日志表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operation_log`
--

LOCK TABLES `operation_log` WRITE;
/*!40000 ALTER TABLE `operation_log` DISABLE KEYS */;
INSERT INTO `operation_log` VALUES (1,'2026-03-13 15:36:17','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 15:36:17'),(2,'2026-03-13 15:36:28','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 15:36:28'),(3,'2026-03-13 15:36:39','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 15:36:39'),(4,'2026-03-13 15:36:39','admin','批量操作','批量续租: 合同1份','0:0:0:0:0:0:0:1','2026-03-13 15:36:39'),(5,'2026-03-13 15:38:11','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 15:38:11'),(6,'2026-03-13 15:38:11','admin','批量操作','批量发送通知: 租户2人','0:0:0:0:0:0:0:1','2026-03-13 15:38:11'),(7,'2026-03-13 15:45:05','admin','批量操作','批量导出: 模块=contracts','127.0.0.1','2026-03-13 15:45:05'),(8,'2026-03-13 16:12:24','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 16:12:24'),(9,'2026-03-13 16:12:38','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 16:12:38'),(10,'2026-03-13 16:15:56','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 16:15:56'),(11,'2026-03-13 16:16:14','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 16:16:14'),(12,'2026-03-13 16:16:43','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 16:16:43'),(13,'2026-03-13 16:28:05','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 16:28:05'),(14,'2026-03-13 16:28:30','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 16:28:30'),(15,'2026-03-13 16:30:49','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 16:30:49'),(16,'2026-03-13 16:31:23','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 16:31:23'),(17,'2026-03-13 16:32:04','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 16:32:04'),(18,'2026-03-13 16:37:50','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 16:37:50'),(19,'2026-03-13 16:38:11','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 16:38:11'),(20,'2026-03-13 16:48:13','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 16:48:13'),(21,'2026-03-13 16:50:27','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 16:50:27'),(22,'2026-03-13 16:50:28','admin','导出','导出房间器具核对单PDF: 房间101(入住)','0:0:0:0:0:0:0:1','2026-03-13 16:50:28'),(23,'2026-03-13 16:50:34','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 16:50:34'),(24,'2026-03-13 16:50:35','admin','导出','导出房间器具核对单PDF: 房间101(退租)','0:0:0:0:0:0:0:1','2026-03-13 16:50:35'),(25,'2026-03-13 17:55:53','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 17:55:53'),(26,'2026-03-13 17:56:16','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 17:56:16'),(27,'2026-03-13 17:56:41','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 17:56:41'),(28,'2026-03-13 17:57:14','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 17:57:14'),(29,'2026-03-13 17:57:28','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 17:57:28'),(30,'2026-03-13 17:58:00','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 17:58:00'),(31,'2026-03-13 17:58:26','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 17:58:26'),(32,'2026-03-13 18:00:23','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 18:00:23'),(33,'2026-03-13 18:06:43','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 18:06:43'),(34,'2026-03-13 18:09:14','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 18:09:14'),(35,'2026-03-13 18:09:31','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 18:09:31'),(36,'2026-03-13 18:09:44','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 18:09:44'),(37,'2026-03-13 18:09:57','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 18:09:57'),(38,'2026-03-13 18:10:13','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 18:10:13'),(39,'2026-03-13 18:10:32','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 18:10:32'),(40,'2026-03-13 18:10:32','admin','操作恢复','恢复 账单管理 - 2026-02 / #64','0:0:0:0:0:0:0:1','2026-03-13 18:10:32'),(41,'2026-03-13 18:11:15','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 18:11:15'),(42,'2026-03-13 18:11:15','admin','操作恢复','恢复 账单管理 - 2026-02 / #64','0:0:0:0:0:0:0:1','2026-03-13 18:11:15'),(43,'2026-03-13 18:15:22','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 18:15:22'),(44,'2026-03-13 18:15:22','admin','操作恢复','恢复 账单管理 - 2026-02 / #64','0:0:0:0:0:0:0:1','2026-03-13 18:15:22'),(45,'2026-03-13 18:23:31','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 18:23:31'),(46,'2026-03-13 18:23:31','admin','操作恢复','恢复 账单管理 - 2026-02 / #64','0:0:0:0:0:0:0:1','2026-03-13 18:23:31'),(47,'2026-03-13 18:23:38','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 18:23:38'),(48,'2026-03-13 18:26:26','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 18:26:26'),(49,'2026-03-13 18:26:26','admin','操作恢复','恢复 房屋管理 - UNDO_TEST_1773397585','0:0:0:0:0:0:0:1','2026-03-13 18:26:26'),(50,'2026-03-13 18:28:09','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 18:28:09'),(51,'2026-03-13 18:32:44','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 18:32:44'),(52,'2026-03-13 18:32:44','admin','操作恢复','恢复 房屋管理 - UNDO_BLD_1773397963','0:0:0:0:0:0:0:1','2026-03-13 18:32:44'),(53,'2026-03-13 18:33:59','admin','操作恢复','恢复 房屋管理 - 101','127.0.0.1','2026-03-13 18:33:59'),(54,'2026-03-13 18:38:41','anonymousUser','用户认证','登录成功: admin','127.0.0.1','2026-03-13 18:38:41'),(55,'2026-03-13 21:36:43','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 21:36:43'),(56,'2026-03-13 21:36:57','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 21:36:57'),(57,'2026-03-13 21:37:59','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 21:37:59'),(58,'2026-03-13 21:49:38','anonymousUser','用户认证','登录失败: 系统异常(admin)','0:0:0:0:0:0:0:1','2026-03-13 21:49:38'),(59,'2026-03-13 21:50:07','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 21:50:07'),(60,'2026-03-13 21:50:29','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 21:50:29'),(61,'2026-03-13 21:52:47','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 21:52:47'),(62,'2026-03-13 21:53:33','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-13 21:53:33'),(63,'2026-03-13 21:53:33','anonymousUser','用户认证','登录成功: qr_viewer_1773410013','0:0:0:0:0:0:0:1','2026-03-13 21:53:33'),(64,'2026-03-14 21:18:34','anonymousUser','用户认证','登录失败: 密码错误(admin)','127.0.0.1','2026-03-14 21:18:34'),(65,'2026-03-14 21:18:40','anonymousUser','用户认证','登录失败: 密码错误(admin)','127.0.0.1','2026-03-14 21:18:40'),(66,'2026-03-14 21:18:52','anonymousUser','用户认证','登录失败: 密码错误(admin)','127.0.0.1','2026-03-14 21:18:52'),(67,'2026-03-14 21:18:59','anonymousUser','用户认证','登录失败: 密码错误(admin)','127.0.0.1','2026-03-14 21:18:59'),(68,'2026-03-14 21:19:02','anonymousUser','用户认证','登录失败: 密码错误(admin)','127.0.0.1','2026-03-14 21:19:02'),(69,'2026-03-14 21:19:06','anonymousUser','用户认证','登录失败: 密码错误(admin)','127.0.0.1','2026-03-14 21:19:06'),(70,'2026-03-14 21:19:34','anonymousUser','用户认证','登录成功: manager1','127.0.0.1','2026-03-14 21:19:34'),(71,'2026-03-14 21:20:33','anonymousUser','用户认证','登录失败: 密码错误(admin)','127.0.0.1','2026-03-14 21:20:33'),(72,'2026-03-14 21:20:35','anonymousUser','用户认证','登录失败: 密码错误(admin)','127.0.0.1','2026-03-14 21:20:35'),(73,'2026-03-14 21:22:43','anonymousUser','用户认证','登录失败: 密码错误(admin)','0:0:0:0:0:0:0:1','2026-03-14 21:22:43'),(74,'2026-03-14 21:22:50','anonymousUser','用户认证','登录失败: 密码错误(admin)','0:0:0:0:0:0:0:1','2026-03-14 21:22:50'),(75,'2026-03-14 21:23:08','anonymousUser','用户认证','登录失败: 密码错误(admin)','0:0:0:0:0:0:0:1','2026-03-14 21:23:08'),(76,'2026-03-14 21:27:33','anonymousUser','用户认证','登录失败: 密码错误(admin)','127.0.0.1','2026-03-14 21:27:33'),(77,'2026-03-14 21:27:39','anonymousUser','用户认证','登录失败: 密码错误(admin)','127.0.0.1','2026-03-14 21:27:39'),(78,'2026-03-14 21:27:45','anonymousUser','用户认证','登录成功: manager1','127.0.0.1','2026-03-14 21:27:45'),(79,'2026-03-14 22:04:01','anonymousUser','用户认证','登录成功: admin','127.0.0.1','2026-03-14 22:04:01'),(80,'2026-03-14 22:11:13','anonymousUser','用户认证','登录成功: admin','127.0.0.1','2026-03-14 22:11:13'),(81,'2026-03-14 22:14:00','anonymousUser','用户认证','登录成功: manager1','127.0.0.1','2026-03-14 22:14:00'),(82,'2026-03-14 22:38:52','anonymousUser','用户认证','登录失败: 密码错误(manager1)','127.0.0.1','2026-03-14 22:38:52'),(83,'2026-03-14 22:38:55','anonymousUser','用户认证','登录成功: manager1','127.0.0.1','2026-03-14 22:38:55'),(84,'2026-03-14 22:39:02','anonymousUser','用户认证','登录成功: admin','127.0.0.1','2026-03-14 22:39:02'),(85,'2026-03-14 23:11:02','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:11:02'),(86,'2026-03-14 23:11:12','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:11:12'),(87,'2026-03-14 23:11:13','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:11:13'),(88,'2026-03-14 23:11:37','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:11:37'),(89,'2026-03-14 23:14:37','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:14:37'),(90,'2026-03-14 23:14:38','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:14:38'),(91,'2026-03-14 23:15:04','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:15:04'),(92,'2026-03-14 23:17:16','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:17:16'),(93,'2026-03-14 23:17:16','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:17:16'),(94,'2026-03-14 23:17:25','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:17:25'),(95,'2026-03-14 23:17:32','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:17:32'),(96,'2026-03-14 23:21:21','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:21:21'),(97,'2026-03-14 23:21:23','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:21:23'),(98,'2026-03-14 23:21:23','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:21:23'),(99,'2026-03-14 23:26:29','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:26:29'),(100,'2026-03-14 23:26:30','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:26:30'),(101,'2026-03-14 23:26:31','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:26:31'),(102,'2026-03-14 23:28:44','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:28:44'),(103,'2026-03-14 23:28:46','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:28:46'),(104,'2026-03-14 23:28:46','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:28:46'),(105,'2026-03-14 23:30:46','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:30:46'),(106,'2026-03-14 23:30:47','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:30:47'),(107,'2026-03-14 23:30:48','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:30:48'),(108,'2026-03-14 23:32:37','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:32:37'),(109,'2026-03-14 23:32:38','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:32:38'),(110,'2026-03-14 23:32:39','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:32:39'),(111,'2026-03-14 23:33:18','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:33:18'),(112,'2026-03-14 23:33:37','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:33:37'),(113,'2026-03-14 23:34:39','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:34:39'),(114,'2026-03-14 23:38:12','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:38:12'),(115,'2026-03-14 23:38:13','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:38:13'),(116,'2026-03-14 23:38:13','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:38:13'),(117,'2026-03-14 23:38:26','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:38:26'),(118,'2026-03-14 23:40:14','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:40:14'),(119,'2026-03-14 23:41:36','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:41:36'),(120,'2026-03-14 23:43:57','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:43:57'),(121,'2026-03-14 23:43:59','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:43:59'),(122,'2026-03-14 23:43:59','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:43:59'),(123,'2026-03-14 23:45:45','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:45:45'),(124,'2026-03-14 23:54:28','anonymousUser','用户认证','登录成功: admin','0:0:0:0:0:0:0:1','2026-03-14 23:54:28');
/*!40000 ALTER TABLE `operation_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `operation_snapshot`
--

DROP TABLE IF EXISTS `operation_snapshot`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `operation_snapshot` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `user_id` bigint DEFAULT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `module` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `operation` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `target_id` bigint DEFAULT NULL,
  `target_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `table_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `before_data` json DEFAULT NULL,
  `after_data` json DEFAULT NULL,
  `is_recovered` tinyint(1) NOT NULL DEFAULT '0',
  `expired_at` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `recovered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_snapshot_created` (`created_at`),
  KEY `idx_snapshot_expired` (`expired_at`),
  KEY `idx_snapshot_target` (`table_name`,`target_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `operation_snapshot`
--

LOCK TABLES `operation_snapshot` WRITE;
/*!40000 ALTER TABLE `operation_snapshot` DISABLE KEYS */;
INSERT INTO `operation_snapshot` VALUES (2,NULL,'admin','账单管理','void',64,'2026-02 / #64','bill','{\"id\": 64, \"roomId\": 1, \"status\": \"PENDING\", \"deleted\": null, \"payments\": null, \"billMonth\": \"2026-02\", \"contractId\": 2, \"createTime\": null, \"paidAmount\": null, \"roomNumber\": \"101\", \"tenantName\": \"ZhangSan\", \"waterUsage\": null, \"tenantPhone\": \"12345678911\", \"totalAmount\": 10.0, \"buildingName\": \"A栋\", \"electricUsage\": null, \"generatedDate\": \"2026-03-13T17:57:14\", \"waterUnitPrice\": null, \"currWaterReading\": null, \"prevWaterReading\": null, \"electricUnitPrice\": null, \"currElectricReading\": null, \"prevElectricReading\": null}','{\"id\": 64, \"roomId\": 1, \"status\": \"VOID\", \"deleted\": null, \"payments\": null, \"billMonth\": \"2026-02\", \"contractId\": 2, \"createTime\": null, \"paidAmount\": null, \"roomNumber\": \"101\", \"tenantName\": \"ZhangSan\", \"waterUsage\": null, \"tenantPhone\": \"12345678911\", \"totalAmount\": 10.0, \"buildingName\": \"A栋\", \"electricUsage\": null, \"generatedDate\": \"2026-03-13T17:57:14\", \"waterUnitPrice\": null, \"currWaterReading\": null, \"prevWaterReading\": null, \"electricUnitPrice\": null, \"currElectricReading\": null, \"prevElectricReading\": null}',1,'2026-03-13 18:40:32','2026-03-13 18:10:32','2026-03-13 18:10:32'),(3,NULL,'admin','账单管理','void',64,'2026-02 / #64','bill','{\"id\": 64, \"roomId\": 1, \"status\": \"PENDING\", \"deleted\": null, \"payments\": null, \"billMonth\": \"2026-02\", \"contractId\": 2, \"createTime\": null, \"paidAmount\": null, \"roomNumber\": \"101\", \"tenantName\": \"ZhangSan\", \"waterUsage\": null, \"tenantPhone\": \"12345678911\", \"totalAmount\": 10.0, \"buildingName\": \"A栋\", \"electricUsage\": null, \"generatedDate\": \"2026-03-13T17:57:14\", \"waterUnitPrice\": null, \"currWaterReading\": null, \"prevWaterReading\": null, \"electricUnitPrice\": null, \"currElectricReading\": null, \"prevElectricReading\": null}','{\"id\": 64, \"roomId\": 1, \"status\": \"VOID\", \"deleted\": null, \"payments\": null, \"billMonth\": \"2026-02\", \"contractId\": 2, \"createTime\": null, \"paidAmount\": null, \"roomNumber\": \"101\", \"tenantName\": \"ZhangSan\", \"waterUsage\": null, \"tenantPhone\": \"12345678911\", \"totalAmount\": 10.0, \"buildingName\": \"A栋\", \"electricUsage\": null, \"generatedDate\": \"2026-03-13T17:57:14\", \"waterUnitPrice\": null, \"currWaterReading\": null, \"prevWaterReading\": null, \"electricUnitPrice\": null, \"currElectricReading\": null, \"prevElectricReading\": null}',1,'2026-03-13 18:41:15','2026-03-13 18:11:15','2026-03-13 18:11:15'),(4,NULL,'admin','账单管理','void',64,'2026-02 / #64','bill','{\"id\": 64, \"roomId\": 1, \"status\": \"PENDING\", \"deleted\": null, \"payments\": null, \"billMonth\": \"2026-02\", \"contractId\": 2, \"createTime\": null, \"paidAmount\": null, \"roomNumber\": \"101\", \"tenantName\": \"ZhangSan\", \"waterUsage\": null, \"tenantPhone\": \"12345678911\", \"totalAmount\": 10.0, \"buildingName\": \"A栋\", \"electricUsage\": null, \"generatedDate\": \"2026-03-13T17:57:14\", \"waterUnitPrice\": null, \"currWaterReading\": null, \"prevWaterReading\": null, \"electricUnitPrice\": null, \"currElectricReading\": null, \"prevElectricReading\": null}','{\"id\": 64, \"roomId\": 1, \"status\": \"VOID\", \"deleted\": null, \"payments\": null, \"billMonth\": \"2026-02\", \"contractId\": 2, \"createTime\": null, \"paidAmount\": null, \"roomNumber\": \"101\", \"tenantName\": \"ZhangSan\", \"waterUsage\": null, \"tenantPhone\": \"12345678911\", \"totalAmount\": 10.0, \"buildingName\": \"A栋\", \"electricUsage\": null, \"generatedDate\": \"2026-03-13T17:57:14\", \"waterUnitPrice\": null, \"currWaterReading\": null, \"prevWaterReading\": null, \"electricUnitPrice\": null, \"currElectricReading\": null, \"prevElectricReading\": null}',1,'2026-03-13 18:45:22','2026-03-13 18:15:22','2026-03-13 18:15:22'),(6,NULL,'admin','账单管理','void',64,'2026-02 / #64','bill','{\"id\": 64, \"roomId\": 1, \"status\": \"PENDING\", \"deleted\": null, \"payments\": null, \"billMonth\": \"2026-02\", \"contractId\": 2, \"createTime\": null, \"paidAmount\": null, \"roomNumber\": \"101\", \"tenantName\": \"ZhangSan\", \"waterUsage\": null, \"tenantPhone\": \"12345678911\", \"totalAmount\": 10.0, \"buildingName\": \"A栋\", \"electricUsage\": null, \"generatedDate\": \"2026-03-13T17:57:14\", \"waterUnitPrice\": null, \"currWaterReading\": null, \"prevWaterReading\": null, \"electricUnitPrice\": null, \"currElectricReading\": null, \"prevElectricReading\": null}','{\"id\": 64, \"roomId\": 1, \"status\": \"VOID\", \"deleted\": null, \"payments\": null, \"billMonth\": \"2026-02\", \"contractId\": 2, \"createTime\": null, \"paidAmount\": null, \"roomNumber\": \"101\", \"tenantName\": \"ZhangSan\", \"waterUsage\": null, \"tenantPhone\": \"12345678911\", \"totalAmount\": 10.0, \"buildingName\": \"A栋\", \"electricUsage\": null, \"generatedDate\": \"2026-03-13T17:57:14\", \"waterUnitPrice\": null, \"currWaterReading\": null, \"prevWaterReading\": null, \"electricUnitPrice\": null, \"currElectricReading\": null, \"prevElectricReading\": null}',1,'2026-03-13 18:53:31','2026-03-13 18:23:31','2026-03-13 18:23:31'),(8,NULL,'admin','房屋管理','delete',6,'UNDO_TEST_1773397585','room','{\"id\": 6, \"area\": 20.0, \"floor\": 1, \"layout\": \"1?\", \"status\": \"??\", \"deleted\": null, \"imageUrl\": null, \"buildingId\": 1, \"roomNumber\": \"UNDO_TEST_1773397585\", \"waterMeterId\": null, \"electricMeterId\": null}',NULL,1,'2026-03-13 18:56:26','2026-03-13 18:26:26','2026-03-13 18:26:26'),(10,NULL,'admin','房屋管理','delete',10,'UNDO_BLD_1773397963','building','{\"id\": 10, \"code\": \"TST\", \"name\": \"UNDO_BLD_1773397963\", \"address\": \"test\", \"imageUrl\": null, \"totalFloors\": 2, \"waterUnitPrice\": 1.1, \"electricUnitPrice\": 0.7}',NULL,1,'2026-03-13 19:02:44','2026-03-13 18:32:44','2026-03-13 18:32:44'),(11,NULL,'admin','房屋管理','delete',7,'101','room','{\"id\": 7, \"area\": 100.0, \"floor\": 1, \"layout\": \"\", \"status\": \"空闲\", \"deleted\": null, \"imageUrl\": \"\", \"buildingId\": 2, \"roomNumber\": \"101\", \"waterMeterId\": null, \"electricMeterId\": null}',NULL,1,'2026-03-13 19:03:58','2026-03-13 18:33:58','2026-03-13 18:33:59');
/*!40000 ALTER TABLE `operation_snapshot` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_record`
--

DROP TABLE IF EXISTS `payment_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `payment_record` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '收款ID',
  `bill_id` bigint NOT NULL COMMENT '账单ID',
  `paid_amount` decimal(12,2) NOT NULL COMMENT '收款金额',
  `paid_date` datetime DEFAULT NULL COMMENT '收款日期',
  `payment_method` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '支付方式',
  `remark` text COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  KEY `idx_bill_id` (`bill_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='收款记录表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_record`
--

LOCK TABLES `payment_record` WRITE;
/*!40000 ALTER TABLE `payment_record` DISABLE KEYS */;
INSERT INTO `payment_record` VALUES (1,53,110.00,'2026-03-11 18:14:09','CASH','','2026-03-11 18:14:08');
/*!40000 ALTER TABLE `payment_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `remind_log`
--

DROP TABLE IF EXISTS `remind_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `remind_log` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `tenant_id` int DEFAULT NULL,
  `tenant_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `room_number` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `overdue_days` int DEFAULT NULL,
  `bill_ids` json DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `content` text COLLATE utf8mb4_unicode_ci,
  `status` enum('success','failed') COLLATE utf8mb4_unicode_ci DEFAULT 'success',
  `fail_reason` text COLLATE utf8mb4_unicode_ci,
  `is_debug` tinyint(1) DEFAULT '0',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_remind_log_tenant_overdue` (`tenant_id`,`overdue_days`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `remind_log`
--

LOCK TABLES `remind_log` WRITE;
/*!40000 ALTER TABLE `remind_log` DISABLE KEYS */;
INSERT INTO `remind_log` VALUES (1,1,'测试用户','13800000000','A-101',1,'[66]',120.00,'尊敬的测试用户，您房间A-101有1笔账单逾期，总欠费120.00元，请尽快处理。','success',NULL,1,'2026-03-14 21:14:50'),(2,NULL,'张三','13800000000','A-101',1,'[1, 2]',256.80,'尊敬的张三，您有2笔账单逾期，总欠费256.80元，请尽快处理。','success',NULL,1,'2026-03-14 22:59:14');
/*!40000 ALTER TABLE `remind_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `remind_rule`
--

DROP TABLE IF EXISTS `remind_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `remind_rule` (
  `id` int NOT NULL AUTO_INCREMENT,
  `overdue_days` int NOT NULL,
  `send_time` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '09:00',
  `sms_template` text COLLATE utf8mb4_unicode_ci,
  `is_enabled` tinyint(1) DEFAULT '0',
  `sort_order` int DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `remind_rule`
--

LOCK TABLES `remind_rule` WRITE;
/*!40000 ALTER TABLE `remind_rule` DISABLE KEYS */;
INSERT INTO `remind_rule` VALUES (1,1,'21:14','尊敬的{租户姓名}，您房间{房间号}有{逾期笔数}笔账单逾期，总欠费{总欠费金额}元，请尽快处理。',1,0),(2,1,'21:15','尊敬的{租户姓名}，您房间{房间号}有{逾期笔数}笔账单逾期，总欠费{总欠费金额}元，请尽快处理。',1,0),(3,1,'21:33','尊敬的{租户姓名}，您有{逾期笔数}笔账单逾期，总欠费{总欠费金额}元。',1,10);
/*!40000 ALTER TABLE `remind_rule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `reminder_settings`
--

DROP TABLE IF EXISTS `reminder_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `reminder_settings` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `enabled` tinyint DEFAULT '1' COMMENT '是否启用提醒',
  `reminder_days` varchar(100) DEFAULT '3,1' COMMENT '提前提醒天数，多个用逗号分隔',
  `reminder_time` varchar(10) DEFAULT '09:00' COMMENT '每日提醒时间',
  `overdue_reminder_enabled` tinyint DEFAULT '0' COMMENT '是否启用逾期提醒',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='合同到期提醒设置';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reminder_settings`
--

LOCK TABLES `reminder_settings` WRITE;
/*!40000 ALTER TABLE `reminder_settings` DISABLE KEYS */;
INSERT INTO `reminder_settings` VALUES (1,1,'3,1','09:00',0,'2026-03-12 18:01:48','2026-03-12 18:01:48');
/*!40000 ALTER TABLE `reminder_settings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repair_order`
--

DROP TABLE IF EXISTS `repair_order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `repair_order` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `order_no` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `room_id` bigint NOT NULL,
  `tenant_id` bigint DEFAULT NULL,
  `reporter_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'admin',
  `reported_by` bigint DEFAULT NULL,
  `fault_type` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `images` json DEFAULT NULL,
  `appliance_id` bigint DEFAULT NULL,
  `status` varchar(30) COLLATE utf8mb4_unicode_ci DEFAULT 'pending',
  `worker_id` bigint DEFAULT NULL,
  `assigned_at` datetime DEFAULT NULL,
  `start_time` datetime DEFAULT NULL,
  `finish_time` datetime DEFAULT NULL,
  `accept_time` datetime DEFAULT NULL,
  `cancel_reason` text COLLATE utf8mb4_unicode_ci,
  `repair_result` text COLLATE utf8mb4_unicode_ci,
  `material_fee` decimal(10,2) DEFAULT '0.00',
  `labor_fee` decimal(10,2) DEFAULT '0.00',
  `total_fee` decimal(10,2) DEFAULT '0.00',
  `fee_remark` text COLLATE utf8mb4_unicode_ci,
  `is_tenant_charge` tinyint DEFAULT '0',
  `bill_item_id` bigint DEFAULT NULL,
  `rating` tinyint DEFAULT NULL,
  `comment` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_repair_order_no` (`order_no`),
  KEY `idx_repair_order_status` (`status`),
  KEY `idx_repair_order_room` (`room_id`),
  KEY `idx_repair_order_worker` (`worker_id`),
  KEY `idx_repair_order_created` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repair_order`
--

LOCK TABLES `repair_order` WRITE;
/*!40000 ALTER TABLE `repair_order` DISABLE KEYS */;
/*!40000 ALTER TABLE `repair_order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repair_worker`
--

DROP TABLE IF EXISTS `repair_worker`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `repair_worker` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint DEFAULT '1',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_repair_worker_status` (`status`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repair_worker`
--

LOCK TABLES `repair_worker` WRITE;
/*!40000 ALTER TABLE `repair_worker` DISABLE KEYS */;
INSERT INTO `repair_worker` VALUES (1,'?????A','13800000000',1,'?????','2026-03-13 16:31:23'),(2,'?????B','13900000000',1,'????','2026-03-13 16:32:04');
/*!40000 ALTER TABLE `repair_worker` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `restore_log`
--

DROP TABLE IF EXISTS `restore_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `restore_log` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '鎭㈠?ID',
  `restore_time` datetime NOT NULL COMMENT '鎭㈠?鏃堕棿',
  `backup_id` bigint NOT NULL COMMENT '鍏宠仈鐨勫?浠絀D',
  `operator_id` bigint NOT NULL COMMENT '鎿嶄綔鐢ㄦ埛ID',
  `status` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'success' COMMENT '鎭㈠?鐘舵?: success/failed',
  `fail_reason` text COLLATE utf8mb4_unicode_ci COMMENT '澶辫触鍘熷洜',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '璁板綍鍒涘缓鏃堕棿',
  PRIMARY KEY (`id`),
  KEY `idx_backup_id` (`backup_id`),
  KEY `idx_restore_time` (`restore_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='鎭㈠?鏃ュ織琛';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `restore_log`
--

LOCK TABLES `restore_log` WRITE;
/*!40000 ALTER TABLE `restore_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `restore_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room`
--

DROP TABLE IF EXISTS `room`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `room` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '房间ID',
  `building_id` bigint NOT NULL COMMENT '楼栋ID',
  `floor` int DEFAULT NULL COMMENT '楼层',
  `room_number` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '房间号',
  `layout` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '户型',
  `area` decimal(10,2) DEFAULT NULL COMMENT '面积(平方米)',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'IDLE' COMMENT '状态: IDLE/RENTED/MAINTENANCE',
  `water_meter_id` bigint DEFAULT NULL COMMENT '水表ID',
  `electric_meter_id` bigint DEFAULT NULL COMMENT '电表ID',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `image_url` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted` tinyint DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_building_floor_number` (`building_id`,`floor`,`room_number`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='房间表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room`
--

LOCK TABLES `room` WRITE;
/*!40000 ALTER TABLE `room` DISABLE KEYS */;
INSERT INTO `room` VALUES (1,1,1,'101','',100.00,'已租',NULL,NULL,'2026-03-10 20:35:34',NULL,0),(2,1,1,'202','',10.00,'已租',NULL,NULL,'2026-03-10 20:35:54',NULL,0),(3,3,1,'303','',10.00,'空闲',NULL,NULL,'2026-03-12 23:11:59','',NULL),(6,1,1,'UNDO_TEST_1773397585','1?',20.00,'??',NULL,NULL,'2026-03-13 18:26:25',NULL,NULL),(7,2,1,'101','',100.00,'空闲',NULL,NULL,'2026-03-13 18:33:59','',NULL);
/*!40000 ALTER TABLE `room` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `room_appliance`
--

DROP TABLE IF EXISTS `room_appliance`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `room_appliance` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `room_id` bigint NOT NULL,
  `appliance_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `brand` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` int DEFAULT '1',
  `unit` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '个',
  `status` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT '正常',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `photos` json DEFAULT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `updated_at` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_room_appliance_room_id` (`room_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `room_appliance`
--

LOCK TABLES `room_appliance` WRITE;
/*!40000 ALTER TABLE `room_appliance` DISABLE KEYS */;
INSERT INTO `room_appliance` VALUES (1,0,'????','????',1,'?','???',NULL,'[]','2026-03-13 16:31:23','2026-03-13 16:31:23'),(2,1,'????',NULL,1,'?','???',NULL,'[]','2026-03-13 16:32:04','2026-03-13 16:32:04'),(3,1,'空调','',1,'个','正常','','[]','2026-03-13 16:55:18','2026-03-13 16:55:18');
/*!40000 ALTER TABLE `room_appliance` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sms_config`
--

DROP TABLE IF EXISTS `sms_config`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sms_config` (
  `id` int NOT NULL AUTO_INCREMENT,
  `provider` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT 'aliyun',
  `access_key` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `access_secret` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `signature` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `template_code` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `debug_mode` tinyint(1) DEFAULT '1',
  `status` tinyint(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sms_config`
--

LOCK TABLES `sms_config` WRITE;
/*!40000 ALTER TABLE `sms_config` DISABLE KEYS */;
INSERT INTO `sms_config` VALUES (1,'aliyun','','','租赁平台','',1,1),(2,'aliyun','','','租赁平台','',1,1);
/*!40000 ALTER TABLE `sms_config` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_user`
--

DROP TABLE IF EXISTS `sys_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_user` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `real_name` varchar(100) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `role` varchar(20) NOT NULL DEFAULT 'STAFF',
  `enabled` tinyint NOT NULL DEFAULT '1',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP,
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_login_time` datetime DEFAULT NULL COMMENT '最后登录时间',
  `theme_preference` varchar(20) NOT NULL DEFAULT 'system' COMMENT '??????: light/dark/system',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_user`
--

LOCK TABLES `sys_user` WRITE;
/*!40000 ALTER TABLE `sys_user` DISABLE KEYS */;
INSERT INTO `sys_user` VALUES (1,'admin','$2b$12$.R7Grg09dhjB7hyiA.QqJOG5nGpP6jN4btgeS13.ZOqnkL03igV1u','系统管理员',NULL,NULL,'SUPER_ADMIN',1,NULL,NULL,'2026-03-14 23:54:28','system'),(2,'manager1','$2a$10$1q0BCMTEIImVlKGgd08dM.TvlMg3cYo1jmcFNl2A18l80VrDUG./S','管理员1',NULL,NULL,'ADMIN',1,'2026-03-13 12:00:06',NULL,'2026-03-14 22:38:55','system');
/*!40000 ALTER TABLE `sys_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_message`
--

DROP TABLE IF EXISTS `system_message`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_message` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `type` varchar(50) NOT NULL COMMENT '消息类型：CONTRACT_EXPIRE-合同到期提醒',
  `title` varchar(200) NOT NULL COMMENT '消息标题',
  `content` text NOT NULL COMMENT '消息内容',
  `related_id` bigint DEFAULT NULL COMMENT '关联ID（合同ID）',
  `is_read` tinyint DEFAULT '0' COMMENT '是否已读：0-未读，1-已读',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `read_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='系统消息';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_message`
--

LOCK TABLES `system_message` WRITE;
/*!40000 ALTER TABLE `system_message` DISABLE KEYS */;
INSERT INTO `system_message` VALUES (1,'BATCH_NOTIFY','??????','????????',1,1,'2026-03-13 15:38:11','2026-03-13 18:33:24'),(2,'BATCH_NOTIFY','??????','????????',2,1,'2026-03-13 15:38:11','2026-03-13 18:33:30'),(3,'SMS_MOCK','短信已发送(模拟)','租户: 张三; 手机号: 13800000000; 房间: A-101; 内容: 尊敬的张三，您有2笔账单逾期，总欠费256.80元，请尽快处理。',NULL,1,'2026-03-14 22:59:14','2026-03-14 22:59:33');
/*!40000 ALTER TABLE `system_message` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenant`
--

DROP TABLE IF EXISTS `tenant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '租户ID',
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '姓名',
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '手机号',
  `id_card` varchar(18) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '身份证号',
  `emergency_contact` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '紧急联系人',
  `emergency_phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '紧急联系电话',
  `remark` text COLLATE utf8mb4_unicode_ci COMMENT '备注',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `deleted` tinyint DEFAULT '0',
  `is_blacklisted` tinyint DEFAULT '0' COMMENT '是否在黑名单中',
  `blacklist_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '加入黑名单原因',
  `blacklisted_at` datetime DEFAULT NULL COMMENT '加入黑名单时间',
  `blacklisted_by` bigint DEFAULT NULL COMMENT '操作人ID',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_phone` (`phone`),
  KEY `idx_tenant_blacklisted` (`is_blacklisted`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='租户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant`
--

LOCK TABLES `tenant` WRITE;
/*!40000 ALTER TABLE `tenant` DISABLE KEYS */;
INSERT INTO `tenant` VALUES (1,'ZhangSan','12345678911','110101199001011234','李四','13800138000',NULL,'2026-03-10 20:35:22',0,0,NULL,NULL,NULL),(2,'李四','14785236900','','','','','2026-03-12 23:11:18',NULL,1,'扰民','2026-03-12 23:11:31',1);
/*!40000 ALTER TABLE `tenant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '用户名',
  `password` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT '密码',
  `real_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '真实姓名',
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '手机号',
  `role` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT 'ADMIN' COMMENT '角色',
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户表';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin','$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5EH','管理员',NULL,'ADMIN','2026-03-10 17:57:22');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-03-14 23:54:29
